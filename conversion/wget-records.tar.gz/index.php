<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
 <TITLE>Rocks Cluster Register</TITLE>
 <META http-equiv="Content-type" content="text/html; charset=utf-8">
 <META HTTP-EQUIV="expires" CONTENT="Wed, 20 Feb 2000 08:30:00 GMT">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
 <LINK rel="stylesheet" href="./styles.css" type="text/css">
</HEAD>
<BODY BGCOLOR="#FFFFFF">

<TABLE WIDTH=100% CELLSPACING=5>
 <TR>
   <TD ALIGN=left VALIGN=center>
    <H1>Rocks Cluster Register</H1>
    Back to <a href=/>www.rocksclusters.org</a>
   </TD>
<!--
<td align=center>
 <img src="./pie.php?title=CPU%20FLOPS&size=350x150&Pentium=1389051350.29,0021a5&Athlon=12690.57,f9873b&Opteron=256425.66,efbe5d&EM64T=226216.56,f221a8&Itanium=10196.8,4f94cd&Other=9536909.94,c6c6c6" border="0">
</td>
-->
<td align=center>
 <img src="./pie.php?title=CPU%20Types&size=350x150&Pentium=124154230,0021a5&Athlon=3457,f9873b&Opteron=56458,efbe5d&EM64T=41057,f221a8&Itanium=1509,4f94cd&Other=703896,c6c6c6" border="0">
</td>
   <TD ALIGN=right>
    <A HREF="http://www.rocksclusters.org">
     <IMG SRC="images/rocks.jpg" ALT="Rocks Clusters" HEIGHT=100 WIDTH=100 BORDER=0>
    </A>
   </TD>
 </TR>
</TABLE>


<a href="./insert.php">Add your cluster to the Register</a>.<br>
Click on a column header to sort by that field.<br>
Click on an (id) for details and to edit your cluster.

<p>

<center>
<table cellspacing=10>
<tr>
 <th>Id</th>
 <th><a href=./index.php?sortby=Name&sortorder=down>Name</a></th>
 <th><a href=./index.php?sortby=Org&sortorder=down>Org</a></th>
 <th><a href=./index.php?sortby=CPUType&sortorder=down>CPUType</a></th>
 <th><a href=./index.php?sortby=CPUs&sortorder=down>CPUs</a></th>
 <th><a href=./index.php?sortby=CPUClock&sortorder=down>CPUClock</a> (GHz)</th>
 <th><a href=./index.php?sortby=FLOPS&sortorder=down>FLOPS</a> (GFLOPS)</th>
 <th><a href=./index.php?sortby=Location&sortorder=down>Location</a></th>
 <td><a href=./index.php?sortby=Id&sortorder=up>Up</a> | Down</td>
</tr>

<tr class=even>
 <td align=center><strong>1837</strong></td>
 <td align=center colspan=3><strong>Total CPUs, Ave CPUClock, Total FLOPS:</strong></td>
 <td align=center><strong>124960607</strong></td>
 <td align=center><strong>2.53</strong></td>
 <td align=center><strong>1399093789.82</strong></td>
</tr>

<tr class=odd>
 <td align=center><a href="details.php?id=2205">(2205) More</a></td>
 <td align=center>Heelsofflight</td>
 <td align=center>Heels of Flight</td>
 <td align=center>EM64T-8</td>
 <td align=center>1024</td>
 <td align=center>4.96</td>
 <td align=center>40632.32</td>
 <td align=center>Mound City, MO</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2204">(2204) More</a></td>
 <td align=center>Jafet Aldair Valle López</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>1</td>
 <td align=center>3.00</td>
 <td align=center>3</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2203">(2203) More</a></td>
 <td align=center>Heelsofflight2</td>
 <td align=center>Heels of Flight</td>
 <td align=center>Other</td>
 <td align=center>4096</td>
 <td align=center>3.30</td>
 <td align=center>13516.8</td>
 <td align=center>Charleston SC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2202">(2202) More</a></td>
 <td align=center>Woodrow</td>
 <td align=center>NCSU Graduate Student</td>
 <td align=center>EM64T-4</td>
 <td align=center>128</td>
 <td align=center>5.50</td>
 <td align=center>2816</td>
 <td align=center>Antarctica (MacTown)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2201">(2201) More</a></td>
 <td align=center>frontend</td>
 <td align=center>R&R</td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>1.00</td>
 <td align=center>3</td>
 <td align=center>Santo Domingo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2200">(2200) More</a></td>
 <td align=center>Cyrix-cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>16</td>
 <td align=center>4.00</td>
 <td align=center>64</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2199">(2199) More</a></td>
 <td align=center>wje-cluster</td>
 <td align=center>Wjohnson Enterprises</td>
 <td align=center>EM64T-8</td>
 <td align=center>36</td>
 <td align=center>3.00</td>
 <td align=center>864</td>
 <td align=center>Orangevale</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2198">(2198) More</a></td>
 <td align=center>SGE</td>
 <td align=center>Ghate</td>
 <td align=center>Athlon 64</td>
 <td align=center>1</td>
 <td align=center>2.00</td>
 <td align=center>4</td>
 <td align=center>Pune</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2197">(2197) More</a></td>
 <td align=center>badifa</td>
 <td align=center>manager</td>
 <td align=center>Pentium 2</td>
 <td align=center>2</td>
 <td align=center>2.00</td>
 <td align=center>4</td>
 <td align=center>san diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2196">(2196) More</a></td>
 <td align=center>Rocks @ Bentley</td>
 <td align=center>Bentley University</td>
 <td align=center>EM64T</td>
 <td align=center>128</td>
 <td align=center>2.66</td>
 <td align=center>680.96</td>
 <td align=center>Waltham, MA, USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2195">(2195) More</a></td>
 <td align=center>nano-upvm</td>
 <td align=center>Nanotecnología UPVM</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>2.83</td>
 <td align=center>11.32</td>
 <td align=center>Tultitlán, Estado de México</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2194">(2194) More</a></td>
 <td align=center>ASdsdfsdf</td>
 <td align=center>mm2 by Deuthland</td>
 <td align=center>Opteron</td>
 <td align=center>2</td>
 <td align=center>2.00</td>
 <td align=center>8</td>
 <td align=center>Berlin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2193">(2193) More</a></td>
 <td align=center>centos</td>
 <td align=center>bhatia</td>
 <td align=center>Unspecified</td>
 <td align=center>4</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2190">(2190) More</a></td>
 <td align=center>Hal9000</td>
 <td align=center>Texas A&M University</td>
 <td align=center>Opteron</td>
 <td align=center>192</td>
 <td align=center>2.50</td>
 <td align=center>960</td>
 <td align=center>Galveston, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2189">(2189) More</a></td>
 <td align=center>KSU Student HPC Cluster</td>
 <td align=center>Kennesaw State University</td>
 <td align=center>EM64T</td>
 <td align=center>136</td>
 <td align=center>2.40</td>
 <td align=center>652.8</td>
 <td align=center>Marietta, Georgia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2188">(2188) More</a></td>
 <td align=center>ApallEngMax</td>
 <td align=center>BezoooomyInc</td>
 <td align=center>Other</td>
 <td align=center>5</td>
 <td align=center>2.60</td>
 <td align=center>13</td>
 <td align=center>BerkelyHieghts</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2187">(2187) More</a></td>
 <td align=center>cluster.bialowas.info.tm</td>
 <td align=center>temcom</td>
 <td align=center>Other</td>
 <td align=center>14</td>
 <td align=center>2.20</td>
 <td align=center>30.8</td>
 <td align=center>Graz, Austria</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2185">(2185) More</a></td>
 <td align=center>caprica</td>
 <td align=center>bramNET Research</td>
 <td align=center>EM64T-8</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>716.8</td>
 <td align=center>Saint Louis</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2184">(2184) More</a></td>
 <td align=center>mendal</td>
 <td align=center>MGMIBT</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>2.36</td>
 <td align=center>9.44</td>
 <td align=center>Aurangabad (MS) India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2183">(2183) More</a></td>
 <td align=center>cluster007</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>4</td>
 <td align=center>2.00</td>
 <td align=center>8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2182">(2182) More</a></td>
 <td align=center>Zombie</td>
 <td align=center>Bombay College of Pharmacy</td>
 <td align=center>EM64T</td>
 <td align=center>80</td>
 <td align=center>2.66</td>
 <td align=center>425.6</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2181">(2181) More</a></td>
 <td align=center>ComuOne</td>
 <td align=center>UPSLP</td>
 <td align=center>Unspecified</td>
 <td align=center>3</td>
 <td align=center>1.80</td>
 <td align=center>5.4</td>
 <td align=center>Mexico San Luis POtosi</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2180">(2180) More</a></td>
 <td align=center>knightwolf</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>4</td>
 <td align=center>2.30</td>
 <td align=center>9.2</td>
 <td align=center>Darwen</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2179">(2179) More</a></td>
 <td align=center>Exciton</td>
 <td align=center>Arizona State University</td>
 <td align=center>Opteron</td>
 <td align=center>480</td>
 <td align=center>2.30</td>
 <td align=center>2208</td>
 <td align=center>Mesa</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2178">(2178) More</a></td>
 <td align=center>boltzmann</td>
 <td align=center>UW Milwaukee - Nor-tech</td>
 <td align=center>Other</td>
 <td align=center>360</td>
 <td align=center>2.60</td>
 <td align=center>936</td>
 <td align=center>Milwaukee</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2177">(2177) More</a></td>
 <td align=center>qx57</td>
 <td align=center>Cornell University</td>
 <td align=center>Other</td>
 <td align=center>1</td>
 <td align=center>2.20</td>
 <td align=center>2.2</td>
 <td align=center>Ithaca</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2176">(2176) More</a></td>
 <td align=center>CC-CLUSTER</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.44</td>
 <td align=center>19.52</td>
 <td align=center>London</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2175">(2175) More</a></td>
 <td align=center>hpc-nfdd</td>
 <td align=center>Saurashtra University</td>
 <td align=center>EM64T-8</td>
 <td align=center>48</td>
 <td align=center>1.90</td>
 <td align=center>729.6</td>
 <td align=center>Rajkot, Gujarat</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2174">(2174) More</a></td>
 <td align=center>genetica</td>
 <td align=center>FISABIO salud publica</td>
 <td align=center>EM64T-8</td>
 <td align=center>254</td>
 <td align=center>2.20</td>
 <td align=center>4470.4</td>
 <td align=center>Valencia Spain</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2172">(2172) More</a></td>
 <td align=center>DetotatedWam</td>
 <td align=center>hpc</td>
 <td align=center>Athlon 64</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Chippewa Falls, Wisconsin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2171">(2171) More</a></td>
 <td align=center>Dont Be fake</td>
 <td align=center>Beeeters</td>
 <td align=center>Pentium 4</td>
 <td align=center>123984372</td>
 <td align=center>5.60</td>
 <td align=center>1388624966.4</td>
 <td align=center>Waffels, Africa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2170">(2170) More</a></td>
 <td align=center>Advanced Computing Class</td>
 <td align=center>CFHS</td>
 <td align=center>Athlon 64</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Chippewa Falls</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2168">(2168) More</a></td>
 <td align=center>aahymee</td>
 <td align=center>ned</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>karachi</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2167">(2167) More</a></td>
 <td align=center>Heavy Metal</td>
 <td align=center>School of Mechanical Engineering, The University of Adelaide</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>3.40</td>
 <td align=center>54.4</td>
 <td align=center>Adelaide, South Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2166">(2166) More</a></td>
 <td align=center>Hikari</td>
 <td align=center>iCeMS, Kyoto University</td>
 <td align=center>Opteron</td>
 <td align=center>48</td>
 <td align=center>2.80</td>
 <td align=center>268.8</td>
 <td align=center>Kyoto, Japan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2165">(2165) More</a></td>
 <td align=center>masta</td>
 <td align=center>Pecet - Laboratorio de biologia molecular</td>
 <td align=center>EM64T-8</td>
 <td align=center>88</td>
 <td align=center>2.00</td>
 <td align=center>1408</td>
 <td align=center>Medellin - Antioquia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2164">(2164) More</a></td>
 <td align=center>bisthpc</td>
 <td align=center>Bharath institute of science and technology</td>
 <td align=center>Unspecified</td>
 <td align=center>4</td>
 <td align=center>2.60</td>
 <td align=center>10.4</td>
 <td align=center>chennai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2162">(2162) More</a></td>
 <td align=center>3Dcluster</td>
 <td align=center>3Dstorm Production</td>
 <td align=center>Unspecified</td>
 <td align=center>16</td>
 <td align=center>2.66</td>
 <td align=center>42.56</td>
 <td align=center>Abuja</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2161">(2161) More</a></td>
 <td align=center>optimus-psu</td>
 <td align=center>Prince of Songkla University</td>
 <td align=center>Unspecified</td>
 <td align=center>24</td>
 <td align=center>3.50</td>
 <td align=center>84</td>
 <td align=center>Pattani, Thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2158">(2158) More</a></td>
 <td align=center>bit.mpcl.in</td>
 <td align=center>MPCL</td>
 <td align=center>Other</td>
 <td align=center>2</td>
 <td align=center>2.93</td>
 <td align=center>5.86</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2157">(2157) More</a></td>
 <td align=center>CfN Compute Cluster</td>
 <td align=center>Univ. of Pennsylvania - Neurology</td>
 <td align=center>Other</td>
 <td align=center>336</td>
 <td align=center>2.20</td>
 <td align=center>739.2</td>
 <td align=center>Philadelphia, PA, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2156">(2156) More</a></td>
 <td align=center>TT_PC</td>
 <td align=center>GAMEK</td>
 <td align=center>EM64T-4</td>
 <td align=center>20</td>
 <td align=center>4.40</td>
 <td align=center>352</td>
 <td align=center>GK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2155">(2155) More</a></td>
 <td align=center>fistUA</td>
 <td align=center>PLASMANT, University of Antwerp</td>
 <td align=center>EM64T</td>
 <td align=center>33</td>
 <td align=center>3.20</td>
 <td align=center>211.2</td>
 <td align=center>Wilrijk, Antewerp</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2154">(2154) More</a></td>
 <td align=center>hawk.hna.wan</td>
 <td align=center>Hutchinson AntiVibration - Nor-Tech</td>
 <td align=center>Unspecified</td>
 <td align=center>28</td>
 <td align=center>2.60</td>
 <td align=center>72.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2153">(2153) More</a></td>
 <td align=center>Schreiber2011</td>
 <td align=center>Freelancer</td>
 <td align=center>EM64T</td>
 <td align=center>2</td>
 <td align=center>2.80</td>
 <td align=center>11.2</td>
 <td align=center>Manaus</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2152">(2152) More</a></td>
 <td align=center>castor</td>
 <td align=center>National Astronomical Research Institute of Thailand</td>
 <td align=center>EM64T-8</td>
 <td align=center>80</td>
 <td align=center>2.60</td>
 <td align=center>1664</td>
 <td align=center>Chiang Mai, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2151">(2151) More</a></td>
 <td align=center>bigcat</td>
 <td align=center>Bombay College of Pharmacy</td>
 <td align=center>EM64T</td>
 <td align=center>144</td>
 <td align=center>2.66</td>
 <td align=center>766.08</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2150">(2150) More</a></td>
 <td align=center>BigIdea</td>
 <td align=center>Big Data Lab</td>
 <td align=center>EM64T-4</td>
 <td align=center>60</td>
 <td align=center>2.66</td>
 <td align=center>638.4</td>
 <td align=center>Birmingham AL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2149">(2149) More</a></td>
 <td align=center>Navlerind</td>
 <td align=center>HPC</td>
 <td align=center>Other</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>1.8</td>
 <td align=center>Garut</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2148">(2148) More</a></td>
 <td align=center>Terra-Cluster</td>
 <td align=center>FAUGI</td>
 <td align=center>EM64T-8</td>
 <td align=center>640</td>
 <td align=center>2.40</td>
 <td align=center>12288</td>
 <td align=center>Moscow</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2147">(2147) More</a></td>
 <td align=center>Informatics cluster</td>
 <td align=center>Mongolian</td>
 <td align=center>EM64T-4</td>
 <td align=center>36</td>
 <td align=center>2.20</td>
 <td align=center>316.8</td>
 <td align=center>Ulaanbaatar</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2146">(2146) More</a></td>
 <td align=center>Raven</td>
 <td align=center>University of St. Thomas</td>
 <td align=center>EM64T-8</td>
 <td align=center>416</td>
 <td align=center>2.60</td>
 <td align=center>8652.8</td>
 <td align=center>St. Paul, MN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2145">(2145) More</a></td>
 <td align=center>Deep Dream</td>
 <td align=center>Cleveland City Schools</td>
 <td align=center>Other</td>
 <td align=center>6</td>
 <td align=center>2.40</td>
 <td align=center>14.4</td>
 <td align=center>Cleveland, Tennessee</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2144">(2144) More</a></td>
 <td align=center>Gaia - Syracuse</td>
 <td align=center>Syracuse University - Nor-Tech</td>
 <td align=center>EM64T-8</td>
 <td align=center>64</td>
 <td align=center>2.66</td>
 <td align=center>1361.92</td>
 <td align=center>Syracuse, New York</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2143">(2143) More</a></td>
 <td align=center>Info.vurtual</td>
 <td align=center>Mongolian</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>1.80</td>
 <td align=center>10.8</td>
 <td align=center>Ulaanbaatar</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2142">(2142) More</a></td>
 <td align=center>reed.cluster</td>
 <td align=center>MOCK</td>
 <td align=center>Other</td>
 <td align=center>2</td>
 <td align=center>2.00</td>
 <td align=center>4</td>
 <td align=center>Madera, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2141">(2141) More</a></td>
 <td align=center>ProjHPC</td>
 <td align=center>ProjHPC</td>
 <td align=center>EM64T</td>
 <td align=center>1</td>
 <td align=center>1.70</td>
 <td align=center>3.4</td>
 <td align=center>Rio de Janeiro</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2140">(2140) More</a></td>
 <td align=center>Enclavix</td>
 <td align=center>Enclavix, LLC</td>
 <td align=center>Opteron</td>
 <td align=center>6</td>
 <td align=center>4.00</td>
 <td align=center>48</td>
 <td align=center>Bountiful, UT</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2139">(2139) More</a></td>
 <td align=center>Davesmacer</td>
 <td align=center>UCR</td>
 <td align=center>Unspecified</td>
 <td align=center>4</td>
 <td align=center>2.00</td>
 <td align=center>8</td>
 <td align=center>San Pedro</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2138">(2138) More</a></td>
 <td align=center>hpcc.ds.boeing.com</td>
 <td align=center>Boeing Research and Technology</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>2.80</td>
 <td align=center>716.8</td>
 <td align=center>Huntington Beach, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2137">(2137) More</a></td>
 <td align=center>boxorocks</td>
 <td align=center>X-TREME MEDIA LLC</td>
 <td align=center>EM64T-4</td>
 <td align=center>52</td>
 <td align=center>2.30</td>
 <td align=center>478.4</td>
 <td align=center>Detroit Lakes, MN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2136">(2136) More</a></td>
 <td align=center>Vor</td>
 <td align=center>SERENE, University of Birmingham</td>
 <td align=center>Itanium 2</td>
 <td align=center>54</td>
 <td align=center>3.20</td>
 <td align=center>691.2</td>
 <td align=center>Birmingham</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2135">(2135) More</a></td>
 <td align=center>Soyuz HPC Cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T-4</td>
 <td align=center>8</td>
 <td align=center>3.00</td>
 <td align=center>96</td>
 <td align=center>Chicago</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2134">(2134) More</a></td>
 <td align=center>TSSM</td>
 <td align=center>UNIV</td>
 <td align=center>EM64T-4</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>57.6</td>
 <td align=center>TIARET</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2133">(2133) More</a></td>
 <td align=center>Biophysics</td>
 <td align=center>Biomedical Engineering, Pukyong National University</td>
 <td align=center>EM64T-8</td>
 <td align=center>484</td>
 <td align=center>3.60</td>
 <td align=center>13939.2</td>
 <td align=center>Busan, South Korea</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2132">(2132) More</a></td>
 <td align=center>padawancluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 2</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>33.6</td>
 <td align=center>Ticino, CH</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2130">(2130) More</a></td>
 <td align=center>ca-cluster</td>
 <td align=center>University Sao Paulo</td>
 <td align=center>Other</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>Ribeirao Preto</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2129">(2129) More</a></td>
 <td align=center>cluster.vinny.us</td>
 <td align=center>vinny.us</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>3.00</td>
 <td align=center>192</td>
 <td align=center>San Antonio</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2128">(2128) More</a></td>
 <td align=center>cluster1</td>
 <td align=center>Ecomotors Nor-Tech</td>
 <td align=center>EM64T-8</td>
 <td align=center>60</td>
 <td align=center>3.10</td>
 <td align=center>1488</td>
 <td align=center>Michigan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2127">(2127) More</a></td>
 <td align=center>ARCHIMEDES</td>
 <td align=center>2o GENIKO LIKIO SYKEON</td>
 <td align=center>EM64T-4</td>
 <td align=center>4</td>
 <td align=center>3.75</td>
 <td align=center>60</td>
 <td align=center>thessaloniki, GREECE</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2126">(2126) More</a></td>
 <td align=center>VGI-Road</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T-4</td>
 <td align=center>1</td>
 <td align=center>2.40</td>
 <td align=center>9.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2125">(2125) More</a></td>
 <td align=center>OSU CMS T3</td>
 <td align=center>The Ohio State University</td>
 <td align=center>EM64T-4</td>
 <td align=center>460</td>
 <td align=center>2.53</td>
 <td align=center>4655.2</td>
 <td align=center>Columbus, OH</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2124">(2124) More</a></td>
 <td align=center>slave-root</td>
 <td align=center>MAS</td>
 <td align=center>Unspecified</td>
 <td align=center>2</td>
 <td align=center>8.00</td>
 <td align=center>16</td>
 <td align=center>UB</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2123">(2123) More</a></td>
 <td align=center>kaveri</td>
 <td align=center>School of Physics, Bharathidasan University</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.30</td>
 <td align=center>294.4</td>
 <td align=center>Tiruchirappalli, India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2122">(2122) More</a></td>
 <td align=center>BICNIRRH</td>
 <td align=center>NIRRH</td>
 <td align=center>Other</td>
 <td align=center>60</td>
 <td align=center>2.60</td>
 <td align=center>156</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2121">(2121) More</a></td>
 <td align=center>pecnet</td>
 <td align=center>Priyadarshini Engineering College</td>
 <td align=center>EM64T-8</td>
 <td align=center>72</td>
 <td align=center>3.20</td>
 <td align=center>1843.2</td>
 <td align=center>Vaniyambadi Tamil Nadu India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2120">(2120) More</a></td>
 <td align=center>rock-cluster.pune.cdac.in</td>
 <td align=center>CDAC</td>
 <td align=center>EM64T-4</td>
 <td align=center>2</td>
 <td align=center>2.00</td>
 <td align=center>16</td>
 <td align=center>Pune</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2119">(2119) More</a></td>
 <td align=center>Zen-Rocks</td>
 <td align=center>Zenit Informatica S.r.l.</td>
 <td align=center>EM64T</td>
 <td align=center>62</td>
 <td align=center>3.17</td>
 <td align=center>393.08</td>
 <td align=center>San Pietro Mosezzo</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2118">(2118) More</a></td>
 <td align=center>LN-C9-LT</td>
 <td align=center>HUST</td>
 <td align=center>Other</td>
 <td align=center>32</td>
 <td align=center>1.86</td>
 <td align=center>59.52</td>
 <td align=center>C9, 1 Dai Co Viet, Hanoi</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2116">(2116) More</a></td>
 <td align=center>singlecell</td>
 <td align=center>STanford University</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>United States</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2115">(2115) More</a></td>
 <td align=center>Protos</td>
 <td align=center>Bowling Green State Univestity </td>
 <td align=center>Other</td>
 <td align=center>64</td>
 <td align=center>3.40</td>
 <td align=center>217.6</td>
 <td align=center>Bowling Green, OH</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2114">(2114) More</a></td>
 <td align=center>asman</td>
 <td align=center>University of Mazandaran</td>
 <td align=center>Athlon 64</td>
 <td align=center>48</td>
 <td align=center>2.20</td>
 <td align=center>211.2</td>
 <td align=center>Babolsar, Iran</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2113">(2113) More</a></td>
 <td align=center>VAX</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>3.20</td>
 <td align=center>9.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2112">(2112) More</a></td>
 <td align=center>nic.mst.edu</td>
 <td align=center>Missouri University of Science and Technology</td>
 <td align=center>EM64T-8</td>
 <td align=center>2918</td>
 <td align=center>2.50</td>
 <td align=center>58360</td>
 <td align=center>Rolla, MO, US</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2110">(2110) More</a></td>
 <td align=center>BrightStar</td>
 <td align=center>CKA Holdings</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Houston</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2109">(2109) More</a></td>
 <td align=center>wcpkneel</td>
 <td align=center>Westmont</td>
 <td align=center>EM64T-4</td>
 <td align=center>204</td>
 <td align=center>3.60</td>
 <td align=center>2937.6</td>
 <td align=center>Santa Barbara</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2108">(2108) More</a></td>
 <td align=center>FiberTEAM-cluster</td>
 <td align=center>FiberTEAM</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>3.40</td>
 <td align=center>272</td>
 <td align=center>Norway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2107">(2107) More</a></td>
 <td align=center>Cluster IBCG</td>
 <td align=center>CNRS IBCG</td>
 <td align=center>EM64T-4</td>
 <td align=center>384</td>
 <td align=center>2.40</td>
 <td align=center>3686.4</td>
 <td align=center>Toulouse</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2106">(2106) More</a></td>
 <td align=center>sid-cluster</td>
 <td align=center>student</td>
 <td align=center>Other</td>
 <td align=center>7</td>
 <td align=center>2.30</td>
 <td align=center>16.1</td>
 <td align=center>mumbai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2105">(2105) More</a></td>
 <td align=center>nostromo</td>
 <td align=center>coventry university</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>coventry</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2103">(2103) More</a></td>
 <td align=center>Gecko1</td>
 <td align=center>Instituto de Física, U.A.S.L.P.</td>
 <td align=center>Opteron</td>
 <td align=center>60</td>
 <td align=center>2.40</td>
 <td align=center>288</td>
 <td align=center>San Luis Potosí, S.L.P.</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2102">(2102) More</a></td>
 <td align=center>daniel3</td>
 <td align=center>Instituto de Física, U.A.S.L.P.</td>
 <td align=center>Opteron</td>
 <td align=center>256</td>
 <td align=center>1.40</td>
 <td align=center>716.8</td>
 <td align=center>San Luis Potosí, S.L.P.</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2101">(2101) More</a></td>
 <td align=center>cheminf.ncl.res.in</td>
 <td align=center>CSIR-National Chemical Laboratory,</td>
 <td align=center>EM64T</td>
 <td align=center>480</td>
 <td align=center>2.40</td>
 <td align=center>2304</td>
 <td align=center>Pune, India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2100">(2100) More</a></td>
 <td align=center>C01N</td>
 <td align=center>Cloudcroft</td>
 <td align=center>Pentium 4</td>
 <td align=center>146400</td>
 <td align=center>1.10</td>
 <td align=center>322080</td>
 <td align=center>Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2099">(2099) More</a></td>
 <td align=center>Tulip Trading</td>
 <td align=center>Cloudcroft</td>
 <td align=center>EM64T-8</td>
 <td align=center>2400</td>
 <td align=center>2.40</td>
 <td align=center>46080</td>
 <td align=center>Australia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2098">(2098) More</a></td>
 <td align=center>Open_science 1</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>24</td>
 <td align=center>2.40</td>
 <td align=center>115.2</td>
 <td align=center>Melbourne, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2097">(2097) More</a></td>
 <td align=center>oneroot-JRM</td>
 <td align=center>oneroot</td>
 <td align=center>Other</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>28.8</td>
 <td align=center>Bauru, São Paulo - Brasil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2096">(2096) More</a></td>
 <td align=center>AIT DTS compute cluster</td>
 <td align=center>AIT Austrian Institute of Technology</td>
 <td align=center>EM64T-4</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>204.8</td>
 <td align=center>Vienna</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2095">(2095) More</a></td>
 <td align=center>hpc.csuft.edu.cn</td>
 <td align=center>Central South University of Forestry & Technology</td>
 <td align=center>Athlon MP</td>
 <td align=center>8</td>
 <td align=center>3.00</td>
 <td align=center>48</td>
 <td align=center>Changsha China</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2094">(2094) More</a></td>
 <td align=center>yfhix</td>
 <td align=center>Fritz-Haber-Institut</td>
 <td align=center>Other</td>
 <td align=center>772</td>
 <td align=center>2.20</td>
 <td align=center>1698.4</td>
 <td align=center>Berlin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2092">(2092) More</a></td>
 <td align=center>octopus100</td>
 <td align=center>UBI</td>
 <td align=center>EM64T-4</td>
 <td align=center>100</td>
 <td align=center>2.40</td>
 <td align=center>960</td>
 <td align=center>Covilha</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2091">(2091) More</a></td>
 <td align=center>ilia.556</td>
 <td align=center>multyplayer.ucoz.com</td>
 <td align=center>EM64T-8</td>
 <td align=center>556556</td>
 <td align=center>1.80</td>
 <td align=center>8014406.4</td>
 <td align=center> "San Diego"</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2090">(2090) More</a></td>
 <td align=center>Nanolab HPC Cluster (ECE-NITKKR)</td>
 <td align=center>National Institute of Technology, Kurukshetra-India</td>
 <td align=center>Other</td>
 <td align=center>144</td>
 <td align=center>2.60</td>
 <td align=center>374.4</td>
 <td align=center>ECE Department, NIT Kurukshetra, Haryana-India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2087">(2087) More</a></td>
 <td align=center>PMD-HPC</td>
 <td align=center>Pakistan Meteorological Department</td>
 <td align=center>Other</td>
 <td align=center>256</td>
 <td align=center>3.33</td>
 <td align=center>852.48</td>
 <td align=center>Islamabad Pakistan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2086">(2086) More</a></td>
 <td align=center>Casterlan - Frodo</td>
 <td align=center>Private</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Knoxville</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2084">(2084) More</a></td>
 <td align=center>Shimano</td>
 <td align=center>TAU</td>
 <td align=center>Other</td>
 <td align=center>80</td>
 <td align=center>2.80</td>
 <td align=center>224</td>
 <td align=center>Israel</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2083">(2083) More</a></td>
 <td align=center>Optimus-Cluster</td>
 <td align=center>Prince of Songkla University</td>
 <td align=center>Unspecified</td>
 <td align=center>24</td>
 <td align=center>3.20</td>
 <td align=center>76.8</td>
 <td align=center>Songkhla</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2082">(2082) More</a></td>
 <td align=center>Mount</td>
 <td align=center>HSIM - East Carolina University</td>
 <td align=center>EM64T-8</td>
 <td align=center>64</td>
 <td align=center>2.60</td>
 <td align=center>1331.2</td>
 <td align=center>Greenville, NC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2081">(2081) More</a></td>
 <td align=center>GRAPES3.CRL</td>
 <td align=center>CRL - TIFR</td>
 <td align=center>EM64T-4</td>
 <td align=center>1280</td>
 <td align=center>2.00</td>
 <td align=center>10240</td>
 <td align=center>OOTY, INDIA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2080">(2080) More</a></td>
 <td align=center>isiseHPC</td>
 <td align=center>ISISE</td>
 <td align=center>Other</td>
 <td align=center>72</td>
 <td align=center>2.80</td>
 <td align=center>201.6</td>
 <td align=center>Coimbra</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2079">(2079) More</a></td>
 <td align=center>SPRAGEA</td>
 <td align=center>AZTI</td>
 <td align=center>EM64T-8</td>
 <td align=center>36</td>
 <td align=center>2.70</td>
 <td align=center>777.6</td>
 <td align=center>Bilbao</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2076">(2076) More</a></td>
 <td align=center>Rocks 5.3 (Rolled Tacos) for Linux</td>
 <td align=center>cui</td>
 <td align=center>Pentium</td>
 <td align=center>1</td>
 <td align=center>60.00</td>
 <td align=center>60</td>
 <td align=center>toluca</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2075">(2075) More</a></td>
 <td align=center>Cluster GRH</td>
 <td align=center>RTA</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>36</td>
 <td align=center>Jonquiere</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2074">(2074) More</a></td>
 <td align=center>Apollo-Cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Athlon 64</td>
 <td align=center>42</td>
 <td align=center>3.20</td>
 <td align=center>268.8</td>
 <td align=center>Montreal</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2073">(2073) More</a></td>
 <td align=center>Cluster LACECI</td>
 <td align=center>LACECI</td>
 <td align=center>EM64T-4</td>
 <td align=center>8</td>
 <td align=center>3.55</td>
 <td align=center>113.6</td>
 <td align=center>Mexico City</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2072">(2072) More</a></td>
 <td align=center>allbt-cluster</td>
 <td align=center>ALLBT</td>
 <td align=center>Other</td>
 <td align=center>400</td>
 <td align=center>2.60</td>
 <td align=center>1040</td>
 <td align=center>South Korea</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2071">(2071) More</a></td>
 <td align=center>Proyecto Andrumx</td>
 <td align=center>Desarrollo e innovación IT.</td>
 <td align=center>EM64T-4</td>
 <td align=center>84</td>
 <td align=center>4.10</td>
 <td align=center>1377.6</td>
 <td align=center>Mexico City</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2070">(2070) More</a></td>
 <td align=center>XLL-Cluster</td>
 <td align=center>Xcelris Labs Limited</td>
 <td align=center>Opteron</td>
 <td align=center>124</td>
 <td align=center>2.40</td>
 <td align=center>595.2</td>
 <td align=center>Ahmedabad, Gujarat, India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2069">(2069) More</a></td>
 <td align=center>prometeo</td>
 <td align=center>Universidad Politécnica de Altamira</td>
 <td align=center>EM64T-8</td>
 <td align=center>48</td>
 <td align=center>3.40</td>
 <td align=center>1305.6</td>
 <td align=center>Altamira, Tamaulipas, México</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2068">(2068) More</a></td>
 <td align=center>CasjaysDev</td>
 <td align=center>Casjays Developments</td>
 <td align=center>EM64T-8</td>
 <td align=center>24</td>
 <td align=center>3.16</td>
 <td align=center>606.72</td>
 <td align=center>Cohoes, NY</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2067">(2067) More</a></td>
 <td align=center>IIITD Cluster</td>
 <td align=center>IIITD Delhi</td>
 <td align=center>Other</td>
 <td align=center>160</td>
 <td align=center>2.50</td>
 <td align=center>400</td>
 <td align=center>Delhi,India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2066">(2066) More</a></td>
 <td align=center>claster</td>
 <td align=center>XR</td>
 <td align=center>Other</td>
 <td align=center>2</td>
 <td align=center>2.00</td>
 <td align=center>4</td>
 <td align=center>Chel</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2064">(2064) More</a></td>
 <td align=center>CAR Caribe</td>
 <td align=center>UCAB Guayana</td>
 <td align=center>Other</td>
 <td align=center>24</td>
 <td align=center>3.00</td>
 <td align=center>72</td>
 <td align=center>Ciudad Guayana</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2061">(2061) More</a></td>
 <td align=center>XZMD HPC cluster</td>
 <td align=center>School of Physics, University of Chinese Academy of Sciences</td>
 <td align=center>EM64T</td>
 <td align=center>1128</td>
 <td align=center>2.00</td>
 <td align=center>4512</td>
 <td align=center>Beijing, China</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2060">(2060) More</a></td>
 <td align=center>Sholler Research Cluster</td>
 <td align=center>Spectrum Health</td>
 <td align=center>EM64T-4</td>
 <td align=center>408</td>
 <td align=center>2.66</td>
 <td align=center>4341.12</td>
 <td align=center>Grand Rapids, MI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2059">(2059) More</a></td>
 <td align=center>thunder.internal</td>
 <td align=center>Spectrum Health.org</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>2.40</td>
 <td align=center>192</td>
 <td align=center>Grand Rapids, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2055">(2055) More</a></td>
 <td align=center>chimera.che</td>
 <td align=center>Univeristy of Cape Town</td>
 <td align=center>EM64T</td>
 <td align=center>266</td>
 <td align=center>1.60</td>
 <td align=center>851.2</td>
 <td align=center>Cape Town, South Africa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2054">(2054) More</a></td>
 <td align=center>cluster-3.hcmiu.edu.vn</td>
 <td align=center>International University</td>
 <td align=center>Pentium 4</td>
 <td align=center>200</td>
 <td align=center>2.40</td>
 <td align=center>960</td>
 <td align=center>Ho Chi Minh City, Vietnam</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2053">(2053) More</a></td>
 <td align=center>chimera.che</td>
 <td align=center>Univeristy of Cape Town</td>
 <td align=center>EM64T</td>
 <td align=center>266</td>
 <td align=center>1.60</td>
 <td align=center>851.2</td>
 <td align=center>Cape Town, South Africa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2052">(2052) More</a></td>
 <td align=center>chimera.che</td>
 <td align=center>Univeristy of Cape Town</td>
 <td align=center>EM64T</td>
 <td align=center>266</td>
 <td align=center>1.60</td>
 <td align=center>851.2</td>
 <td align=center>Cape Town, South Africa</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2051">(2051) More</a></td>
 <td align=center>HAZ</td>
 <td align=center>private</td>
 <td align=center>EM64T-4</td>
 <td align=center>120</td>
 <td align=center>3.40</td>
 <td align=center>1632</td>
 <td align=center>Riyadh</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2050">(2050) More</a></td>
 <td align=center>EDB-Calc</td>
 <td align=center>Laboratoire Evolution et Diversité Biologique CNRS / UPS / ENFA</td>
 <td align=center>EM64T-8</td>
 <td align=center>104</td>
 <td align=center>2.10</td>
 <td align=center>1747.2</td>
 <td align=center>Toulouse</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2049">(2049) More</a></td>
 <td align=center>Bigfoot</td>
 <td align=center>ICBMS-UMR5246 (CNRS/Université Lyon 1)</td>
 <td align=center>EM64T</td>
 <td align=center>224</td>
 <td align=center>2.20</td>
 <td align=center>985.6</td>
 <td align=center>Villeurbanne</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2048">(2048) More</a></td>
 <td align=center>Cluster-2.hcmiu.edu.vn</td>
 <td align=center>International University</td>
 <td align=center>Other</td>
 <td align=center>5</td>
 <td align=center>1.80</td>
 <td align=center>9</td>
 <td align=center>HCMCity, VietNam</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2047">(2047) More</a></td>
 <td align=center>franklin</td>
 <td align=center>CorpoGen</td>
 <td align=center>Other</td>
 <td align=center>8</td>
 <td align=center>2.30</td>
 <td align=center>18.4</td>
 <td align=center>Bogota, Colombia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2046">(2046) More</a></td>
 <td align=center>THM Rocks</td>
 <td align=center>THM -  University of Applied Sciences</td>
 <td align=center>EM64T-8</td>
 <td align=center>404</td>
 <td align=center>2.00</td>
 <td align=center>6464</td>
 <td align=center>Giessen</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2044">(2044) More</a></td>
 <td align=center>Cluster-1.hcmiu.edu.vn</td>
 <td align=center>International University</td>
 <td align=center>Pentium 4</td>
 <td align=center>50</td>
 <td align=center>3.00</td>
 <td align=center>300</td>
 <td align=center>HCMCity, VietNam</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2042">(2042) More</a></td>
 <td align=center>CSM</td>
 <td align=center>Louisiana State University</td>
 <td align=center>Unspecified</td>
 <td align=center>10</td>
 <td align=center>3.40</td>
 <td align=center>34</td>
 <td align=center>Baton Rouge</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2041">(2041) More</a></td>
 <td align=center>1337built Cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>18</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2040">(2040) More</a></td>
 <td align=center>Applied Cognitive Sciences</td>
 <td align=center>Naval Health Research Center</td>
 <td align=center>Opteron</td>
 <td align=center>84</td>
 <td align=center>2.30</td>
 <td align=center>386.4</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2039">(2039) More</a></td>
 <td align=center>zx3</td>
 <td align=center>riffa club of hpc </td>
 <td align=center>Other</td>
 <td align=center>128</td>
 <td align=center>3.70</td>
 <td align=center>473.6</td>
 <td align=center>bahrain ar riffa </td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2038">(2038) More</a></td>
 <td align=center>ClusterDJN</td>
 <td align=center>DJN</td>
 <td align=center>EM64T</td>
 <td align=center>6</td>
 <td align=center>2.80</td>
 <td align=center>33.6</td>
 <td align=center>New Jersey</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2037">(2037) More</a></td>
 <td align=center>TESTKS</td>
 <td align=center>kenshoo</td>
 <td align=center>Unspecified</td>
 <td align=center>8</td>
 <td align=center>2.50</td>
 <td align=center>20</td>
 <td align=center>NJ</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2036">(2036) More</a></td>
 <td align=center>Daniel2</td>
 <td align=center>Instituto de Fisica, UASLP</td>
 <td align=center>Opteron</td>
 <td align=center>224</td>
 <td align=center>1.40</td>
 <td align=center>627.2</td>
 <td align=center>San Luis Potosi, SLP. Mexico</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2035">(2035) More</a></td>
 <td align=center>dsivchev_1</td>
 <td align=center>Cisco</td>
 <td align=center>EM64T-8</td>
 <td align=center>4</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2034">(2034) More</a></td>
 <td align=center>HIMOBS</td>
 <td align=center>Technical University of Madrid</td>
 <td align=center>Opteron</td>
 <td align=center>82</td>
 <td align=center>2.00</td>
 <td align=center>328</td>
 <td align=center>Madrid</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2033">(2033) More</a></td>
 <td align=center>rocks</td>
 <td align=center>IFUSP</td>
 <td align=center>Other</td>
 <td align=center>8</td>
 <td align=center>2.40</td>
 <td align=center>19.2</td>
 <td align=center>Sao Paulo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2032">(2032) More</a></td>
 <td align=center>Kelvin</td>
 <td align=center>Bose Institute, India</td>
 <td align=center>Other</td>
 <td align=center>272</td>
 <td align=center>2.60</td>
 <td align=center>707.2</td>
 <td align=center>Kolkata</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2030">(2030) More</a></td>
 <td align=center>ohirohiro</td>
 <td align=center>Universidad de Valparaíso</td>
 <td align=center>Opteron</td>
 <td align=center>152</td>
 <td align=center>2.10</td>
 <td align=center>638.4</td>
 <td align=center>Valparaíso</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2029">(2029) More</a></td>
 <td align=center>zuopiezi</td>
 <td align=center>yoodo</td>
 <td align=center>EM64T-4</td>
 <td align=center>8</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>beijing</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2028">(2028) More</a></td>
 <td align=center>admin</td>
 <td align=center>1</td>
 <td align=center>Pentium</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>1.8</td>
 <td align=center>sdsc</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2026">(2026) More</a></td>
 <td align=center>ClusterRocks_UTE</td>
 <td align=center>Universidad Tecnológica Equinoccial</td>
 <td align=center>Other</td>
 <td align=center>10</td>
 <td align=center>2.20</td>
 <td align=center>22</td>
 <td align=center>Quito</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2025">(2025) More</a></td>
 <td align=center>meigetsu</td>
 <td align=center>Université Lille1 - CNRS</td>
 <td align=center>EM64T</td>
 <td align=center>476</td>
 <td align=center>2.70</td>
 <td align=center>2570.4</td>
 <td align=center>Lille, France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2024">(2024) More</a></td>
 <td align=center>fondsol</td>
 <td align=center>Université Lille1 - CNRS</td>
 <td align=center>EM64T</td>
 <td align=center>128</td>
 <td align=center>2.70</td>
 <td align=center>691.2</td>
 <td align=center>Lille, France</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2023">(2023) More</a></td>
 <td align=center>AlphaCluster</td>
 <td align=center>UFO</td>
 <td align=center>Other</td>
 <td align=center>14</td>
 <td align=center>2.30</td>
 <td align=center>32.2</td>
 <td align=center>Teresina</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2022">(2022) More</a></td>
 <td align=center>Cluster LIneA</td>
 <td align=center>Laboratorio Inteinstitucional de e-Astronomia</td>
 <td align=center>EM64T-8</td>
 <td align=center>84</td>
 <td align=center>2.60</td>
 <td align=center>1747.2</td>
 <td align=center>Rio de Janeiro</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2020">(2020) More</a></td>
 <td align=center>Hyper-Clus</td>
 <td align=center>UANL - CIIDIT</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>1.60</td>
 <td align=center>25.6</td>
 <td align=center>Apodaca, Nuevo Leon, México</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2019">(2019) More</a></td>
 <td align=center>HBAR</td>
 <td align=center>W&L</td>
 <td align=center>Pentium 4</td>
 <td align=center>216</td>
 <td align=center>2.93</td>
 <td align=center>1265.76</td>
 <td align=center>Virginia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2018">(2018) More</a></td>
 <td align=center>machine</td>
 <td align=center>home</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>3.20</td>
 <td align=center>12.8</td>
 <td align=center>canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2017">(2017) More</a></td>
 <td align=center>FRT-Cluster</td>
 <td align=center>diastech.info</td>
 <td align=center>EM64T</td>
 <td align=center>9</td>
 <td align=center>2.80</td>
 <td align=center>50.4</td>
 <td align=center>Salto/SP</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2015">(2015) More</a></td>
 <td align=center>ACSL</td>
 <td align=center>Naval Health Research Center</td>
 <td align=center>Opteron</td>
 <td align=center>72</td>
 <td align=center>2.40</td>
 <td align=center>345.6</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2014">(2014) More</a></td>
 <td align=center>HPCx</td>
 <td align=center>UCLM</td>
 <td align=center>EM64T-8</td>
 <td align=center>28</td>
 <td align=center>2.30</td>
 <td align=center>515.2</td>
 <td align=center>Ciudad Real</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2011">(2011) More</a></td>
 <td align=center>Rocks-Oskar</td>
 <td align=center>N/A</td>
 <td align=center>Other</td>
 <td align=center>24</td>
 <td align=center>1.80</td>
 <td align=center>43.2</td>
 <td align=center>Scottsboro, AL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2010">(2010) More</a></td>
 <td align=center>attractor</td>
 <td align=center>Universidad Antonio Narino</td>
 <td align=center>Other</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>14.4</td>
 <td align=center>Bogota</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2008">(2008) More</a></td>
 <td align=center>supercom</td>
 <td align=center>Sant Gadge Baba Amravati University</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>36</td>
 <td align=center>Amravati, Maharashtra, India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2006">(2006) More</a></td>
 <td align=center>s</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>36</td>
 <td align=center>Amravati, India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2005">(2005) More</a></td>
 <td align=center>lzchen</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>2.80</td>
 <td align=center>11.2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2004">(2004) More</a></td>
 <td align=center>chenzhan1417</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>2.80</td>
 <td align=center>11.2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2003">(2003) More</a></td>
 <td align=center>BRC-Hyper</td>
 <td align=center>The University of Queensland</td>
 <td align=center>Other</td>
 <td align=center>48</td>
 <td align=center>2.67</td>
 <td align=center>128.16</td>
 <td align=center>Brisbane</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2002">(2002) More</a></td>
 <td align=center>hnkler</td>
 <td align=center>Central South University of Forestry & Technology</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>2.60</td>
 <td align=center>52</td>
 <td align=center>Changsha, Hunan, P.R.C.</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=2001">(2001) More</a></td>
 <td align=center>cz171</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>2.80</td>
 <td align=center>11.2</td>
 <td align=center>New Jersy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2000">(2000) More</a></td>
 <td align=center>Serenity</td>
 <td align=center>University of Memphis Feinstone Center for Genomic Research</td>
 <td align=center>Opteron</td>
 <td align=center>104</td>
 <td align=center>2.60</td>
 <td align=center>540.8</td>
 <td align=center>Memphis, TN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1999">(1999) More</a></td>
 <td align=center>ZHAN CHEN</td>
 <td align=center>ECE</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>2.80</td>
 <td align=center>11.2</td>
 <td align=center>Piscataway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1998">(1998) More</a></td>
 <td align=center>DOM</td>
 <td align=center>MyTOTOE Network</td>
 <td align=center>EM64T-8</td>
 <td align=center>31</td>
 <td align=center>66.03</td>
 <td align=center>16375.44</td>
 <td align=center>Surin, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1997">(1997) More</a></td>
 <td align=center>mcccafe</td>
 <td align=center>ViosLab</td>
 <td align=center>Other</td>
 <td align=center>2</td>
 <td align=center>1.80</td>
 <td align=center>3.6</td>
 <td align=center>Taiwan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1996">(1996) More</a></td>
 <td align=center>swerlcluster-rams</td>
 <td align=center>swerl-rcee TSU</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.60</td>
 <td align=center>332.8</td>
 <td align=center>Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1995">(1995) More</a></td>
 <td align=center>swerlcluster-wrf</td>
 <td align=center>swerl-rcee tsu</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.60</td>
 <td align=center>332.8</td>
 <td align=center>phatthalung</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1994">(1994) More</a></td>
 <td align=center>CentosCarif</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>3.40</td>
 <td align=center>13.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1993">(1993) More</a></td>
 <td align=center>Physics Cluster</td>
 <td align=center>GUFBS</td>
 <td align=center>EM64T-8</td>
 <td align=center>52</td>
 <td align=center>3.40</td>
 <td align=center>1414.4</td>
 <td align=center>Rasht - Guilan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1992">(1992) More</a></td>
 <td align=center>CLUSTER CUDA CPTEC/DSA</td>
 <td align=center>INPE</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>3.40</td>
 <td align=center>870.4</td>
 <td align=center>Cachoeira Paulista - São Paulo</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1990">(1990) More</a></td>
 <td align=center>ececluster</td>
 <td align=center>Rutgers University / Dept ECE</td>
 <td align=center>EM64T</td>
 <td align=center>20</td>
 <td align=center>1.80</td>
 <td align=center>72</td>
 <td align=center>Piscataway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1989">(1989) More</a></td>
 <td align=center>HPC-core.um.si</td>
 <td align=center>University of Maribor</td>
 <td align=center>EM64T-8</td>
 <td align=center>240</td>
 <td align=center>2.60</td>
 <td align=center>4992</td>
 <td align=center>Slovenija</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1988">(1988) More</a></td>
 <td align=center>illice</td>
 <td align=center>UWICORE - University Miguel Hernandez</td>
 <td align=center>EM64T-4</td>
 <td align=center>132</td>
 <td align=center>2.66</td>
 <td align=center>1404.48</td>
 <td align=center>Elche, Spain</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1987">(1987) More</a></td>
 <td align=center>CfN Rocks Cluster</td>
 <td align=center>Univ. of Pennsylvania</td>
 <td align=center>EM64T-4</td>
 <td align=center>304</td>
 <td align=center>2.10</td>
 <td align=center>2553.6</td>
 <td align=center>Philadelphia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1986">(1986) More</a></td>
 <td align=center>Hera-UW-AOS</td>
 <td align=center>UW-Madison Dept Atmos. & Oceanic Sci.</td>
 <td align=center>Other</td>
 <td align=center>48</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>Madison, WI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1985">(1985) More</a></td>
 <td align=center>Cluster Mazorkita Xanini</td>
 <td align=center>Cinvestav Langebio</td>
 <td align=center>EM64T</td>
 <td align=center>66</td>
 <td align=center>2.50</td>
 <td align=center>330</td>
 <td align=center>Guanajuato, México</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1984">(1984) More</a></td>
 <td align=center>serrano</td>
 <td align=center>Institute of PEtroleum Engineering</td>
 <td align=center>Opteron</td>
 <td align=center>240</td>
 <td align=center>2.60</td>
 <td align=center>1248</td>
 <td align=center>Edinburgh, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1983">(1983) More</a></td>
 <td align=center>Rocks_Cluster-01</td>
 <td align=center>GE Power & Water</td>
 <td align=center>EM64T</td>
 <td align=center>26</td>
 <td align=center>2.80</td>
 <td align=center>145.6</td>
 <td align=center>Melbourne, FL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1982">(1982) More</a></td>
 <td align=center>many</td>
 <td align=center>sysu</td>
 <td align=center>EM64T</td>
 <td align=center>1</td>
 <td align=center>1.50</td>
 <td align=center>3</td>
 <td align=center>guangzhou</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1981">(1981) More</a></td>
 <td align=center>KANGSAVATI</td>
 <td align=center>Indian Institute Of Technology</td>
 <td align=center>EM64T-8</td>
 <td align=center>352</td>
 <td align=center>2.90</td>
 <td align=center>8166.4</td>
 <td align=center>India, Westbengal, Kharagpur</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1980">(1980) More</a></td>
 <td align=center>BezootZoots!</td>
 <td align=center>BezooomyInc</td>
 <td align=center>Pentium</td>
 <td align=center>6</td>
 <td align=center>200.00</td>
 <td align=center>1200</td>
 <td align=center>Thanet</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1979">(1979) More</a></td>
 <td align=center>Zebu</td>
 <td align=center>UFTM</td>
 <td align=center>EM64T-4</td>
 <td align=center>144</td>
 <td align=center>3.00</td>
 <td align=center>1728</td>
 <td align=center>Uberaba, MG, Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1978">(1978) More</a></td>
 <td align=center>berrygenomics.com</td>
 <td align=center>berrygenomics</td>
 <td align=center>EM64T-8</td>
 <td align=center>5200</td>
 <td align=center>2.60</td>
 <td align=center>108160</td>
 <td align=center>Beijing China</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1977">(1977) More</a></td>
 <td align=center>Newton-UNSW</td>
 <td align=center>School of Mechanical and Manufacturing Engineering, UNSW</td>
 <td align=center>Opteron</td>
 <td align=center>160</td>
 <td align=center>3.10</td>
 <td align=center>992</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1976">(1976) More</a></td>
 <td align=center>calculon@robolabo</td>
 <td align=center>Universidad Politecnica de Madrid</td>
 <td align=center>Opteron</td>
 <td align=center>60</td>
 <td align=center>2.60</td>
 <td align=center>312</td>
 <td align=center>Madrid</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1975">(1975) More</a></td>
 <td align=center>LOACluster</td>
 <td align=center>Laboratoire d Optique Atmosphérique - UMR8518 - CNRS/Lille1</td>
 <td align=center>EM64T-8</td>
 <td align=center>336</td>
 <td align=center>2.70</td>
 <td align=center>7257.6</td>
 <td align=center>Lille, France</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1974">(1974) More</a></td>
 <td align=center>Shock@ME-IITB</td>
 <td align=center>Indian Institute of Technology Bombay</td>
 <td align=center>Pentium 4</td>
 <td align=center>24</td>
 <td align=center>3.40</td>
 <td align=center>163.2</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1973">(1973) More</a></td>
 <td align=center>Tesjo.hpc.org</td>
 <td align=center>Tecnologico de Estudios Superiores de Jocotitlan</td>
 <td align=center>Other</td>
 <td align=center>16</td>
 <td align=center>1.80</td>
 <td align=center>28.8</td>
 <td align=center>Jocotitlan,Estado de Mexico</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1972">(1972) More</a></td>
 <td align=center>meta</td>
 <td align=center>HITSZ</td>
 <td align=center>Unspecified</td>
 <td align=center>8</td>
 <td align=center>2.00</td>
 <td align=center>16</td>
 <td align=center>Shenzhen</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1971">(1971) More</a></td>
 <td align=center>FIME</td>
 <td align=center>Universidad de Colima</td>
 <td align=center>Other</td>
 <td align=center>7</td>
 <td align=center>2.20</td>
 <td align=center>15.4</td>
 <td align=center>Colima, México</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1970">(1970) More</a></td>
 <td align=center>UNA Cluster</td>
 <td align=center>Universidad Nacional</td>
 <td align=center>Other</td>
 <td align=center>22</td>
 <td align=center>2.27</td>
 <td align=center>49.94</td>
 <td align=center>Heredia, Costa Rica</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1969">(1969) More</a></td>
 <td align=center>PRI</td>
 <td align=center>PRI</td>
 <td align=center>Other</td>
 <td align=center>24</td>
 <td align=center>2.20</td>
 <td align=center>52.8</td>
 <td align=center>chennai</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1968">(1968) More</a></td>
 <td align=center>bambi</td>
 <td align=center>UTPA</td>
 <td align=center>Other</td>
 <td align=center>230</td>
 <td align=center>2.40</td>
 <td align=center>552</td>
 <td align=center>Edinburg, Texas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1967">(1967) More</a></td>
 <td align=center>Odie</td>
 <td align=center>UW Madison - Materials Science Program</td>
 <td align=center>Unspecified</td>
 <td align=center>16</td>
 <td align=center>2.10</td>
 <td align=center>33.6</td>
 <td align=center>Madison WI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1966">(1966) More</a></td>
 <td align=center>Magma</td>
 <td align=center>CSRI</td>
 <td align=center>Other</td>
 <td align=center>36</td>
 <td align=center>2.66</td>
 <td align=center>95.76</td>
 <td align=center>Athens, Greece</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1965">(1965) More</a></td>
 <td align=center>beaked.fau.edu</td>
 <td align=center>FAU</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>2.40</td>
 <td align=center>38.4</td>
 <td align=center>Boca Raton</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1964">(1964) More</a></td>
 <td align=center>cluster1awt</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>72</td>
 <td align=center>2.50</td>
 <td align=center>180</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1963">(1963) More</a></td>
 <td align=center>rock mail</td>
 <td align=center>saratsis</td>
 <td align=center>Pentium</td>
 <td align=center>2</td>
 <td align=center>2.20</td>
 <td align=center>4.4</td>
 <td align=center>timisoara</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1962">(1962) More</a></td>
 <td align=center>naveeth</td>
 <td align=center>mipl</td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>2.80</td>
 <td align=center>8.4</td>
 <td align=center>india</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1961">(1961) More</a></td>
 <td align=center>Superior</td>
 <td align=center>Michigan Technological University</td>
 <td align=center>EM64T-8</td>
 <td align=center>1488</td>
 <td align=center>2.60</td>
 <td align=center>30950.4</td>
 <td align=center>Houghton, Michigan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1960">(1960) More</a></td>
 <td align=center>Rocks Cluster</td>
 <td align=center>Sant Gadge Babe Amravati University</td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>3.00</td>
 <td align=center>9</td>
 <td align=center>Amravati, India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1959">(1959) More</a></td>
 <td align=center>salam</td>
 <td align=center>asas</td>
 <td align=center>Athlon XP</td>
 <td align=center>1</td>
 <td align=center>1.40</td>
 <td align=center>2.8</td>
 <td align=center>sa asa</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1958">(1958) More</a></td>
 <td align=center>nikola</td>
 <td align=center>Clark Atlanta University</td>
 <td align=center>Unspecified</td>
 <td align=center>24</td>
 <td align=center>2.66</td>
 <td align=center>63.84</td>
 <td align=center>Atlanta, Georgia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1957">(1957) More</a></td>
 <td align=center>clustertesttlx</td>
 <td align=center>totalinux</td>
 <td align=center>EM64T-4</td>
 <td align=center>2</td>
 <td align=center>2.00</td>
 <td align=center>16</td>
 <td align=center>jouy en josas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1956">(1956) More</a></td>
 <td align=center>master-hpc-mox</td>
 <td align=center>Universidad de los Andes</td>
 <td align=center>Unspecified</td>
 <td align=center>700</td>
 <td align=center>2.60</td>
 <td align=center>1820</td>
 <td align=center>Colombia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1955">(1955) More</a></td>
 <td align=center>Academics-CIRP-Cluster</td>
 <td align=center>CIRP USP</td>
 <td align=center>EM64T</td>
 <td align=center>56</td>
 <td align=center>3.50</td>
 <td align=center>392</td>
 <td align=center>São Paulo</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1954">(1954) More</a></td>
 <td align=center>Nymeria</td>
 <td align=center>Wuhan University</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>1.15</td>
 <td align=center>4.6</td>
 <td align=center>China</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1953">(1953) More</a></td>
 <td align=center>Electron-hpc</td>
 <td align=center>RLIMD^3 -- TSU</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>2.80</td>
 <td align=center>224</td>
 <td align=center>Songkhla, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1952">(1952) More</a></td>
 <td align=center>prodatacluster01</td>
 <td align=center>RGSNet</td>
 <td align=center>Other</td>
 <td align=center>1</td>
 <td align=center>3.00</td>
 <td align=center>3</td>
 <td align=center>sao paulo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1951">(1951) More</a></td>
 <td align=center>Auburn GridIron</td>
 <td align=center>Auburn University</td>
 <td align=center>EM64T-8</td>
 <td align=center>256</td>
 <td align=center>2.70</td>
 <td align=center>5529.6</td>
 <td align=center>Auburn, AL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1950">(1950) More</a></td>
 <td align=center>Reliant</td>
 <td align=center>Iowa State University</td>
 <td align=center>EM64T-4</td>
 <td align=center>104</td>
 <td align=center>2.93</td>
 <td align=center>1218.88</td>
 <td align=center>Ames, IA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1949">(1949) More</a></td>
 <td align=center>Excelsior</td>
 <td align=center>Iowa State University</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.00</td>
 <td align=center>512</td>
 <td align=center>Ames, IA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1948">(1948) More</a></td>
 <td align=center>HPCIFISUR</td>
 <td align=center>IFISUR CONICET</td>
 <td align=center>Other</td>
 <td align=center>36</td>
 <td align=center>1.60</td>
 <td align=center>57.6</td>
 <td align=center>Bahía Blanca</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1947">(1947) More</a></td>
 <td align=center>CEG-NGS_CLUSTER</td>
 <td align=center>Newcastle University</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.90</td>
 <td align=center>15.6</td>
 <td align=center>UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1946">(1946) More</a></td>
 <td align=center>cluster-laar</td>
 <td align=center>USTO</td>
 <td align=center>Unspecified</td>
 <td align=center>68</td>
 <td align=center>3.40</td>
 <td align=center>231.2</td>
 <td align=center>ORAN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1945">(1945) More</a></td>
 <td align=center>testskif</td>
 <td align=center>lol</td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>1.80</td>
 <td align=center>5.4</td>
 <td align=center>lol</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1944">(1944) More</a></td>
 <td align=center>ABOUCluster</td>
 <td align=center> Lille 3</td>
 <td align=center>Unspecified</td>
 <td align=center>32</td>
 <td align=center>4.00</td>
 <td align=center>128</td>
 <td align=center>France </td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1943">(1943) More</a></td>
 <td align=center>RCEEclustertsu</td>
 <td align=center>RCEE</td>
 <td align=center>Unspecified</td>
 <td align=center>32</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1942">(1942) More</a></td>
 <td align=center>Canis Latrans</td>
 <td align=center>Nebraska Wesleyan University</td>
 <td align=center>Opteron</td>
 <td align=center>104</td>
 <td align=center>2.80</td>
 <td align=center>582.4</td>
 <td align=center>Lincoln, NE</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1941">(1941) More</a></td>
 <td align=center>swerl</td>
 <td align=center>TSU</td>
 <td align=center>Pentium 4</td>
 <td align=center>36</td>
 <td align=center>2.30</td>
 <td align=center>165.6</td>
 <td align=center>Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1939">(1939) More</a></td>
 <td align=center>ililminatiBox</td>
 <td align=center>Conclusão de Curso IFPB</td>
 <td align=center>Unspecified</td>
 <td align=center>4</td>
 <td align=center>2.40</td>
 <td align=center>9.6</td>
 <td align=center>Alagoa Nova</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1938">(1938) More</a></td>
 <td align=center>Nanoheat</td>
 <td align=center>Iowa State University</td>
 <td align=center>Athlon 64</td>
 <td align=center>56</td>
 <td align=center>2.40</td>
 <td align=center>268.8</td>
 <td align=center>Ames, IA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1937">(1937) More</a></td>
 <td align=center>cndltest</td>
 <td align=center>cntv</td>
 <td align=center>EM64T</td>
 <td align=center>1</td>
 <td align=center>2.26</td>
 <td align=center>4.52</td>
 <td align=center>china</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1936">(1936) More</a></td>
 <td align=center>Andromeda</td>
 <td align=center>Kitware, Inc</td>
 <td align=center>EM64T-8</td>
 <td align=center>256</td>
 <td align=center>2.60</td>
 <td align=center>5324.8</td>
 <td align=center>Clifton Park, NY</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1935">(1935) More</a></td>
 <td align=center>art</td>
 <td align=center>Advanced Visualization Lab, NCSA, U of Illinois</td>
 <td align=center>EM64T</td>
 <td align=center>48</td>
 <td align=center>3.00</td>
 <td align=center>288</td>
 <td align=center>Urbana, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1934">(1934) More</a></td>
 <td align=center>Molekylära Mekanik Kluster</td>
 <td align=center>Stockholms Universitet</td>
 <td align=center>Opteron</td>
 <td align=center>256</td>
 <td align=center>2.40</td>
 <td align=center>1228.8</td>
 <td align=center>Stockholm, Sweden</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1932">(1932) More</a></td>
 <td align=center>Zahid NUST Cluster</td>
 <td align=center>National University of Sciences and Technology (NUST)</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.30</td>
 <td align=center>26.4</td>
 <td align=center>Islamabad, Pakistan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1930">(1930) More</a></td>
 <td align=center>wigner.research.mtu.edu</td>
 <td align=center>Michigan Technological University</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.00</td>
 <td align=center>512</td>
 <td align=center>Houghton, Michigan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1929">(1929) More</a></td>
 <td align=center>LISA</td>
 <td align=center>CADD Laboratory, Faculty of Pharmacy</td>
 <td align=center>EM64T-4</td>
 <td align=center>16</td>
 <td align=center>2.53</td>
 <td align=center>161.92</td>
 <td align=center>Bratislava, Slovakia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1928">(1928) More</a></td>
 <td align=center>CIMeC CLIC Cluster 4</td>
 <td align=center>CIMeC - University of Trento</td>
 <td align=center>Opteron</td>
 <td align=center>336</td>
 <td align=center>2.10</td>
 <td align=center>1411.2</td>
 <td align=center>Rovereto TN - Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1927">(1927) More</a></td>
 <td align=center>Time Travel One</td>
 <td align=center>Time Travel Institute</td>
 <td align=center>Athlon 64</td>
 <td align=center>16</td>
 <td align=center>4.10</td>
 <td align=center>131.2</td>
 <td align=center>Little Rock</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1926">(1926) More</a></td>
 <td align=center>swerlcluster</td>
 <td align=center>tsu</td>
 <td align=center>Other</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>14.4</td>
 <td align=center>Phatthalung</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1925">(1925) More</a></td>
 <td align=center>Trentino</td>
 <td align=center>School of Mechanical and Manufacturing Engineering, UNSW</td>
 <td align=center>Opteron</td>
 <td align=center>1024</td>
 <td align=center>2.10</td>
 <td align=center>4300.8</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1924">(1924) More</a></td>
 <td align=center>Leonardi</td>
 <td align=center>Faculty of Engineering, UNSW</td>
 <td align=center>Opteron</td>
 <td align=center>2968</td>
 <td align=center>2.20</td>
 <td align=center>13059.2</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1923">(1923) More</a></td>
 <td align=center>Rocks.Blue</td>
 <td align=center>Personal</td>
 <td align=center>Itanium</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>57.6</td>
 <td align=center>Home</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1922">(1922) More</a></td>
 <td align=center>Ascar</td>
 <td align=center>Texas Water Development Board</td>
 <td align=center>Unspecified</td>
 <td align=center>166</td>
 <td align=center>0.80</td>
 <td align=center>132.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1921">(1921) More</a></td>
 <td align=center>cluster.WDC.ISD2155</td>
 <td align=center>WDC</td>
 <td align=center>Pentium 4</td>
 <td align=center>48</td>
 <td align=center>2.40</td>
 <td align=center>230.4</td>
 <td align=center>Wadena, MN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1920">(1920) More</a></td>
 <td align=center>Bodrug</td>
 <td align=center>unasm</td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>2.70</td>
 <td align=center>8.1</td>
 <td align=center>chisinau</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1919">(1919) More</a></td>
 <td align=center>Zambezi</td>
 <td align=center>Marquette University</td>
 <td align=center>Pentium 4</td>
 <td align=center>22</td>
 <td align=center>2.99</td>
 <td align=center>131.56</td>
 <td align=center>Milwaukee, WI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1918">(1918) More</a></td>
 <td align=center>TOOFAN</td>
 <td align=center>alfaisal.edu</td>
 <td align=center>Athlon</td>
 <td align=center>132</td>
 <td align=center>3.60</td>
 <td align=center>475.2</td>
 <td align=center>Riyadh</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1917">(1917) More</a></td>
 <td align=center>huskers</td>
 <td align=center>HFHS</td>
 <td align=center>Opteron</td>
 <td align=center>71</td>
 <td align=center>2.59</td>
 <td align=center>367.78</td>
 <td align=center>Detroit</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1916">(1916) More</a></td>
 <td align=center>Texas Tornado</td>
 <td align=center>Texas State Technical College</td>
 <td align=center>EM64T</td>
 <td align=center>80</td>
 <td align=center>3.40</td>
 <td align=center>544</td>
 <td align=center>Waco</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1915">(1915) More</a></td>
 <td align=center>Time Travel One Station</td>
 <td align=center>Time Travel Insttiute</td>
 <td align=center>Other</td>
 <td align=center>16</td>
 <td align=center>4.10</td>
 <td align=center>65.6</td>
 <td align=center>Little Rock</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1914">(1914) More</a></td>
 <td align=center>CBG-Cluster</td>
 <td align=center>CBG-IPN</td>
 <td align=center>Opteron</td>
 <td align=center>128</td>
 <td align=center>2.10</td>
 <td align=center>537.6</td>
 <td align=center>Reynosa, Tamps, México</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1913">(1913) More</a></td>
 <td align=center>medils</td>
 <td align=center>MedILS</td>
 <td align=center>EM64T-4</td>
 <td align=center>96</td>
 <td align=center>2.00</td>
 <td align=center>768</td>
 <td align=center>Split, Croatia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1912">(1912) More</a></td>
 <td align=center>BBCSRV3</td>
 <td align=center>University of Connecticut</td>
 <td align=center>EM64T</td>
 <td align=center>144</td>
 <td align=center>2.53</td>
 <td align=center>728.64</td>
 <td align=center>Storrs, CT</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1911">(1911) More</a></td>
 <td align=center>jade.oerc.ox.ac.uk</td>
 <td align=center>Oxford University / Oxford e-Research Center</td>
 <td align=center>EM64T</td>
 <td align=center>36</td>
 <td align=center>3.20</td>
 <td align=center>230.4</td>
 <td align=center>Oxford</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1910">(1910) More</a></td>
 <td align=center>borocks</td>
 <td align=center>AWS Truepower</td>
 <td align=center>Other</td>
 <td align=center>48</td>
 <td align=center>2.20</td>
 <td align=center>105.6</td>
 <td align=center>Barcelona</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1909">(1909) More</a></td>
 <td align=center>cluster.fiberteam.com</td>
 <td align=center>Fiberteam</td>
 <td align=center>EM64T-4</td>
 <td align=center>40</td>
 <td align=center>3.40</td>
 <td align=center>544</td>
 <td align=center>Norway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1908">(1908) More</a></td>
 <td align=center>sh-Cluster</td>
 <td align=center>edu.cn</td>
 <td align=center>Opteron</td>
 <td align=center>120</td>
 <td align=center>2.00</td>
 <td align=center>480</td>
 <td align=center>shanghai</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1907">(1907) More</a></td>
 <td align=center>Phobos</td>
 <td align=center>Molecular Simulations Group, Bombay College of Pharmacy</td>
 <td align=center>EM64T</td>
 <td align=center>328</td>
 <td align=center>2.66</td>
 <td align=center>1744.96</td>
 <td align=center>Mumbai, India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1906">(1906) More</a></td>
 <td align=center>fatemeh</td>
 <td align=center>Mechanical Engineering Department</td>
 <td align=center>Other</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>18</td>
 <td align=center>Houston</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1904">(1904) More</a></td>
 <td align=center>opencluster</td>
 <td align=center>Bezooomy Inc</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>2.00</td>
 <td align=center>24</td>
 <td align=center>Thanet</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1903">(1903) More</a></td>
 <td align=center>CESE-HPCC</td>
 <td align=center>Center for Environmental Science. University of Connecticut</td>
 <td align=center>Opteron</td>
 <td align=center>128</td>
 <td align=center>2.50</td>
 <td align=center>640</td>
 <td align=center>Storrs, CT</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1902">(1902) More</a></td>
 <td align=center>msn-kku</td>
 <td align=center>Department of Physics, Faculty of Science, Khon Kaen University</td>
 <td align=center>EM64T</td>
 <td align=center>120</td>
 <td align=center>3.40</td>
 <td align=center>816</td>
 <td align=center>Khon Kaen, Thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1901">(1901) More</a></td>
 <td align=center>Karo</td>
 <td align=center>Pemkab Karo</td>
 <td align=center>Other</td>
 <td align=center>7</td>
 <td align=center>2.10</td>
 <td align=center>14.7</td>
 <td align=center>Kabanjahe-Indonesia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1900">(1900) More</a></td>
 <td align=center>habacuque</td>
 <td align=center>Infosig</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>Campinas/São Paulo - Brasil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1899">(1899) More</a></td>
 <td align=center>kafinf</td>
 <td align=center>USATU</td>
 <td align=center>Other</td>
 <td align=center>13</td>
 <td align=center>2.50</td>
 <td align=center>32.5</td>
 <td align=center>Russian</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1898">(1898) More</a></td>
 <td align=center>Rocks-TLP</td>
 <td align=center>Computer Sciences Laboratory  LIMSI-CNRS</td>
 <td align=center>EM64T-8</td>
 <td align=center>144</td>
 <td align=center>2.27</td>
 <td align=center>2615.04</td>
 <td align=center>ORSAY FRANCE</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1897">(1897) More</a></td>
 <td align=center>GMU Medusa</td>
 <td align=center>Volgenau School of engineering</td>
 <td align=center>EM64T</td>
 <td align=center>84</td>
 <td align=center>3.20</td>
 <td align=center>537.6</td>
 <td align=center>Fairfax, Virginia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1896">(1896) More</a></td>
 <td align=center>Softvision</td>
 <td align=center>svm</td>
 <td align=center>Other</td>
 <td align=center>2</td>
 <td align=center>1.80</td>
 <td align=center>3.6</td>
 <td align=center>guatemala</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1895">(1895) More</a></td>
 <td align=center>Htlab</td>
 <td align=center>SNUT</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>3.90</td>
 <td align=center>62.4</td>
 <td align=center>Seoul, Korea</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1894">(1894) More</a></td>
 <td align=center> Kerala University CCF</td>
 <td align=center>KERALA UNIVERSITY</td>
 <td align=center>EM64T-4</td>
 <td align=center>48</td>
 <td align=center>2.40</td>
 <td align=center>460.8</td>
 <td align=center>   Kerala , Kariavattom</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1893">(1893) More</a></td>
 <td align=center>radio-cluster</td>
 <td align=center>CUMC</td>
 <td align=center>EM64T-8</td>
 <td align=center>144</td>
 <td align=center>2.60</td>
 <td align=center>2995.2</td>
 <td align=center>New York</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1892">(1892) More</a></td>
 <td align=center>BornOpp</td>
 <td align=center>Brunold Research Group UW-Madison</td>
 <td align=center>Other</td>
 <td align=center>120</td>
 <td align=center>2.53</td>
 <td align=center>303.6</td>
 <td align=center>Madison, WI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1891">(1891) More</a></td>
 <td align=center>Curie</td>
 <td align=center>Major Hard Drive Mfg</td>
 <td align=center>Opteron</td>
 <td align=center>1664</td>
 <td align=center>2.60</td>
 <td align=center>8652.8</td>
 <td align=center>U.S.</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1890">(1890) More</a></td>
 <td align=center>SYSU-EGS-Cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T-4</td>
 <td align=center>176</td>
 <td align=center>2.20</td>
 <td align=center>1548.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1889">(1889) More</a></td>
 <td align=center>IBT-CLUSTER</td>
 <td align=center>MGM</td>
 <td align=center>Unspecified</td>
 <td align=center>6</td>
 <td align=center>2.40</td>
 <td align=center>14.4</td>
 <td align=center>India(MS)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1888">(1888) More</a></td>
 <td align=center>proclus</td>
 <td align=center>school of humanities and sciences</td>
 <td align=center>EM64T-8</td>
 <td align=center>1792</td>
 <td align=center>2.20</td>
 <td align=center>31539.2</td>
 <td align=center>stanford</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1887">(1887) More</a></td>
 <td align=center>Mocofato</td>
 <td align=center>Universidade Estadual de Feira de Santana</td>
 <td align=center>EM64T-4</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Feira de Santana - Bahia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1886">(1886) More</a></td>
 <td align=center>pintbob</td>
 <td align=center>private</td>
 <td align=center>Other</td>
 <td align=center>6</td>
 <td align=center>2.80</td>
 <td align=center>16.8</td>
 <td align=center>Vienna, Austria</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1885">(1885) More</a></td>
 <td align=center>Zefram</td>
 <td align=center>Institute of Physics Belgrade</td>
 <td align=center>Opteron</td>
 <td align=center>320</td>
 <td align=center>2.10</td>
 <td align=center>1344</td>
 <td align=center>Belgrade, Serbia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1884">(1884) More</a></td>
 <td align=center>vrnano</td>
 <td align=center>MMCCRG, Chulalongkorn University</td>
 <td align=center>EM64T-8</td>
 <td align=center>64</td>
 <td align=center>2.50</td>
 <td align=center>1280</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1883">(1883) More</a></td>
 <td align=center>Rocks-Lille1</td>
 <td align=center>CRI - Université Lille 1</td>
 <td align=center>EM64T-8</td>
 <td align=center>2028</td>
 <td align=center>2.60</td>
 <td align=center>42182.4</td>
 <td align=center>Lille, France</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1882">(1882) More</a></td>
 <td align=center>stronics.hpc.in</td>
 <td align=center>stronics</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>3.6</td>
 <td align=center>pune</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1881">(1881) More</a></td>
 <td align=center>BIG JIM</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T-8</td>
 <td align=center>8</td>
 <td align=center>2.33</td>
 <td align=center>149.12</td>
 <td align=center>Merseyside UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1880">(1880) More</a></td>
 <td align=center>breatheeasyclusterhead</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T-8</td>
 <td align=center>8</td>
 <td align=center>2.33</td>
 <td align=center>149.12</td>
 <td align=center>Liverpool Merseyside England UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1878">(1878) More</a></td>
 <td align=center>pacopico</td>
 <td align=center>Universitat de Girona</td>
 <td align=center>Unspecified</td>
 <td align=center>125</td>
 <td align=center>2.10</td>
 <td align=center>262.5</td>
 <td align=center>Girona, Spain</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1877">(1877) More</a></td>
 <td align=center>Lucy (JHU)</td>
 <td align=center>Johns Hopkins University</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>3.60</td>
 <td align=center>288</td>
 <td align=center>Baltimore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1876">(1876) More</a></td>
 <td align=center>Eagle Cluster</td>
 <td align=center>Universiti Sains Malaysia</td>
 <td align=center>EM64T</td>
 <td align=center>36</td>
 <td align=center>2.00</td>
 <td align=center>144</td>
 <td align=center>Penang</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1875">(1875) More</a></td>
 <td align=center>Tuna Cluster</td>
 <td align=center>Universiti Sains Malaysia</td>
 <td align=center>EM64T-8</td>
 <td align=center>32</td>
 <td align=center>2.53</td>
 <td align=center>647.68</td>
 <td align=center>Penang</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1874">(1874) More</a></td>
 <td align=center>cheetah</td>
 <td align=center>ICFO</td>
 <td align=center>Other</td>
 <td align=center>240</td>
 <td align=center>2.40</td>
 <td align=center>576</td>
 <td align=center>Spain</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1872">(1872) More</a></td>
 <td align=center>Wolfpack</td>
 <td align=center>Garvan Institute of Medical Research</td>
 <td align=center>Opteron</td>
 <td align=center>1270</td>
 <td align=center>2.60</td>
 <td align=center>6604</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1871">(1871) More</a></td>
 <td align=center>Rocks.dec.ad</td>
 <td align=center>Personal</td>
 <td align=center>Itanium 2</td>
 <td align=center>1</td>
 <td align=center>3.30</td>
 <td align=center>13.2</td>
 <td align=center>Hangzhou </td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1870">(1870) More</a></td>
 <td align=center>CCNi General Cluster #1</td>
 <td align=center>Psychology University of Glasgow</td>
 <td align=center>Opteron</td>
 <td align=center>292</td>
 <td align=center>2.30</td>
 <td align=center>1343.2</td>
 <td align=center>Glasgow, Scotland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1869">(1869) More</a></td>
 <td align=center>CCNi Parallel matlab Grid #6</td>
 <td align=center>Psychology University of Glasgow</td>
 <td align=center>Opteron</td>
 <td align=center>384</td>
 <td align=center>2.60</td>
 <td align=center>1996.8</td>
 <td align=center>Glasgow, Scotland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1868">(1868) More</a></td>
 <td align=center>CCNi Parallel matlab Grid #1</td>
 <td align=center>Psychology University of Glasgow</td>
 <td align=center>Opteron</td>
 <td align=center>192</td>
 <td align=center>2.50</td>
 <td align=center>960</td>
 <td align=center>Glasgow, Scotland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1867">(1867) More</a></td>
 <td align=center>CCNi Parallel matlab Grid #2</td>
 <td align=center>Psychology University of Glasgow</td>
 <td align=center>Opteron</td>
 <td align=center>192</td>
 <td align=center>2.50</td>
 <td align=center>960</td>
 <td align=center>Glasgow, Scotland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1866">(1866) More</a></td>
 <td align=center>CCNi Parallel matlab Grid #5</td>
 <td align=center>Psychology University of Glasgow</td>
 <td align=center>Opteron</td>
 <td align=center>192</td>
 <td align=center>2.50</td>
 <td align=center>960</td>
 <td align=center>Glasgow, Scotland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1865">(1865) More</a></td>
 <td align=center>CCNi Parallel matlab Grid #4</td>
 <td align=center>Psychology University of Glasgow</td>
 <td align=center>Opteron</td>
 <td align=center>192</td>
 <td align=center>2.50</td>
 <td align=center>960</td>
 <td align=center>Glasgow, Scotland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1864">(1864) More</a></td>
 <td align=center>CCNi Parallel matlab Grid #3</td>
 <td align=center>Psychology University of Glasgow</td>
 <td align=center>Opteron</td>
 <td align=center>192</td>
 <td align=center>2.50</td>
 <td align=center>960</td>
 <td align=center>Glasgow, Scotland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1863">(1863) More</a></td>
 <td align=center>clus1</td>
 <td align=center>tck</td>
 <td align=center>Athlon 64</td>
 <td align=center>2</td>
 <td align=center>2.67</td>
 <td align=center>10.68</td>
 <td align=center>kermanshah</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1862">(1862) More</a></td>
 <td align=center>hsdbc1</td>
 <td align=center>Loyola University Chicago Health Sciences Division</td>
 <td align=center>Pentium 4</td>
 <td align=center>256</td>
 <td align=center>2.80</td>
 <td align=center>1433.6</td>
 <td align=center>Maywood, Ill</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1861">(1861) More</a></td>
 <td align=center>TC Cluster</td>
 <td align=center>Technische Universität Braunschweig</td>
 <td align=center>EM64T-4</td>
 <td align=center>200</td>
 <td align=center>2.67</td>
 <td align=center>2136</td>
 <td align=center>Braunschweig, Germany</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1860">(1860) More</a></td>
 <td align=center>mightee.ast.uct.ac.za</td>
 <td align=center>University of Cape Town</td>
 <td align=center>Athlon 64</td>
 <td align=center>56</td>
 <td align=center>3.50</td>
 <td align=center>392</td>
 <td align=center>Cape Town, South Africa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1859">(1859) More</a></td>
 <td align=center>stronics.hpc.com</td>
 <td align=center>stronicsa</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>3.6</td>
 <td align=center>pune</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1858">(1858) More</a></td>
 <td align=center>College of Sciences and Humanities Cluster (cshcluster)</td>
 <td align=center>Ball State University</td>
 <td align=center>EM64T-8</td>
 <td align=center>512</td>
 <td align=center>2.90</td>
 <td align=center>11878.4</td>
 <td align=center>Muncie</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1857">(1857) More</a></td>
 <td align=center>Matrix Dragon</td>
 <td align=center>Key Safety Systems</td>
 <td align=center>EM64T</td>
 <td align=center>80</td>
 <td align=center>3.46</td>
 <td align=center>553.6</td>
 <td align=center>Raunheim</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1856">(1856) More</a></td>
 <td align=center>iowaee</td>
 <td align=center>Iowa Embedded Engineering</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>Cedar Rapids</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1855">(1855) More</a></td>
 <td align=center>Tower</td>
 <td align=center>tau</td>
 <td align=center>Other</td>
 <td align=center>1000</td>
 <td align=center>1.80</td>
 <td align=center>1800</td>
 <td align=center>Israel</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1854">(1854) More</a></td>
 <td align=center>WarmHole</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium</td>
 <td align=center>1</td>
 <td align=center>2.60</td>
 <td align=center>2.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1853">(1853) More</a></td>
 <td align=center>sbdhpc</td>
 <td align=center>Chyme</td>
 <td align=center>EM64T</td>
 <td align=center>5</td>
 <td align=center>2.50</td>
 <td align=center>25</td>
 <td align=center>York</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1852">(1852) More</a></td>
 <td align=center>STAR-CLUSTER</td>
 <td align=center>TnC Computer</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>Talca, VII Region de Chile</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1851">(1851) More</a></td>
 <td align=center>pixley.cluster.hpc</td>
 <td align=center>Solution Logix</td>
 <td align=center>EM64T-4</td>
 <td align=center>40</td>
 <td align=center>2.48</td>
 <td align=center>396.8</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1850">(1850) More</a></td>
 <td align=center>genome.rutgers.edu</td>
 <td align=center>Rutgers University</td>
 <td align=center>Unspecified</td>
 <td align=center>36</td>
 <td align=center>2.00</td>
 <td align=center>72</td>
 <td align=center>Piscataway, NJ</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1849">(1849) More</a></td>
 <td align=center>cluster.rmarshall.net</td>
 <td align=center>private</td>
 <td align=center>Other</td>
 <td align=center>12</td>
 <td align=center>3.20</td>
 <td align=center>38.4</td>
 <td align=center>San Antonio, TX USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1848">(1848) More</a></td>
 <td align=center>Inferno Layer3 </td>
 <td align=center>Layer3.com.mx</td>
 <td align=center>Opteron</td>
 <td align=center>2</td>
 <td align=center>2.60</td>
 <td align=center>10.4</td>
 <td align=center>Guadalajara, Jalisco, Mexico</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1847">(1847) More</a></td>
 <td align=center>swerlcluster.sci.tsu.ac.th</td>
 <td align=center>SWERL</td>
 <td align=center>Other</td>
 <td align=center>42</td>
 <td align=center>3.60</td>
 <td align=center>151.2</td>
 <td align=center>Phatthalung, TH</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1846">(1846) More</a></td>
 <td align=center>CUBES Universiti Malaysia Sabah</td>
 <td align=center>F.R.I.C.S SKTM Universiti Malaysia Sabah</td>
 <td align=center>EM64T-8</td>
 <td align=center>272</td>
 <td align=center>2.39</td>
 <td align=center>5200.64</td>
 <td align=center>Kota Kinabalu, Sabah MALAYSIA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1845">(1845) More</a></td>
 <td align=center>xstreamservices</td>
 <td align=center>xstream Services Inc.</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>3.40</td>
 <td align=center>68</td>
 <td align=center>Barbados</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1844">(1844) More</a></td>
 <td align=center>Zendmannet</td>
 <td align=center>Private</td>
 <td align=center>Opteron</td>
 <td align=center>40</td>
 <td align=center>3.00</td>
 <td align=center>240</td>
 <td align=center>The Netherlands</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1843">(1843) More</a></td>
 <td align=center>olymp</td>
 <td align=center>Perm State University</td>
 <td align=center>Opteron</td>
 <td align=center>13</td>
 <td align=center>1.80</td>
 <td align=center>46.8</td>
 <td align=center>Perm, Russia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1842">(1842) More</a></td>
 <td align=center>middle</td>
 <td align=center>U. of Northern BC</td>
 <td align=center>Other</td>
 <td align=center>6</td>
 <td align=center>1.00</td>
 <td align=center>6</td>
 <td align=center>Prince George, BC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1840">(1840) More</a></td>
 <td align=center>swan</td>
 <td align=center>Oxford University / Oxford e-Research Center</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>2.66</td>
 <td align=center>85.12</td>
 <td align=center>Oxford</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1839">(1839) More</a></td>
 <td align=center>Ensemble</td>
 <td align=center>Indian Institute of Technology, Kanpur</td>
 <td align=center>EM64T-8</td>
 <td align=center>84</td>
 <td align=center>2.66</td>
 <td align=center>1787.52</td>
 <td align=center>Kanpur</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1838">(1838) More</a></td>
 <td align=center>TARDIS</td>
 <td align=center>TARDIS Cluster Project</td>
 <td align=center>EM64T</td>
 <td align=center>11</td>
 <td align=center>2.60</td>
 <td align=center>57.2</td>
 <td align=center>Park Forest, IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1837">(1837) More</a></td>
 <td align=center>defiant</td>
 <td align=center>self</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.40</td>
 <td align=center>27.2</td>
 <td align=center>Brisbane</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1835">(1835) More</a></td>
 <td align=center>phys-titan</td>
 <td align=center>Univerty of Basel</td>
 <td align=center>Opteron</td>
 <td align=center>152</td>
 <td align=center>2.20</td>
 <td align=center>668.8</td>
 <td align=center>Basel</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1833">(1833) More</a></td>
 <td align=center>PANCHONET</td>
 <td align=center>Panchonet S.A.</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>3.20</td>
 <td align=center>12.8</td>
 <td align=center>Ecuador</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1832">(1832) More</a></td>
 <td align=center>doppler</td>
 <td align=center>University of Salzburg</td>
 <td align=center>Opteron</td>
 <td align=center>544</td>
 <td align=center>2.20</td>
 <td align=center>2393.6</td>
 <td align=center>Salzburg / Austria</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1831">(1831) More</a></td>
 <td align=center>gardar</td>
 <td align=center>Nordic HPC</td>
 <td align=center>EM64T-4</td>
 <td align=center>3480</td>
 <td align=center>2.53</td>
 <td align=center>35217.6</td>
 <td align=center>Ísland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1830">(1830) More</a></td>
 <td align=center>N3cluster</td>
 <td align=center>Net-3.CO.UK LTD</td>
 <td align=center>Athlon 64</td>
 <td align=center>28</td>
 <td align=center>2.80</td>
 <td align=center>156.8</td>
 <td align=center>United Kingdom</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1829">(1829) More</a></td>
 <td align=center>Maxwell-HPC</td>
 <td align=center>Computer & Electrical  Engineering, Polytechnic University of PR</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>1.80</td>
 <td align=center>230.4</td>
 <td align=center>Hato Rey, Puerto Rico</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1828">(1828) More</a></td>
 <td align=center>hbsf</td>
 <td align=center>unnversity</td>
 <td align=center>EM64T</td>
 <td align=center>4</td>
 <td align=center>2.10</td>
 <td align=center>16.8</td>
 <td align=center>shijiazhuang</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1827">(1827) More</a></td>
 <td align=center>test_cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>67.2</td>
 <td align=center>varamin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1825">(1825) More</a></td>
 <td align=center>xuanwuben</td>
 <td align=center>zhongke</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>3.60</td>
 <td align=center>115.2</td>
 <td align=center>china</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1824">(1824) More</a></td>
 <td align=center>qicrg.org</td>
 <td align=center>secret</td>
 <td align=center>EM64T-8</td>
 <td align=center>56</td>
 <td align=center>3.70</td>
 <td align=center>1657.6</td>
 <td align=center>thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1823">(1823) More</a></td>
 <td align=center>GDUdev</td>
 <td align=center>John Curtin School of Medical Research</td>
 <td align=center>Opteron</td>
 <td align=center>288</td>
 <td align=center>2.40</td>
 <td align=center>1382.4</td>
 <td align=center>Canberra, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1822">(1822) More</a></td>
 <td align=center>Cloud</td>
 <td align=center>Maxwell Worthington, LLC.</td>
 <td align=center>EM64T-4</td>
 <td align=center>112</td>
 <td align=center>2.50</td>
 <td align=center>1120</td>
 <td align=center>New Orleans, LA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1821">(1821) More</a></td>
 <td align=center>recsys</td>
 <td align=center>privet</td>
 <td align=center>Other</td>
 <td align=center>10</td>
 <td align=center>2.13</td>
 <td align=center>21.3</td>
 <td align=center>Melboune AUS</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1820">(1820) More</a></td>
 <td align=center>S4NGRID</td>
 <td align=center>uitm perlis</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>Malaysia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1819">(1819) More</a></td>
 <td align=center>repa_cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>1.50</td>
 <td align=center>6</td>
 <td align=center>London</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1818">(1818) More</a></td>
 <td align=center>vega</td>
 <td align=center>CMOP</td>
 <td align=center>EM64T-4</td>
 <td align=center>128</td>
 <td align=center>2.66</td>
 <td align=center>1361.92</td>
 <td align=center>Beaverton</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1817">(1817) More</a></td>
 <td align=center>Capivara CTEI/FACOM/UFMS</td>
 <td align=center>Faculty of Computing</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>2.00</td>
 <td align=center>320</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1816">(1816) More</a></td>
 <td align=center>cscb-cluster</td>
 <td align=center>Center for Systems and Computational Biology - Wistar Institute</td>
 <td align=center>EM64T-8</td>
 <td align=center>120</td>
 <td align=center>2.66</td>
 <td align=center>2553.6</td>
 <td align=center>Philadelphia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1815">(1815) More</a></td>
 <td align=center>Mez-Cluster</td>
 <td align=center>Electronics Departement, BBA University</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>3.10</td>
 <td align=center>198.4</td>
 <td align=center>BBA, Algeria</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1813">(1813) More</a></td>
 <td align=center>Computer Engineering  Utcc Cluster</td>
 <td align=center>CPE UTCC</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>3.00</td>
 <td align=center>48</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1812">(1812) More</a></td>
 <td align=center>Thunder.esalq</td>
 <td align=center>USP</td>
 <td align=center>EM64T-4</td>
 <td align=center>120</td>
 <td align=center>2.40</td>
 <td align=center>1152</td>
 <td align=center>Piracicaba, SP, Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1811">(1811) More</a></td>
 <td align=center>PIC</td>
 <td align=center>Pacific Northwest National Laboratory</td>
 <td align=center>EM64T-4</td>
 <td align=center>20992</td>
 <td align=center>2.10</td>
 <td align=center>176332.8</td>
 <td align=center>Richland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1810">(1810) More</a></td>
 <td align=center>taylor</td>
 <td align=center>Wright State University Dept of Mech. and Mat. Egr.</td>
 <td align=center>Athlon 64</td>
 <td align=center>92</td>
 <td align=center>2.40</td>
 <td align=center>441.6</td>
 <td align=center>Dayton, Ohio</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1809">(1809) More</a></td>
 <td align=center>Clive</td>
 <td align=center>UNSW</td>
 <td align=center>EM64T-4</td>
 <td align=center>72</td>
 <td align=center>3.07</td>
 <td align=center>884.16</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1808">(1808) More</a></td>
 <td align=center>Katana</td>
 <td align=center>UNSW</td>
 <td align=center>EM64T-4</td>
 <td align=center>768</td>
 <td align=center>3.07</td>
 <td align=center>9431.04</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1807">(1807) More</a></td>
 <td align=center>Genome</td>
 <td align=center>UNSW</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.40</td>
 <td align=center>614.4</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1806">(1806) More</a></td>
 <td align=center>Fiji</td>
 <td align=center>UCSD</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.50</td>
 <td align=center>640</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1805">(1805) More</a></td>
 <td align=center>Tortellino Rocks Clusters</td>
 <td align=center>SER TEC S.r.l.</td>
 <td align=center>Other</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>Bologna - ITALY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1804">(1804) More</a></td>
 <td align=center>bankandma</td>
 <td align=center>compaq</td>
 <td align=center>Unspecified</td>
 <td align=center>2</td>
 <td align=center>2.00</td>
 <td align=center>4</td>
 <td align=center>dfdfdf</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1803">(1803) More</a></td>
 <td align=center>Auriga</td>
 <td align=center>Instituto Mexicano del Petroleo</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.66</td>
 <td align=center>680.96</td>
 <td align=center>Mexico City</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1802">(1802) More</a></td>
 <td align=center>chipper</td>
 <td align=center>NCGR</td>
 <td align=center>Opteron</td>
 <td align=center>600</td>
 <td align=center>2.00</td>
 <td align=center>2400</td>
 <td align=center>Santa Fe, NM, US</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1801">(1801) More</a></td>
 <td align=center>tome</td>
 <td align=center>NCGR</td>
 <td align=center>EM64T</td>
 <td align=center>192</td>
 <td align=center>3.16</td>
 <td align=center>1213.44</td>
 <td align=center>Santa Fe, NM, US</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1800">(1800) More</a></td>
 <td align=center>caliban</td>
 <td align=center>Dipartimento di Matematica Pura ed Applicata - UNIVAQ</td>
 <td align=center>Opteron</td>
 <td align=center>576</td>
 <td align=center>2.00</td>
 <td align=center>2304</td>
 <td align=center>Italy, AQ</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1799">(1799) More</a></td>
 <td align=center>thor.pharm</td>
 <td align=center>University of Cape Town</td>
 <td align=center>EM64T-4</td>
 <td align=center>90</td>
 <td align=center>2.00</td>
 <td align=center>720</td>
 <td align=center>Cape Town, South Africa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1798">(1798) More</a></td>
 <td align=center>gardel</td>
 <td align=center>Gascon Lab, UCONN Chemistry</td>
 <td align=center>Opteron</td>
 <td align=center>44</td>
 <td align=center>2.80</td>
 <td align=center>246.4</td>
 <td align=center>Storrs, CT</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1797">(1797) More</a></td>
 <td align=center>jm-cluster</td>
 <td align=center>Fac. Cs. Exactas y Naturales - UBA</td>
 <td align=center>Athlon 64</td>
 <td align=center>30</td>
 <td align=center>2.60</td>
 <td align=center>156</td>
 <td align=center>Buenos Aires, Argentina</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1796">(1796) More</a></td>
 <td align=center>LHView</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T</td>
 <td align=center>6</td>
 <td align=center>2.66</td>
 <td align=center>31.92</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1795">(1795) More</a></td>
 <td align=center>The Planetary Assault System</td>
 <td align=center>UAT</td>
 <td align=center>EM64T</td>
 <td align=center>24</td>
 <td align=center>2.60</td>
 <td align=center>124.8</td>
 <td align=center>Tempe, AZ</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1793">(1793) More</a></td>
 <td align=center>AlphaTest</td>
 <td align=center>Alpha System AS</td>
 <td align=center>EM64T</td>
 <td align=center>24</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>Trondheim, Norway</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1792">(1792) More</a></td>
 <td align=center>Embla</td>
 <td align=center>SINTEF MARINTEK</td>
 <td align=center>Opteron</td>
 <td align=center>344</td>
 <td align=center>2.70</td>
 <td align=center>1857.6</td>
 <td align=center>Trondheim, Norway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1791">(1791) More</a></td>
 <td align=center>Flukus</td>
 <td align=center>SINTEF Materials and Chemistry</td>
 <td align=center>EM64T-4</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>240</td>
 <td align=center>Trondheim, Norway</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1790">(1790) More</a></td>
 <td align=center>Salt</td>
 <td align=center>SINTEF Materials and Chemistry</td>
 <td align=center>EM64T-4</td>
 <td align=center>100</td>
 <td align=center>3.00</td>
 <td align=center>1200</td>
 <td align=center>Trondheim, Norway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1789">(1789) More</a></td>
 <td align=center>Rumen-rocks</td>
 <td align=center>AAFC</td>
 <td align=center>EM64T-4</td>
 <td align=center>14</td>
 <td align=center>2.67</td>
 <td align=center>149.52</td>
 <td align=center>Lethbridge</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1788">(1788) More</a></td>
 <td align=center>Borg</td>
 <td align=center>University of Arkansas at Monticello</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>2.40</td>
 <td align=center>96</td>
 <td align=center>Monticello, Arkansas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1787">(1787) More</a></td>
 <td align=center>Phoenix</td>
 <td align=center>Chulalongkorn University</td>
 <td align=center>EM64T-4</td>
 <td align=center>640</td>
 <td align=center>2.50</td>
 <td align=center>6400</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1786">(1786) More</a></td>
 <td align=center>ESM-LCC</td>
 <td align=center>Virginia Tech - ESM Department</td>
 <td align=center>EM64T</td>
 <td align=center>192</td>
 <td align=center>2.50</td>
 <td align=center>960</td>
 <td align=center>Blacksburg, Virginia, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1785">(1785) More</a></td>
 <td align=center>Mccluster</td>
 <td align=center>Cold Spring Harbor Laboratory</td>
 <td align=center>Other</td>
 <td align=center>48</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>Cold Spring Harbor</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1784">(1784) More</a></td>
 <td align=center>OUH-MCCluster</td>
 <td align=center>Odense University Hospital</td>
 <td align=center>EM64T-4</td>
 <td align=center>24</td>
 <td align=center>2.66</td>
 <td align=center>255.36</td>
 <td align=center>Odense, Denmark</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1783">(1783) More</a></td>
 <td align=center>Selenium</td>
 <td align=center>Baylor College of Medicine</td>
 <td align=center>Opteron</td>
 <td align=center>260</td>
 <td align=center>2.20</td>
 <td align=center>1144</td>
 <td align=center>Houston</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1782">(1782) More</a></td>
 <td align=center>labmol</td>
 <td align=center>Federal University of Goias - LABMOL</td>
 <td align=center>EM64T</td>
 <td align=center>60</td>
 <td align=center>2.10</td>
 <td align=center>252</td>
 <td align=center>Goiania, Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1780">(1780) More</a></td>
 <td align=center>Pebbles</td>
 <td align=center>Home Brew</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>3.40</td>
 <td align=center>68</td>
 <td align=center>Newark, OH</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1778">(1778) More</a></td>
 <td align=center>Wisp</td>
 <td align=center>Johns Hopkins University</td>
 <td align=center>EM64T</td>
 <td align=center>2180</td>
 <td align=center>2.50</td>
 <td align=center>10900</td>
 <td align=center>Baltimore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1777">(1777) More</a></td>
 <td align=center>Mini-Cluster</td>
 <td align=center>UFAM</td>
 <td align=center>EM64T</td>
 <td align=center>28</td>
 <td align=center>2.00</td>
 <td align=center>112</td>
 <td align=center>Humitá</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1776">(1776) More</a></td>
 <td align=center>barberocluster</td>
 <td align=center>Mechanical and Aerospace Engineering WVU</td>
 <td align=center>Opteron</td>
 <td align=center>36</td>
 <td align=center>2.13</td>
 <td align=center>153.36</td>
 <td align=center>West Virginia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1775">(1775) More</a></td>
 <td align=center>mkcluster</td>
 <td align=center>University of California, San Diego</td>
 <td align=center>Opteron</td>
 <td align=center>128</td>
 <td align=center>2.40</td>
 <td align=center>614.4</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1774">(1774) More</a></td>
 <td align=center>aos88</td>
 <td align=center>University of Colorado</td>
 <td align=center>EM64T-4</td>
 <td align=center>6</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>Boulder</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1773">(1773) More</a></td>
 <td align=center>pdr7</td>
 <td align=center>Boeing</td>
 <td align=center>EM64T-4</td>
 <td align=center>22</td>
 <td align=center>2.40</td>
 <td align=center>211.2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1772">(1772) More</a></td>
 <td align=center>pdr6</td>
 <td align=center>Boeing</td>
 <td align=center>EM64T-4</td>
 <td align=center>22</td>
 <td align=center>2.40</td>
 <td align=center>211.2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1771">(1771) More</a></td>
 <td align=center>pdr5</td>
 <td align=center>Boeing</td>
 <td align=center>EM64T-4</td>
 <td align=center>14</td>
 <td align=center>2.40</td>
 <td align=center>134.4</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1770">(1770) More</a></td>
 <td align=center>krathys</td>
 <td align=center>Veterans Administration</td>
 <td align=center>EM64T-4</td>
 <td align=center>90</td>
 <td align=center>2.26</td>
 <td align=center>813.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1769">(1769) More</a></td>
 <td align=center>nami</td>
 <td align=center>University of Buffalo</td>
 <td align=center>Opteron</td>
 <td align=center>58</td>
 <td align=center>2.00</td>
 <td align=center>232</td>
 <td align=center>New York</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1768">(1768) More</a></td>
 <td align=center>tesla</td>
 <td align=center>Seagate</td>
 <td align=center>EM64T-4</td>
 <td align=center>18</td>
 <td align=center>2.40</td>
 <td align=center>172.8</td>
 <td align=center>Ireland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1767">(1767) More</a></td>
 <td align=center>Cluster-Rock</td>
 <td align=center>Instituto de Física de São Carlos</td>
 <td align=center>EM64T</td>
 <td align=center>88</td>
 <td align=center>3.33</td>
 <td align=center>586.08</td>
 <td align=center>São Carlos - SP - BR</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1766">(1766) More</a></td>
 <td align=center>Cluster-Ruska</td>
 <td align=center>Instituto de Física de São Carlos</td>
 <td align=center>EM64T</td>
 <td align=center>36</td>
 <td align=center>2.40</td>
 <td align=center>172.8</td>
 <td align=center>São Carlos - SP - BR</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1764">(1764) More</a></td>
 <td align=center>Mika</td>
 <td align=center>private</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>2.66</td>
 <td align=center>26.6</td>
 <td align=center>Mitchell, SD</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1763">(1763) More</a></td>
 <td align=center>Bio-informatic Cluster</td>
 <td align=center>COMSATS</td>
 <td align=center>Pentium</td>
 <td align=center>11</td>
 <td align=center>1.80</td>
 <td align=center>19.8</td>
 <td align=center>Abbottabad</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1762">(1762) More</a></td>
 <td align=center>shawn.nuxtp</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Athlon 64</td>
 <td align=center>5</td>
 <td align=center>3.20</td>
 <td align=center>32</td>
 <td align=center>Fairfield, Calif.</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1761">(1761) More</a></td>
 <td align=center>elrond</td>
 <td align=center>The Queensland Brain Institute, The University of Queensland</td>
 <td align=center>EM64T-4</td>
 <td align=center>1200</td>
 <td align=center>2.93</td>
 <td align=center>14064</td>
 <td align=center>Queensland, Australia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1760">(1760) More</a></td>
 <td align=center>Cluster-Física</td>
 <td align=center>School of Physics, University of Costa Rica</td>
 <td align=center>Unspecified</td>
 <td align=center>72</td>
 <td align=center>2.80</td>
 <td align=center>201.6</td>
 <td align=center>San José</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1759">(1759) More</a></td>
 <td align=center>electron</td>
 <td align=center>BITS, Pilani</td>
 <td align=center>Opteron</td>
 <td align=center>20</td>
 <td align=center>2.26</td>
 <td align=center>90.4</td>
 <td align=center>Pilani , Rajasthan, India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1758">(1758) More</a></td>
 <td align=center>SUTECH</td>
 <td align=center>SUTECH</td>
 <td align=center>EM64T-4</td>
 <td align=center>160</td>
 <td align=center>3.00</td>
 <td align=center>1920</td>
 <td align=center>Shiraz, Iran</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1757">(1757) More</a></td>
 <td align=center>Seed</td>
 <td align=center>SGGSIE&T , Nanded</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.00</td>
 <td align=center>12</td>
 <td align=center>Nanded , India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1756">(1756) More</a></td>
 <td align=center>GPT</td>
 <td align=center>Tennessee State University</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.80</td>
 <td align=center>716.8</td>
 <td align=center>Nashville</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1755">(1755) More</a></td>
 <td align=center>Marc-1</td>
 <td align=center>CEPM</td>
 <td align=center>Pentium 4</td>
 <td align=center>22</td>
 <td align=center>2.40</td>
 <td align=center>105.6</td>
 <td align=center>Morges, Switzerland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1754">(1754) More</a></td>
 <td align=center>ROCKS-MUSHTAQ</td>
 <td align=center>Bombay College of Pharmacy</td>
 <td align=center>Unspecified</td>
 <td align=center>5</td>
 <td align=center>2.50</td>
 <td align=center>12.5</td>
 <td align=center>Mumbai, India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1753">(1753) More</a></td>
 <td align=center>janarguitar</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>1</td>
 <td align=center>3.00</td>
 <td align=center>3</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1752">(1752) More</a></td>
 <td align=center>IMSG</td>
 <td align=center>I.M Systems Group</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.93</td>
 <td align=center>750.08</td>
 <td align=center>Maryland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1751">(1751) More</a></td>
 <td align=center>Julius</td>
 <td align=center>NJIT</td>
 <td align=center>Athlon 64</td>
 <td align=center>53</td>
 <td align=center>3.20</td>
 <td align=center>339.2</td>
 <td align=center>Newark NJ</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1750">(1750) More</a></td>
 <td align=center>MORU-Rocky</td>
 <td align=center>Mahidol University</td>
 <td align=center>EM64T</td>
 <td align=center>104</td>
 <td align=center>2.80</td>
 <td align=center>582.4</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1748">(1748) More</a></td>
 <td align=center>Green lantern</td>
 <td align=center>Lab 7,National Centre For Cell Science</td>
 <td align=center>EM64T</td>
 <td align=center>80</td>
 <td align=center>2.53</td>
 <td align=center>404.8</td>
 <td align=center>Pune India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1747">(1747) More</a></td>
 <td align=center>HPC-MT-MU</td>
 <td align=center>Faculty of Medical Technology, Mahidol University</td>
 <td align=center>Opteron</td>
 <td align=center>240</td>
 <td align=center>2.10</td>
 <td align=center>1008</td>
 <td align=center>Nakornpathom</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1746">(1746) More</a></td>
 <td align=center>HiST</td>
 <td align=center>HiPT Group</td>
 <td align=center>Pentium 4</td>
 <td align=center>42</td>
 <td align=center>3.00</td>
 <td align=center>252</td>
 <td align=center>Ha Noi - Viet Nam</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1745">(1745) More</a></td>
 <td align=center>IBM 1600</td>
 <td align=center>Center for High Performance Computing (CHPC/HUS)</td>
 <td align=center>EM64T-4</td>
 <td align=center>40</td>
 <td align=center>1.70</td>
 <td align=center>272</td>
 <td align=center>Hanoi</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1744">(1744) More</a></td>
 <td align=center>Curio</td>
 <td align=center>CPGG-UFBA</td>
 <td align=center>Other</td>
 <td align=center>52</td>
 <td align=center>2.40</td>
 <td align=center>124.8</td>
 <td align=center>Salvador, Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1743">(1743) More</a></td>
 <td align=center>Aguia</td>
 <td align=center>CPGG-UFBA</td>
 <td align=center>Other</td>
 <td align=center>336</td>
 <td align=center>2.50</td>
 <td align=center>840</td>
 <td align=center>Salvador, Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1742">(1742) More</a></td>
 <td align=center>NET</td>
 <td align=center>University of Stuttgart</td>
 <td align=center>EM64T-4</td>
 <td align=center>128</td>
 <td align=center>2.40</td>
 <td align=center>1228.8</td>
 <td align=center>Stuttgart</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1741">(1741) More</a></td>
 <td align=center>VSDSL</td>
 <td align=center>University of Stuttgart</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.80</td>
 <td align=center>358.4</td>
 <td align=center>Stuttgart</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1740">(1740) More</a></td>
 <td align=center>LHU_Cluster</td>
 <td align=center>Education</td>
 <td align=center>Other</td>
 <td align=center>18</td>
 <td align=center>2.66</td>
 <td align=center>47.88</td>
 <td align=center>Biên Hòa - �?ồng Nai - Việt Nam</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1739">(1739) More</a></td>
 <td align=center>Diodo</td>
 <td align=center>Instituto de Astrofísica de Canarias (www.iac.es)</td>
 <td align=center>EM64T</td>
 <td align=center>114</td>
 <td align=center>3.20</td>
 <td align=center>729.6</td>
 <td align=center>La Laguna (Spain)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1738">(1738) More</a></td>
 <td align=center>covertlab-cluster</td>
 <td align=center>Covert Lab, Department of Bioengineering, Stanford University</td>
 <td align=center>EM64T-4</td>
 <td align=center>72</td>
 <td align=center>2.40</td>
 <td align=center>691.2</td>
 <td align=center>Stanford CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1737">(1737) More</a></td>
 <td align=center>PROMETHEUS</td>
 <td align=center>Bombay College of Pharmacy</td>
 <td align=center>EM64T</td>
 <td align=center>112</td>
 <td align=center>2.40</td>
 <td align=center>537.6</td>
 <td align=center>Mumbai, Maharashtra</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1736">(1736) More</a></td>
 <td align=center>optimus</td>
 <td align=center>Bombay College of Pharmacy</td>
 <td align=center>EM64T</td>
 <td align=center>56</td>
 <td align=center>1.60</td>
 <td align=center>179.2</td>
 <td align=center>Mumbai, India</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1735">(1735) More</a></td>
 <td align=center>Longwood University Cluster (LUC)</td>
 <td align=center>Longwood University</td>
 <td align=center>Other</td>
 <td align=center>64</td>
 <td align=center>1.66</td>
 <td align=center>106.24</td>
 <td align=center>Farmville, Virginia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1734">(1734) More</a></td>
 <td align=center>Tripod</td>
 <td align=center>Personal lab</td>
 <td align=center>Athlon 64</td>
 <td align=center>9</td>
 <td align=center>2.10</td>
 <td align=center>37.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1733">(1733) More</a></td>
 <td align=center>Tyndall HPC</td>
 <td align=center>Tyndall Institute</td>
 <td align=center>Opteron</td>
 <td align=center>2740</td>
 <td align=center>2.40</td>
 <td align=center>13152</td>
 <td align=center>Cork, Ireland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1732">(1732) More</a></td>
 <td align=center>riemann</td>
 <td align=center>University of Wisconsin</td>
 <td align=center>EM64T-4</td>
 <td align=center>256</td>
 <td align=center>2.40</td>
 <td align=center>2457.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1731">(1731) More</a></td>
 <td align=center>gaia CMIMA</td>
 <td align=center>ICM CSIC</td>
 <td align=center>Opteron</td>
 <td align=center>92</td>
 <td align=center>2.30</td>
 <td align=center>423.2</td>
 <td align=center>Barcelona (Spain)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1730">(1730) More</a></td>
 <td align=center>rockarea.paknam.org</td>
 <td align=center>paknam</td>
 <td align=center>Opteron</td>
 <td align=center>2</td>
 <td align=center>2.40</td>
 <td align=center>9.6</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1729">(1729) More</a></td>
 <td align=center>ASH25</td>
 <td align=center>Dep. Teoria de la Señal y Com. Univ. Carlos III de Madrid.</td>
 <td align=center>EM64T-4</td>
 <td align=center>164</td>
 <td align=center>2.40</td>
 <td align=center>1574.4</td>
 <td align=center>Leganés, Madrid (Spain)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1728">(1728) More</a></td>
 <td align=center>Solomon</td>
 <td align=center>Stanford University</td>
 <td align=center>Opteron</td>
 <td align=center>640</td>
 <td align=center>2.00</td>
 <td align=center>2560</td>
 <td align=center>Stanford, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1727">(1727) More</a></td>
 <td align=center>recatm</td>
 <td align=center>UFES</td>
 <td align=center>Unspecified</td>
 <td align=center>4</td>
 <td align=center>3.00</td>
 <td align=center>12</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1726">(1726) More</a></td>
 <td align=center>UBCluster</td>
 <td align=center>Bechar University</td>
 <td align=center>EM64T</td>
 <td align=center>96</td>
 <td align=center>2.66</td>
 <td align=center>510.72</td>
 <td align=center>Bechar, Algeria</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1725">(1725) More</a></td>
 <td align=center>geodyncomp</td>
 <td align=center>Dalhousie University</td>
 <td align=center>EM64T</td>
 <td align=center>48</td>
 <td align=center>2.40</td>
 <td align=center>230.4</td>
 <td align=center>Halifax</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1724">(1724) More</a></td>
 <td align=center>Sherlock Cluster</td>
 <td align=center>UW-Milwaukee</td>
 <td align=center>EM64T</td>
 <td align=center>56</td>
 <td align=center>2.50</td>
 <td align=center>280</td>
 <td align=center>Milwaukee</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1723">(1723) More</a></td>
 <td align=center>SWDRocks</td>
 <td align=center>ARA</td>
 <td align=center>Opteron</td>
 <td align=center>40</td>
 <td align=center>2.66</td>
 <td align=center>212.8</td>
 <td align=center>Albuquerque, NM</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1722">(1722) More</a></td>
 <td align=center>area996</td>
 <td align=center>FMB (five Magic Beans)</td>
 <td align=center>Athlon</td>
 <td align=center>4</td>
 <td align=center>2.40</td>
 <td align=center>9.6</td>
 <td align=center>Miyoko-Shi ,Niigata ,Japan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1721">(1721) More</a></td>
 <td align=center>IF-UFMT</td>
 <td align=center>Universidade Federal de Mato Grosso</td>
 <td align=center>EM64T-4</td>
 <td align=center>46</td>
 <td align=center>2.00</td>
 <td align=center>368</td>
 <td align=center>Cuiabá - MT - Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1720">(1720) More</a></td>
 <td align=center>UIST MPS01</td>
 <td align=center>University for Information Science and Technology</td>
 <td align=center>EM64T-4</td>
 <td align=center>250</td>
 <td align=center>2.50</td>
 <td align=center>2500</td>
 <td align=center>Ohrid, Republic of Macedonia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1719">(1719) More</a></td>
 <td align=center>Windowless Tiger</td>
 <td align=center>HRH Productions</td>
 <td align=center>Pentium 4</td>
 <td align=center>73</td>
 <td align=center>3.00</td>
 <td align=center>438</td>
 <td align=center>La Junta, CO</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1717">(1717) More</a></td>
 <td align=center>LCID</td>
 <td align=center>LCID at UTEP</td>
 <td align=center>EM64T-4</td>
 <td align=center>1728</td>
 <td align=center>2.16</td>
 <td align=center>14929.92</td>
 <td align=center>El Paso</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1716">(1716) More</a></td>
 <td align=center>powder</td>
 <td align=center>University of Connecticut</td>
 <td align=center>Unspecified</td>
 <td align=center>44</td>
 <td align=center>2.33</td>
 <td align=center>102.52</td>
 <td align=center>Storrs</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1714">(1714) More</a></td>
 <td align=center>UrsaMajor</td>
 <td align=center>Center for Environmental Sciences and Engineering</td>
 <td align=center>Athlon</td>
 <td align=center>13</td>
 <td align=center>1.70</td>
 <td align=center>22.1</td>
 <td align=center>Storrs</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1713">(1713) More</a></td>
 <td align=center>berserker</td>
 <td align=center>University of Chicago</td>
 <td align=center>EM64T-4</td>
 <td align=center>192</td>
 <td align=center>2.66</td>
 <td align=center>2042.88</td>
 <td align=center>Chicago</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1712">(1712) More</a></td>
 <td align=center>sun</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.30</td>
 <td align=center>294.4</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1711">(1711) More</a></td>
 <td align=center>emitting</td>
 <td align=center>faculty of chemistry, northeast normal univesity</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>2.67</td>
 <td align=center>42.72</td>
 <td align=center>Changchun, China</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1710">(1710) More</a></td>
 <td align=center>Stella_HPC</td>
 <td align=center>University of Athens</td>
 <td align=center>EM64T</td>
 <td align=center>6</td>
 <td align=center>2.30</td>
 <td align=center>27.6</td>
 <td align=center>Athens</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1709">(1709) More</a></td>
 <td align=center>The-Gad</td>
 <td align=center>Advance Computing Lab, Department of Physics, University of Pune</td>
 <td align=center>EM64T</td>
 <td align=center>34</td>
 <td align=center>3.20</td>
 <td align=center>217.6</td>
 <td align=center>Pune, India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1708">(1708) More</a></td>
 <td align=center>MMIL-CLUSTER-4</td>
 <td align=center>MMIL - UC San  Diego</td>
 <td align=center>EM64T-4</td>
 <td align=center>784</td>
 <td align=center>2.66</td>
 <td align=center>8341.76</td>
 <td align=center>La Jolla</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1707">(1707) More</a></td>
 <td align=center>MMIL-CLUSTER-3</td>
 <td align=center>MMIL - UC San  Diego</td>
 <td align=center>EM64T-4</td>
 <td align=center>104</td>
 <td align=center>2.33</td>
 <td align=center>969.28</td>
 <td align=center>La Jolla</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1706">(1706) More</a></td>
 <td align=center>MMIL-CLUSTER-2</td>
 <td align=center>MMIL - UC San  Diego</td>
 <td align=center>EM64T-4</td>
 <td align=center>120</td>
 <td align=center>2.33</td>
 <td align=center>1118.4</td>
 <td align=center>La Jolla</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1705">(1705) More</a></td>
 <td align=center>EOIdeas</td>
 <td align=center>ElectroOptical Innovations</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>2.40</td>
 <td align=center>115.2</td>
 <td align=center>Briarcliff Manor NY</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1704">(1704) More</a></td>
 <td align=center>science</td>
 <td align=center>private</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>3.20</td>
 <td align=center>153.6</td>
 <td align=center>Athens, Greece</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1703">(1703) More</a></td>
 <td align=center>Helium</td>
 <td align=center>IIT Bombay</td>
 <td align=center>EM64T</td>
 <td align=center>104</td>
 <td align=center>3.00</td>
 <td align=center>624</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1702">(1702) More</a></td>
 <td align=center>Nike-HPC</td>
 <td align=center>University of Minnesota, Aerospace Engineering</td>
 <td align=center>Opteron</td>
 <td align=center>1680</td>
 <td align=center>2.10</td>
 <td align=center>7056</td>
 <td align=center>Minneapolis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1701">(1701) More</a></td>
 <td align=center>LPMCN1</td>
 <td align=center>CNRS</td>
 <td align=center>EM64T-4</td>
 <td align=center>320</td>
 <td align=center>2.27</td>
 <td align=center>2905.6</td>
 <td align=center>Lyon</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1700">(1700) More</a></td>
 <td align=center>gyra</td>
 <td align=center>CCMAR</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>2.30</td>
 <td align=center>368</td>
 <td align=center>Faro, Portugal</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1699">(1699) More</a></td>
 <td align=center>IBM1350</td>
 <td align=center>chpc</td>
 <td align=center>EM64T-4</td>
 <td align=center>8</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>hanoi</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1698">(1698) More</a></td>
 <td align=center>ioitgca1</td>
 <td align=center>IOIT Hanoi</td>
 <td align=center>EM64T-4</td>
 <td align=center>4</td>
 <td align=center>2.50</td>
 <td align=center>40</td>
 <td align=center>Hanoi</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1697">(1697) More</a></td>
 <td align=center>cluster.chem.ksu.edu</td>
 <td align=center>Kansas State University</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>1.80</td>
 <td align=center>288</td>
 <td align=center>Manhattan, KS</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1696">(1696) More</a></td>
 <td align=center>Krusty</td>
 <td align=center>Instituto de Física de São Carlos - USP</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>2.60</td>
 <td align=center>332.8</td>
 <td align=center>São Carlos - SP - Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1695">(1695) More</a></td>
 <td align=center>URS Gaithersburg</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T-4</td>
 <td align=center>128</td>
 <td align=center>2.33</td>
 <td align=center>1192.96</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1694">(1694) More</a></td>
 <td align=center>CIMeC CLIC Cluster</td>
 <td align=center>CIMeC - University of Trento</td>
 <td align=center>EM64T-4</td>
 <td align=center>88</td>
 <td align=center>2.27</td>
 <td align=center>799.04</td>
 <td align=center>Rovereto TN - Italy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1693">(1693) More</a></td>
 <td align=center>genomica_csisp</td>
 <td align=center>Centro Superior de Investigacion en Salud Publica</td>
 <td align=center>EM64T-4</td>
 <td align=center>256</td>
 <td align=center>3.00</td>
 <td align=center>3072</td>
 <td align=center>Valencia , SPAIN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1692">(1692) More</a></td>
 <td align=center>newton.uakron</td>
 <td align=center>The University of Akron - Mechanical Engineering</td>
 <td align=center>Opteron</td>
 <td align=center>136</td>
 <td align=center>2.60</td>
 <td align=center>707.2</td>
 <td align=center>Akron, OH</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1691">(1691) More</a></td>
 <td align=center>steger</td>
 <td align=center>Aerospace Engr. Dept., California Polytechnic State University</td>
 <td align=center>Opteron</td>
 <td align=center>88</td>
 <td align=center>2.40</td>
 <td align=center>422.4</td>
 <td align=center>San Luis Obispo, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1690">(1690) More</a></td>
 <td align=center>UniKL Grid</td>
 <td align=center>UniKL</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>2.40</td>
 <td align=center>9.6</td>
 <td align=center>KL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1689">(1689) More</a></td>
 <td align=center>Terragames</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>3</td>
 <td align=center>2.80</td>
 <td align=center>8.4</td>
 <td align=center>Germany</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1688">(1688) More</a></td>
 <td align=center>crazynet</td>
 <td align=center>crazynet</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>beijing</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1687">(1687) More</a></td>
 <td align=center>CAT HPC</td>
 <td align=center>Anglia Ruskin University</td>
 <td align=center>Other</td>
 <td align=center>24</td>
 <td align=center>1.80</td>
 <td align=center>43.2</td>
 <td align=center>Chelmsford, UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1686">(1686) More</a></td>
 <td align=center>nanda</td>
 <td align=center>U.C. Davis Physics</td>
 <td align=center>Unspecified</td>
 <td align=center>16</td>
 <td align=center>2.53</td>
 <td align=center>40.48</td>
 <td align=center>Davis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1685">(1685) More</a></td>
 <td align=center>drobilica</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T-4</td>
 <td align=center>48</td>
 <td align=center>2.33</td>
 <td align=center>447.36</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1684">(1684) More</a></td>
 <td align=center>mypc</td>
 <td align=center>cn</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.93</td>
 <td align=center>23.44</td>
 <td align=center>china</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1683">(1683) More</a></td>
 <td align=center>Kongull</td>
 <td align=center>NTNU</td>
 <td align=center>Opteron</td>
 <td align=center>188</td>
 <td align=center>2.40</td>
 <td align=center>902.4</td>
 <td align=center>Trondheim</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1682">(1682) More</a></td>
 <td align=center>geon</td>
 <td align=center>University of Hyderabad</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>2.80</td>
 <td align=center>11.2</td>
 <td align=center>Hyderabad</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1681">(1681) More</a></td>
 <td align=center>Paknam_Cluster</td>
 <td align=center>paknam</td>
 <td align=center>Opteron</td>
 <td align=center>2</td>
 <td align=center>2.40</td>
 <td align=center>9.6</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1679">(1679) More</a></td>
 <td align=center>GRB</td>
 <td align=center>UCI</td>
 <td align=center>Opteron</td>
 <td align=center>240</td>
 <td align=center>2.20</td>
 <td align=center>1056</td>
 <td align=center>Irvine</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1678">(1678) More</a></td>
 <td align=center>AGN</td>
 <td align=center>UCI</td>
 <td align=center>Itanium 2</td>
 <td align=center>520</td>
 <td align=center>1.50</td>
 <td align=center>3120</td>
 <td align=center>Irvine</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1677">(1677) More</a></td>
 <td align=center>darius2</td>
 <td align=center>MIT</td>
 <td align=center>EM64T-4</td>
 <td align=center>272</td>
 <td align=center>2.40</td>
 <td align=center>2611.2</td>
 <td align=center>MA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1676">(1676) More</a></td>
 <td align=center>TKH-Cluster02</td>
 <td align=center>TK Holdings, Inc.</td>
 <td align=center>EM64T-8</td>
 <td align=center>72</td>
 <td align=center>2.60</td>
 <td align=center>1497.6</td>
 <td align=center>Auburn Hills, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1675">(1675) More</a></td>
 <td align=center>RHHPC Wild Dragon</td>
 <td align=center>Key Safety Systems Deutschland GmbH</td>
 <td align=center>EM64T-4</td>
 <td align=center>76</td>
 <td align=center>2.80</td>
 <td align=center>851.2</td>
 <td align=center>Raunheim / Germany</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1674">(1674) More</a></td>
 <td align=center>graphene</td>
 <td align=center>IITB</td>
 <td align=center>EM64T</td>
 <td align=center>80</td>
 <td align=center>2.00</td>
 <td align=center>320</td>
 <td align=center>Mumbai, INDIA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1673">(1673) More</a></td>
 <td align=center>Fisher</td>
 <td align=center>Genetics Institute, University of Florida</td>
 <td align=center>EM64T</td>
 <td align=center>146</td>
 <td align=center>2.66</td>
 <td align=center>776.72</td>
 <td align=center>Gainesville</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1671">(1671) More</a></td>
 <td align=center>ProSightCluster</td>
 <td align=center>Northwestern University</td>
 <td align=center>EM64T-4</td>
 <td align=center>166</td>
 <td align=center>2.40</td>
 <td align=center>1593.6</td>
 <td align=center>Evanston, IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1670">(1670) More</a></td>
 <td align=center>Wata</td>
 <td align=center>Faculty of Engineering</td>
 <td align=center>EM64T-4</td>
 <td align=center>120</td>
 <td align=center>2.53</td>
 <td align=center>1214.4</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1669">(1669) More</a></td>
 <td align=center>Lee@UNO</td>
 <td align=center>University of New Orleans</td>
 <td align=center>EM64T-4</td>
 <td align=center>160</td>
 <td align=center>2.66</td>
 <td align=center>1702.4</td>
 <td align=center>New Orleans</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1668">(1668) More</a></td>
 <td align=center>cairhive</td>
 <td align=center>SCRA/MUSC</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>2.50</td>
 <td align=center>160</td>
 <td align=center>Charleston, South Carolina</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1667">(1667) More</a></td>
 <td align=center>ironman1</td>
 <td align=center>University of Auckland</td>
 <td align=center>Other</td>
 <td align=center>8</td>
 <td align=center>2.93</td>
 <td align=center>23.44</td>
 <td align=center>Auckland, New Zealand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1666">(1666) More</a></td>
 <td align=center>Undergrad Lab Cluster-2</td>
 <td align=center>University of Toronto, Dept. of Chemistry</td>
 <td align=center>Other</td>
 <td align=center>36</td>
 <td align=center>3.60</td>
 <td align=center>129.6</td>
 <td align=center>Toronto, ON</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1665">(1665) More</a></td>
 <td align=center>API-Cluster-II</td>
 <td align=center>Applied Physics Institute</td>
 <td align=center>EM64T-4</td>
 <td align=center>160</td>
 <td align=center>2.10</td>
 <td align=center>1344</td>
 <td align=center>Bowling Green, KY</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1664">(1664) More</a></td>
 <td align=center>Firebird</td>
 <td align=center>School Of Computer Science, University Of KwaZulu-Natal</td>
 <td align=center>Itanium 2</td>
 <td align=center>16</td>
 <td align=center>2.47</td>
 <td align=center>158.08</td>
 <td align=center>Durban</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1662">(1662) More</a></td>
 <td align=center>chepibe</td>
 <td align=center>Physics, University of Nottingham</td>
 <td align=center>Pentium 4</td>
 <td align=center>34</td>
 <td align=center>2.80</td>
 <td align=center>190.4</td>
 <td align=center>Nottingham, UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1661">(1661) More</a></td>
 <td align=center>Viz</td>
 <td align=center>Lews Castle College</td>
 <td align=center>Other</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>18</td>
 <td align=center>Stornoway, Isle of Lewis, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1660">(1660) More</a></td>
 <td align=center>gadolinium</td>
 <td align=center>NE-CAT, Cornell University</td>
 <td align=center>EM64T-4</td>
 <td align=center>136</td>
 <td align=center>2.27</td>
 <td align=center>1234.88</td>
 <td align=center>Argonne, IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1659">(1659) More</a></td>
 <td align=center><a href=http://hpc.irri.cgiar.org>HPC-IRRI</a></td>
 <td align=center><a href=http://www.irri.org>IRRI</a></td>
 <td align=center>Opteron</td>
 <td align=center>18</td>
 <td align=center>2.00</td>
 <td align=center>72</td>
 <td align=center>Los Baños, Laguna, Philippines</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1658">(1658) More</a></td>
 <td align=center>Swarm Cluster</td>
 <td align=center>CBSE</td>
 <td align=center>EM64T</td>
 <td align=center>1024</td>
 <td align=center>2.00</td>
 <td align=center>4096</td>
 <td align=center>Santa Cruz, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1657">(1657) More</a></td>
 <td align=center>Florida Tech CMS Tier-3</td>
 <td align=center>Florida Tech HEP</td>
 <td align=center>EM64T-4</td>
 <td align=center>160</td>
 <td align=center>2.33</td>
 <td align=center>1491.2</td>
 <td align=center>Melbourne FL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1655">(1655) More</a></td>
 <td align=center>Bernoulli</td>
 <td align=center>Loyola Marymount University (Math)</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>2.00</td>
 <td align=center>256</td>
 <td align=center>Los Angeles, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1654">(1654) More</a></td>
 <td align=center>Rocks-Coaa</td>
 <td align=center>Brazil National Observatory</td>
 <td align=center>EM64T-4</td>
 <td align=center>28</td>
 <td align=center>2.80</td>
 <td align=center>313.6</td>
 <td align=center>Rio de Janeiro, BR</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1653">(1653) More</a></td>
 <td align=center>Gargi.ME</td>
 <td align=center>University of Houston</td>
 <td align=center>EM64T-4</td>
 <td align=center>272</td>
 <td align=center>2.13</td>
 <td align=center>2317.44</td>
 <td align=center>Houston</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1652">(1652) More</a></td>
 <td align=center>APICluster-II</td>
 <td align=center>WKU Applied Physics Institute</td>
 <td align=center>EM64T-4</td>
 <td align=center>160</td>
 <td align=center>2.10</td>
 <td align=center>1344</td>
 <td align=center>Bowling Green, KY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1651">(1651) More</a></td>
 <td align=center>TSU Hades Cluster</td>
 <td align=center>Texas Southern University High Performance Computing Center</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>2.39</td>
 <td align=center>611.84</td>
 <td align=center>Houston, Texas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1650">(1650) More</a></td>
 <td align=center>Arbewing</td>
 <td align=center>IA UDEC, Universidad de Concepción, Chile</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>3.00</td>
 <td align=center>48</td>
 <td align=center>Concepción, Chile</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1649">(1649) More</a></td>
 <td align=center>typhoon</td>
 <td align=center>US Navy</td>
 <td align=center>Opteron</td>
 <td align=center>128</td>
 <td align=center>2.20</td>
 <td align=center>563.2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1648">(1648) More</a></td>
 <td align=center>RocksLaSalleBCN</td>
 <td align=center>Enginyeria La Salle URL</td>
 <td align=center>EM64T</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>120</td>
 <td align=center>Barcelona Catalunya</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1647">(1647) More</a></td>
 <td align=center>big.hpc.org Military Medi</td>
 <td align=center>Third Military Medical University</td>
 <td align=center>Other</td>
 <td align=center>208</td>
 <td align=center>2.66</td>
 <td align=center>553.28</td>
 <td align=center>Chongqing</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1646">(1646) More</a></td>
 <td align=center>ghetto</td>
 <td align=center>SUNY at Stony Brook</td>
 <td align=center>Other</td>
 <td align=center>40</td>
 <td align=center>3.00</td>
 <td align=center>120</td>
 <td align=center>Stony Brook, NY, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1645">(1645) More</a></td>
 <td align=center>Algoritmo_Touch-By_Fabio_Marcio</td>
 <td align=center>Touch HPC</td>
 <td align=center>Other</td>
 <td align=center>18680</td>
 <td align=center>5.00</td>
 <td align=center>93400</td>
 <td align=center>Belo Horizonte-Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1644">(1644) More</a></td>
 <td align=center>csedcluster</td>
 <td align=center>National Institute Of Technology Calicut</td>
 <td align=center>Other</td>
 <td align=center>128</td>
 <td align=center>1.95</td>
 <td align=center>249.6</td>
 <td align=center>Calicut, Kerala, INDIA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1643">(1643) More</a></td>
 <td align=center>darius1</td>
 <td align=center>MIT</td>
 <td align=center>EM64T-4</td>
 <td align=center>272</td>
 <td align=center>2.26</td>
 <td align=center>2458.88</td>
 <td align=center>MA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1642">(1642) More</a></td>
 <td align=center>CRFLovell</td>
 <td align=center>Collaborative Research Foundation</td>
 <td align=center>Opteron</td>
 <td align=center>120</td>
 <td align=center>2.40</td>
 <td align=center>576</td>
 <td align=center>Wakefield, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1641">(1641) More</a></td>
 <td align=center>Ha-Cluster</td>
 <td align=center>RMUTL</td>
 <td align=center>EM64T-4</td>
 <td align=center>16</td>
 <td align=center>2.50</td>
 <td align=center>160</td>
 <td align=center>ChiangMai  Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1640">(1640) More</a></td>
 <td align=center>Nernst-Cluster</td>
 <td align=center>Humboldt-University</td>
 <td align=center>EM64T-4</td>
 <td align=center>32</td>
 <td align=center>3.65</td>
 <td align=center>467.2</td>
 <td align=center>Berlin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1639">(1639) More</a></td>
 <td align=center>rocks-cluster</td>
 <td align=center>Capital Markets CRC Ltd</td>
 <td align=center>EM64T-4</td>
 <td align=center>120</td>
 <td align=center>1.85</td>
 <td align=center>888</td>
 <td align=center>The Rocks</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1638">(1638) More</a></td>
 <td align=center>Carminati Cluster</td>
 <td align=center>UFT</td>
 <td align=center>EM64T</td>
 <td align=center>3</td>
 <td align=center>3.00</td>
 <td align=center>18</td>
 <td align=center>Palmas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1637">(1637) More</a></td>
 <td align=center>PHS Rocks</td>
 <td align=center>Henry Ford Health System</td>
 <td align=center>Other</td>
 <td align=center>120</td>
 <td align=center>2.40</td>
 <td align=center>288</td>
 <td align=center>Detroit, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1636">(1636) More</a></td>
 <td align=center>Arcturus</td>
 <td align=center>CMOP</td>
 <td align=center>EM64T-4</td>
 <td align=center>20</td>
 <td align=center>2.67</td>
 <td align=center>213.6</td>
 <td align=center>Beaverton</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1635">(1635) More</a></td>
 <td align=center>wotan</td>
 <td align=center>Materials Simulation Group (MSG)</td>
 <td align=center>Other</td>
 <td align=center>40</td>
 <td align=center>2.66</td>
 <td align=center>106.4</td>
 <td align=center>Badajoz (Spain)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1634">(1634) More</a></td>
 <td align=center>Triton</td>
 <td align=center>UCSD</td>
 <td align=center>EM64T-4</td>
 <td align=center>2944</td>
 <td align=center>2.40</td>
 <td align=center>28262.4</td>
 <td align=center>SDSC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1633">(1633) More</a></td>
 <td align=center>Bioinformatics Cluster</td>
 <td align=center>CCS HAU</td>
 <td align=center>Athlon 64</td>
 <td align=center>18</td>
 <td align=center>2.54</td>
 <td align=center>91.44</td>
 <td align=center>Hisar</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1632">(1632) More</a></td>
 <td align=center>GIKI Cluster</td>
 <td align=center>GIK Institute</td>
 <td align=center>Opteron</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>28.8</td>
 <td align=center>Topi, Pakistan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1631">(1631) More</a></td>
 <td align=center>Certainty</td>
 <td align=center>Stanford University</td>
 <td align=center>EM64T-4</td>
 <td align=center>6924</td>
 <td align=center>2.66</td>
 <td align=center>73671.36</td>
 <td align=center>Stanford</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1630">(1630) More</a></td>
 <td align=center>cclab-cluster</td>
 <td align=center>Humboldt State University</td>
 <td align=center>Athlon MP</td>
 <td align=center>10</td>
 <td align=center>2.40</td>
 <td align=center>48</td>
 <td align=center>Arcata</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1629">(1629) More</a></td>
 <td align=center>Sharifi.IUST</td>
 <td align=center>Iran University of Science and Technology- OS Research Lab</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.50</td>
 <td align=center>40</td>
 <td align=center>Tehran/Iran</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1628">(1628) More</a></td>
 <td align=center>ChemClusterUPC</td>
 <td align=center>China University of Petroleum</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>2.80</td>
 <td align=center>11.2</td>
 <td align=center>Tsingdao</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1627">(1627) More</a></td>
 <td align=center>Agave</td>
 <td align=center>ITVer</td>
 <td align=center>EM64T-4</td>
 <td align=center>32</td>
 <td align=center>3.00</td>
 <td align=center>384</td>
 <td align=center>Veracruz, Mexico</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1626">(1626) More</a></td>
 <td align=center>neuromancer</td>
 <td align=center>Federal Government</td>
 <td align=center>EM64T</td>
 <td align=center>512</td>
 <td align=center>2.50</td>
 <td align=center>2560</td>
 <td align=center>Minneapolis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1625">(1625) More</a></td>
 <td align=center>Greg-R-Carmichael</td>
 <td align=center>UNAB</td>
 <td align=center>EM64T-4</td>
 <td align=center>24</td>
 <td align=center>2.66</td>
 <td align=center>255.36</td>
 <td align=center>Santiago de Chile</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1624">(1624) More</a></td>
 <td align=center>Panther</td>
 <td align=center>Univ of Illinois at Urbana-Champaign</td>
 <td align=center>Unspecified</td>
 <td align=center>32</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>Urbana</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1623">(1623) More</a></td>
 <td align=center>Hugo</td>
 <td align=center>Research Center Pharmaceutical Engineering</td>
 <td align=center>EM64T</td>
 <td align=center>144</td>
 <td align=center>2.70</td>
 <td align=center>777.6</td>
 <td align=center>Graz</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1622">(1622) More</a></td>
 <td align=center>debian01.petersenserver.com</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>2.00</td>
 <td align=center>6</td>
 <td align=center>Anchorage</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1621">(1621) More</a></td>
 <td align=center>UACh Cluster</td>
 <td align=center>Universidad Austral de Chile</td>
 <td align=center>Athlon 64</td>
 <td align=center>5</td>
 <td align=center>2.70</td>
 <td align=center>27</td>
 <td align=center>Valdivia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1620">(1620) More</a></td>
 <td align=center>nano</td>
 <td align=center>ICMAB-CSIC</td>
 <td align=center>EM64T</td>
 <td align=center>192</td>
 <td align=center>2.50</td>
 <td align=center>960</td>
 <td align=center>Barcelona</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1619">(1619) More</a></td>
 <td align=center>pico</td>
 <td align=center>ICMAB-CSIC</td>
 <td align=center>EM64T</td>
 <td align=center>192</td>
 <td align=center>2.50</td>
 <td align=center>960</td>
 <td align=center>Barcelona</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1618">(1618) More</a></td>
 <td align=center>Joseph Kraemer</td>
 <td align=center>RAMS</td>
 <td align=center>EM64T-4</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>Canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1617">(1617) More</a></td>
 <td align=center>nigel65</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium</td>
 <td align=center>1</td>
 <td align=center>2.10</td>
 <td align=center>2.1</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1616">(1616) More</a></td>
 <td align=center>SARAHS Cluster</td>
 <td align=center>UBC Okanagan</td>
 <td align=center>EM64T</td>
 <td align=center>72</td>
 <td align=center>1.86</td>
 <td align=center>267.84</td>
 <td align=center>Kelowna</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1615">(1615) More</a></td>
 <td align=center>rc</td>
 <td align=center>lvcm</td>
 <td align=center>Other</td>
 <td align=center>24</td>
 <td align=center>2.80</td>
 <td align=center>67.2</td>
 <td align=center>Las Vegas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1614">(1614) More</a></td>
 <td align=center>UTAR</td>
 <td align=center>UTAR</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>2.66</td>
 <td align=center>10.64</td>
 <td align=center>Malaysia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1613">(1613) More</a></td>
 <td align=center>MORU Rocky</td>
 <td align=center>MORU</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>2.50</td>
 <td align=center>200</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1612">(1612) More</a></td>
 <td align=center>Nopal.cluster</td>
 <td align=center>ITVer</td>
 <td align=center>Athlon 64</td>
 <td align=center>40</td>
 <td align=center>2.30</td>
 <td align=center>184</td>
 <td align=center>Veracruz</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1611">(1611) More</a></td>
 <td align=center>Lobster</td>
 <td align=center>Biology, Chemistry, Physics Dept</td>
 <td align=center>Pentium 4</td>
 <td align=center>27</td>
 <td align=center>1.90</td>
 <td align=center>102.6</td>
 <td align=center>Oshkosh, Wi</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1610">(1610) More</a></td>
 <td align=center>TK2</td>
 <td align=center>Case Western Reserve University</td>
 <td align=center>Unspecified</td>
 <td align=center>36</td>
 <td align=center>2.40</td>
 <td align=center>86.4</td>
 <td align=center>Cleveland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1609">(1609) More</a></td>
 <td align=center>sciblade</td>
 <td align=center>HPCCC, Faculty of Science, Hong Kong Baptist University</td>
 <td align=center>EM64T-4</td>
 <td align=center>2048</td>
 <td align=center>2.66</td>
 <td align=center>21790.72</td>
 <td align=center>Hong Kong, PR China</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1608">(1608) More</a></td>
 <td align=center>Funes</td>
 <td align=center>University of Texas at Brownsville</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>3.20</td>
 <td align=center>819.2</td>
 <td align=center>Brownsville</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1607">(1607) More</a></td>
 <td align=center>LHS Cluster</td>
 <td align=center>Aston University</td>
 <td align=center>EM64T-4</td>
 <td align=center>48</td>
 <td align=center>2.50</td>
 <td align=center>480</td>
 <td align=center>Birmingham, United Kingdom</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1606">(1606) More</a></td>
 <td align=center>INTI-AyE-Cluster0</td>
 <td align=center>INTI AyE</td>
 <td align=center>Other</td>
 <td align=center>20</td>
 <td align=center>2.67</td>
 <td align=center>53.4</td>
 <td align=center>San Martin,Buenos Aires, Argentina</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1605">(1605) More</a></td>
 <td align=center>Cassini</td>
 <td align=center>Molecular Biology Institute at UCLA</td>
 <td align=center>Opteron</td>
 <td align=center>640</td>
 <td align=center>2.54</td>
 <td align=center>3251.2</td>
 <td align=center>Los Angeles</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1604">(1604) More</a></td>
 <td align=center>cortex_cluster</td>
 <td align=center>UNLV</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Las Vegas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1603">(1603) More</a></td>
 <td align=center>Petersens-cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>4</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1602">(1602) More</a></td>
 <td align=center>Evolution</td>
 <td align=center>Harvard-MIT Health Sciences and Technology</td>
 <td align=center>Other</td>
 <td align=center>10</td>
 <td align=center>2.26</td>
 <td align=center>22.6</td>
 <td align=center>Cambridge, MA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1600">(1600) More</a></td>
 <td align=center>macbeth</td>
 <td align=center>Princeton University</td>
 <td align=center>Other</td>
 <td align=center>32</td>
 <td align=center>3.00</td>
 <td align=center>96</td>
 <td align=center>Princeton</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1599">(1599) More</a></td>
 <td align=center>psych</td>
 <td align=center>Minnesota Center for Twin and Family Research, University of MN</td>
 <td align=center>Opteron</td>
 <td align=center>120</td>
 <td align=center>2.40</td>
 <td align=center>576</td>
 <td align=center>Minneapolis, Minnesota</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1598">(1598) More</a></td>
 <td align=center>polymath</td>
 <td align=center>Private</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.00</td>
 <td align=center>256</td>
 <td align=center>Del Valle, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1597">(1597) More</a></td>
 <td align=center>Molecular Resource Center</td>
 <td align=center>The University of Tennessee Health Science Center</td>
 <td align=center>Other</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>32</td>
 <td align=center>Memphis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1596">(1596) More</a></td>
 <td align=center>SZABIST-Rocks</td>
 <td align=center>SZABIST</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.86</td>
 <td align=center>57.2</td>
 <td align=center>Dubai, UAE</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1595">(1595) More</a></td>
 <td align=center>D-A-N-X 2</td>
 <td align=center>CAMBO s.a.s. - www.rocksclusters.it</td>
 <td align=center>EM64T-4</td>
 <td align=center>40</td>
 <td align=center>2.26</td>
 <td align=center>361.6</td>
 <td align=center>Italy, Telve Valsugana - Trentino</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1594">(1594) More</a></td>
 <td align=center>manticore</td>
 <td align=center>National Human Genome Research Institute (NIH)</td>
 <td align=center>Opteron</td>
 <td align=center>62</td>
 <td align=center>2.40</td>
 <td align=center>297.6</td>
 <td align=center>Bethesda</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1593">(1593) More</a></td>
 <td align=center>Teera</td>
 <td align=center>Thailand</td>
 <td align=center>EM64T</td>
 <td align=center>2</td>
 <td align=center>2.10</td>
 <td align=center>8.4</td>
 <td align=center>Nakhon Si Thammarat Rajabhat University</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1592">(1592) More</a></td>
 <td align=center>paramgem</td>
 <td align=center>NEIST</td>
 <td align=center>Opteron</td>
 <td align=center>128</td>
 <td align=center>2.50</td>
 <td align=center>640</td>
 <td align=center>JORHAT</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1591">(1591) More</a></td>
 <td align=center>MMURocks-Cluster</td>
 <td align=center>Multimedia University Cyberjaya</td>
 <td align=center>EM64T-4</td>
 <td align=center>2</td>
 <td align=center>2.13</td>
 <td align=center>17.04</td>
 <td align=center>Malaysia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1590">(1590) More</a></td>
 <td align=center>Human Genetics Resources Core Grid</td>
 <td align=center>Columbia University Sergievsky Center</td>
 <td align=center>Other</td>
 <td align=center>176</td>
 <td align=center>2.93</td>
 <td align=center>515.68</td>
 <td align=center>New York</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1588">(1588) More</a></td>
 <td align=center>nwu-hpcprod1</td>
 <td align=center>North-West University</td>
 <td align=center>EM64T-4</td>
 <td align=center>376</td>
 <td align=center>3.00</td>
 <td align=center>4512</td>
 <td align=center>Potchefstroom - South-Africa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1587">(1587) More</a></td>
 <td align=center>pythagoras</td>
 <td align=center>Dept of Mathematics, Aegean University</td>
 <td align=center>Other</td>
 <td align=center>60</td>
 <td align=center>2.00</td>
 <td align=center>120</td>
 <td align=center>Karlovasi, Samos Island, Greece</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1586">(1586) More</a></td>
 <td align=center>fresno</td>
 <td align=center>LSTC</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>2.26</td>
 <td align=center>144.64</td>
 <td align=center>Livermore, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1585">(1585) More</a></td>
 <td align=center>florida</td>
 <td align=center>LSTC</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>2.26</td>
 <td align=center>180.8</td>
 <td align=center>Livermore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1584">(1584) More</a></td>
 <td align=center>SIOC Cluster</td>
 <td align=center>Shanghai Institute of Organic Chemistry</td>
 <td align=center>EM64T-4</td>
 <td align=center>128</td>
 <td align=center>2.33</td>
 <td align=center>1192.96</td>
 <td align=center>Shanghai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1583">(1583) More</a></td>
 <td align=center>hercules.uio.no</td>
 <td align=center>ITA/University of Oslo</td>
 <td align=center>Opteron</td>
 <td align=center>94</td>
 <td align=center>2.20</td>
 <td align=center>413.6</td>
 <td align=center>Oslo, Norway</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1582">(1582) More</a></td>
 <td align=center>MetClus</td>
 <td align=center>Meteorological Marine Forecast and Research Office</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.20</td>
 <td align=center>52.8</td>
 <td align=center>Bandar Anzali - Iran</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1581">(1581) More</a></td>
 <td align=center>Ramonet</td>
 <td align=center>DICC-UJI</td>
 <td align=center>EM64T</td>
 <td align=center>50</td>
 <td align=center>2.40</td>
 <td align=center>240</td>
 <td align=center>Castellon</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1580">(1580) More</a></td>
 <td align=center>Doom</td>
 <td align=center>Bitterwolf Legion of Darkness</td>
 <td align=center>EM64T-4</td>
 <td align=center>28</td>
 <td align=center>2.80</td>
 <td align=center>313.6</td>
 <td align=center>Moscow, ID</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1579">(1579) More</a></td>
 <td align=center>cluster.xll</td>
 <td align=center>XLL</td>
 <td align=center>Unspecified</td>
 <td align=center>16</td>
 <td align=center>3.60</td>
 <td align=center>57.6</td>
 <td align=center>Ahmedabad</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1577">(1577) More</a></td>
 <td align=center>IdeeFabrik</td>
 <td align=center>DRHPCC</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>1.80</td>
 <td align=center>57.6</td>
 <td align=center>De Rust, South Africa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1576">(1576) More</a></td>
 <td align=center>Shahrood university</td>
 <td align=center>Shahrood University Of technology</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>2.50</td>
 <td align=center>25</td>
 <td align=center>Shahrood University , Shahrood , Iran</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1575">(1575) More</a></td>
 <td align=center>CASPER</td>
 <td align=center>Politecnico di Torino</td>
 <td align=center>Opteron</td>
 <td align=center>448</td>
 <td align=center>3.20</td>
 <td align=center>2867.2</td>
 <td align=center>Turin, Italy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1574">(1574) More</a></td>
 <td align=center>USTC T3 Cluster</td>
 <td align=center>USTC</td>
 <td align=center>EM64T-4</td>
 <td align=center>256</td>
 <td align=center>2.26</td>
 <td align=center>2314.24</td>
 <td align=center>Hefei, China</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1573">(1573) More</a></td>
 <td align=center>Teo En Ming (Zhang Enming) Virtual Rocks HPC Cluster</td>
 <td align=center>Teo En Ming (Zhang Enming) Virtual Supercomputer Center</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Bedok Reservoir Road, Singapore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1572">(1572) More</a></td>
 <td align=center>kronos</td>
 <td align=center>UW-Madison Dept. Atmos. & Oceanic Sci.</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>2.40</td>
 <td align=center>115.2</td>
 <td align=center>Madison, WI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1571">(1571) More</a></td>
 <td align=center>Virtual Plant</td>
 <td align=center>NYU Biology Dept.</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>3.00</td>
 <td align=center>384</td>
 <td align=center>New York City</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1570">(1570) More</a></td>
 <td align=center>192.168.104</td>
 <td align=center>USTC</td>
 <td align=center>Athlon 64</td>
 <td align=center>8</td>
 <td align=center>2.70</td>
 <td align=center>43.2</td>
 <td align=center>hefei</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1569">(1569) More</a></td>
 <td align=center>Macrotux</td>
 <td align=center>Isfahan University</td>
 <td align=center>Opteron</td>
 <td align=center>4</td>
 <td align=center>1.00</td>
 <td align=center>8</td>
 <td align=center>Isfahan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1568">(1568) More</a></td>
 <td align=center>helpdesk-botswana</td>
 <td align=center>HelpDESK SOLUTIONS</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>36</td>
 <td align=center>Botswana</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1566">(1566) More</a></td>
 <td align=center>fuzul</td>
 <td align=center>eu</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>1.80</td>
 <td align=center>10.8</td>
 <td align=center>iran esfahan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1565">(1565) More</a></td>
 <td align=center>CPE Cluster</td>
 <td align=center>CPE</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>RMUTT</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1564">(1564) More</a></td>
 <td align=center>aguadas</td>
 <td align=center>Universidad EAFIT - Laboratorio de mecanica aplicada</td>
 <td align=center>EM64T</td>
 <td align=center>48</td>
 <td align=center>2.60</td>
 <td align=center>249.6</td>
 <td align=center>Medellin, Colombia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1563">(1563) More</a></td>
 <td align=center>Gallery</td>
 <td align=center>IEMS</td>
 <td align=center>Other</td>
 <td align=center>24</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>Northwestern University</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1562">(1562) More</a></td>
 <td align=center>Tandar</td>
 <td align=center>CNEA</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>2.27</td>
 <td align=center>72.64</td>
 <td align=center>Buenos Aires</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1561">(1561) More</a></td>
 <td align=center>Lothar</td>
 <td align=center>SMS-Meteocenter</td>
 <td align=center>EM64T-4</td>
 <td align=center>560</td>
 <td align=center>2.66</td>
 <td align=center>5958.4</td>
 <td align=center>Faenza</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1560">(1560) More</a></td>
 <td align=center>CentosOR</td>
 <td align=center>CENTRUM Catolica</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>28.8</td>
 <td align=center>Lima, Peru</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1559">(1559) More</a></td>
 <td align=center>dell test</td>
 <td align=center>NJIT</td>
 <td align=center>Athlon 64</td>
 <td align=center>4</td>
 <td align=center>2.20</td>
 <td align=center>17.6</td>
 <td align=center>Newark</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1558">(1558) More</a></td>
 <td align=center>SeekerFT</td>
 <td align=center>FT</td>
 <td align=center>EM64T-4</td>
 <td align=center>384</td>
 <td align=center>2.00</td>
 <td align=center>3072</td>
 <td align=center>Cambridge</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1557">(1557) More</a></td>
 <td align=center>mendelevium</td>
 <td align=center>University of Calgary, Dept of Chemistry</td>
 <td align=center>EM64T</td>
 <td align=center>65</td>
 <td align=center>3.40</td>
 <td align=center>442</td>
 <td align=center>Calgary, Alberta, Canada</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1556">(1556) More</a></td>
 <td align=center>avex-64</td>
 <td align=center>Los Alamos National Laboratory</td>
 <td align=center>Opteron</td>
 <td align=center>72</td>
 <td align=center>2.50</td>
 <td align=center>360</td>
 <td align=center>Los Alamos, NM</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1555">(1555) More</a></td>
 <td align=center>Phobos</td>
 <td align=center>Element Networx</td>
 <td align=center>EM64T-4</td>
 <td align=center>28</td>
 <td align=center>2.66</td>
 <td align=center>297.92</td>
 <td align=center>Rochester, NY</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1554">(1554) More</a></td>
 <td align=center>Sherlock by Nor-tech</td>
 <td align=center>U of W</td>
 <td align=center>EM64T-4</td>
 <td align=center>56</td>
 <td align=center>2.50</td>
 <td align=center>560</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1553">(1553) More</a></td>
 <td align=center>sporades by Nor-tech</td>
 <td align=center>U of M</td>
 <td align=center>Opteron</td>
 <td align=center>512</td>
 <td align=center>2.53</td>
 <td align=center>2590.72</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1551">(1551) More</a></td>
 <td align=center>duzunsys</td>
 <td align=center>DUzunSys</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.00</td>
 <td align=center>12</td>
 <td align=center>Chisinau MDA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1550">(1550) More</a></td>
 <td align=center>SENA_Wx</td>
 <td align=center>Shell Energy North America</td>
 <td align=center>EM64T-4</td>
 <td align=center>128</td>
 <td align=center>2.80</td>
 <td align=center>1433.6</td>
 <td align=center>Houston</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1549">(1549) More</a></td>
 <td align=center>WPUNJ Science Cluster</td>
 <td align=center>William Paterson University</td>
 <td align=center>Opteron</td>
 <td align=center>20</td>
 <td align=center>1.00</td>
 <td align=center>40</td>
 <td align=center>Wayne, NJ</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1548">(1548) More</a></td>
 <td align=center>cub</td>
 <td align=center>University of Lugano</td>
 <td align=center>Opteron</td>
 <td align=center>336</td>
 <td align=center>2.70</td>
 <td align=center>1814.4</td>
 <td align=center>Lugano, Switzerland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1547">(1547) More</a></td>
 <td align=center>pavelvolinkiinss</td>
 <td align=center>pavelvolinkiinss</td>
 <td align=center>Athlon</td>
 <td align=center>200</td>
 <td align=center>2.30</td>
 <td align=center>460</td>
 <td align=center>Virgin Islands</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1546">(1546) More</a></td>
 <td align=center>hartree1</td>
 <td align=center>Departamento de Química, Universidade Federal de Minas Gerais</td>
 <td align=center>EM64T</td>
 <td align=center>5</td>
 <td align=center>2.66</td>
 <td align=center>26.6</td>
 <td align=center>Belo Horizonte, Minas Gerais, Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1545">(1545) More</a></td>
 <td align=center>QCG@Tandar</td>
 <td align=center>Laboratorio Tandar - CNEA</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.10</td>
 <td align=center>67.2</td>
 <td align=center>Buenos Aires, Argentina</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1544">(1544) More</a></td>
 <td align=center>seaman</td>
 <td align=center>ETA</td>
 <td align=center>EM64T</td>
 <td align=center>4</td>
 <td align=center>2.00</td>
 <td align=center>16</td>
 <td align=center>Shanghai</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1543">(1543) More</a></td>
 <td align=center>Banyuhay</td>
 <td align=center>Advanced Science and Technology Institute</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.00</td>
 <td align=center>512</td>
 <td align=center>Quezon City, Philippines</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1542">(1542) More</a></td>
 <td align=center>Buhawi</td>
 <td align=center>Advanced Science and Technology Institute</td>
 <td align=center>EM64T-4</td>
 <td align=center>128</td>
 <td align=center>2.00</td>
 <td align=center>1024</td>
 <td align=center>Quezon City, Philippines</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1541">(1541) More</a></td>
 <td align=center>Dalubhasaan</td>
 <td align=center>Advanced Science and Technology Institute</td>
 <td align=center>EM64T-4</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>128</td>
 <td align=center>Quezon City, Philippines</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1540">(1540) More</a></td>
 <td align=center>DCK</td>
 <td align=center>Case Western Reserve University</td>
 <td align=center>EM64T</td>
 <td align=center>104</td>
 <td align=center>2.40</td>
 <td align=center>499.2</td>
 <td align=center>Cleveland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1539">(1539) More</a></td>
 <td align=center>fgc-analysis</td>
 <td align=center>University of Rochester</td>
 <td align=center>EM64T-4</td>
 <td align=center>12</td>
 <td align=center>2.27</td>
 <td align=center>108.96</td>
 <td align=center>Rochester, NY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1538">(1538) More</a></td>
 <td align=center>Cray CX1</td>
 <td align=center>Cray</td>
 <td align=center>EM64T-4</td>
 <td align=center>16</td>
 <td align=center>3.00</td>
 <td align=center>192</td>
 <td align=center>Seattle</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1537">(1537) More</a></td>
 <td align=center>tukey</td>
 <td align=center>University of Washington</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.26</td>
 <td align=center>578.56</td>
 <td align=center>Seattle</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1536">(1536) More</a></td>
 <td align=center>CLUSTER-LME</td>
 <td align=center>Facultad de Ingenieria - Universidad Nacional de Asuncion</td>
 <td align=center>Other</td>
 <td align=center>10</td>
 <td align=center>2.20</td>
 <td align=center>22</td>
 <td align=center>San Lorenzo, PY</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1535">(1535) More</a></td>
 <td align=center>HYcluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.80</td>
 <td align=center>44.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1534">(1534) More</a></td>
 <td align=center>Gobstopr</td>
 <td align=center>Wayland Baptist University</td>
 <td align=center>Pentium 4</td>
 <td align=center>22</td>
 <td align=center>2.73</td>
 <td align=center>120.12</td>
 <td align=center>Plainview, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1533">(1533) More</a></td>
 <td align=center>GHCGroup Cluster</td>
 <td align=center>HKU</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>1.80</td>
 <td align=center>72</td>
 <td align=center>Hong Kong</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1532">(1532) More</a></td>
 <td align=center>resolute</td>
 <td align=center>The Children's Hospital of Philadelphia</td>
 <td align=center>Opteron</td>
 <td align=center>320</td>
 <td align=center>2.50</td>
 <td align=center>1600</td>
 <td align=center>Philadelphia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1531">(1531) More</a></td>
 <td align=center>bolle</td>
 <td align=center>Politecnico di Torino - Dept. Chemical Engineering</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>2.10</td>
 <td align=center>336</td>
 <td align=center>Torino</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1530">(1530) More</a></td>
 <td align=center>BT_cluster</td>
 <td align=center>Betimes</td>
 <td align=center>EM64T-4</td>
 <td align=center>12</td>
 <td align=center>2.33</td>
 <td align=center>111.84</td>
 <td align=center>bkk</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1529">(1529) More</a></td>
 <td align=center>EGC CLuster</td>
 <td align=center>INRA - UMR EGC</td>
 <td align=center>EM64T-4</td>
 <td align=center>60</td>
 <td align=center>1.86</td>
 <td align=center>446.4</td>
 <td align=center>78850 Thiverval-Grignon - FRANCE</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1528">(1528) More</a></td>
 <td align=center>asviz1</td>
 <td align=center>VeRSI</td>
 <td align=center>EM64T-4</td>
 <td align=center>44</td>
 <td align=center>2.50</td>
 <td align=center>440</td>
 <td align=center>Clayton, Victoria, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1527">(1527) More</a></td>
 <td align=center>DATCAP</td>
 <td align=center>University of Otago - Dept. Finance and Quantitative Analysis</td>
 <td align=center>Pentium 4</td>
 <td align=center>41</td>
 <td align=center>3.00</td>
 <td align=center>246</td>
 <td align=center>Dunedin, New Zealand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1526">(1526) More</a></td>
 <td align=center>Amon Cluster</td>
 <td align=center>University of Illinois at Springfield, Computer Science Club</td>
 <td align=center>Pentium 3</td>
 <td align=center>33</td>
 <td align=center>1.10</td>
 <td align=center>36.3</td>
 <td align=center>Springfield, Illinois</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1525">(1525) More</a></td>
 <td align=center>RWM_Wx Cluster</td>
 <td align=center>RWM Weather Services</td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>3.00</td>
 <td align=center>72</td>
 <td align=center>Houston</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1524">(1524) More</a></td>
 <td align=center>shiva</td>
 <td align=center>Personal use</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>0.80</td>
 <td align=center>6.4</td>
 <td align=center>Ringgold, Louisiana</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1523">(1523) More</a></td>
 <td align=center>nautilus</td>
 <td align=center>CIIMAR - Universidade do Porto</td>
 <td align=center>Athlon 64</td>
 <td align=center>164</td>
 <td align=center>2.10</td>
 <td align=center>688.8</td>
 <td align=center>Porto, Portugal</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1522">(1522) More</a></td>
 <td align=center>Yisrael Cluster</td>
 <td align=center>Center for the Study of Digital Libraries, Texas A&M University</td>
 <td align=center>Pentium 4</td>
 <td align=center>44</td>
 <td align=center>2.40</td>
 <td align=center>211.2</td>
 <td align=center>College Station, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1520">(1520) More</a></td>
 <td align=center>SCENZ-Grid</td>
 <td align=center>Landcare Research</td>
 <td align=center>EM64T-4</td>
 <td align=center>104</td>
 <td align=center>2.79</td>
 <td align=center>1160.64</td>
 <td align=center>New Zealand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1519">(1519) More</a></td>
 <td align=center>gridtmd</td>
 <td align=center>Thai meteorological Department</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1518">(1518) More</a></td>
 <td align=center>Cimplx HPC</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>50</td>
 <td align=center>1.80</td>
 <td align=center>180</td>
 <td align=center>Auckland, New Zealand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1517">(1517) More</a></td>
 <td align=center>Grid TMD</td>
 <td align=center>Meteorological Department</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>BangNa, Bangkok, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1516">(1516) More</a></td>
 <td align=center>IBMM Cluster</td>
 <td align=center>IBMM</td>
 <td align=center>EM64T</td>
 <td align=center>60</td>
 <td align=center>3.00</td>
 <td align=center>360</td>
 <td align=center>Montpellier, France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1515">(1515) More</a></td>
 <td align=center>Aquiles Cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium</td>
 <td align=center>10</td>
 <td align=center>2.40</td>
 <td align=center>24</td>
 <td align=center>Temuco</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1514">(1514) More</a></td>
 <td align=center>NHMC Cluster for Evolution</td>
 <td align=center>Natural History Museum of Crete, University of Crete</td>
 <td align=center>Athlon 64</td>
 <td align=center>44</td>
 <td align=center>2.80</td>
 <td align=center>246.4</td>
 <td align=center>Heraklion, Crete</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1513">(1513) More</a></td>
 <td align=center>Smokey</td>
 <td align=center>VTT</td>
 <td align=center>EM64T</td>
 <td align=center>120</td>
 <td align=center>3.00</td>
 <td align=center>720</td>
 <td align=center>Espoo, Finland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1512">(1512) More</a></td>
 <td align=center>Bukka Cluster</td>
 <td align=center>University of Shizuoka</td>
 <td align=center>EM64T</td>
 <td align=center>72</td>
 <td align=center>2.50</td>
 <td align=center>360</td>
 <td align=center>Shizuoka, JAPAN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1511">(1511) More</a></td>
 <td align=center>Dragonfish</td>
 <td align=center>Tallinn University of Technology, CBIS</td>
 <td align=center>EM64T</td>
 <td align=center>176</td>
 <td align=center>2.26</td>
 <td align=center>795.52</td>
 <td align=center>Tallinn, Estonia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1510">(1510) More</a></td>
 <td align=center>ECS</td>
 <td align=center>ECS, Victoria University of Wellington</td>
 <td align=center>Pentium 4</td>
 <td align=center>7</td>
 <td align=center>3.20</td>
 <td align=center>44.8</td>
 <td align=center>Wellington, New Zealand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1509">(1509) More</a></td>
 <td align=center>jgseecluster</td>
 <td align=center>The Joint Graduate School of Energy and Environment (JGSEE)</td>
 <td align=center>EM64T-4</td>
 <td align=center>2</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1508">(1508) More</a></td>
 <td align=center>krg-cluster</td>
 <td align=center>Northwestern University</td>
 <td align=center>Opteron</td>
 <td align=center>168</td>
 <td align=center>2.20</td>
 <td align=center>739.2</td>
 <td align=center>Evanston, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1507">(1507) More</a></td>
 <td align=center>phys-6node</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T-4</td>
 <td align=center>10</td>
 <td align=center>2.50</td>
 <td align=center>100</td>
 <td align=center>Tiruchirappalli</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1506">(1506) More</a></td>
 <td align=center>HPC CLUSTER CCT ROSARIO CONICET</td>
 <td align=center>CCT ROSARIO CONICET</td>
 <td align=center>EM64T-4</td>
 <td align=center>336</td>
 <td align=center>2.50</td>
 <td align=center>3360</td>
 <td align=center>ROSARIO</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1505">(1505) More</a></td>
 <td align=center>ISDC Cluster</td>
 <td align=center>ISDC</td>
 <td align=center>EM64T</td>
 <td align=center>168</td>
 <td align=center>2.50</td>
 <td align=center>840</td>
 <td align=center>Versoix, CH</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1504">(1504) More</a></td>
 <td align=center>Siricluster</td>
 <td align=center>jntu</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>Hyderabad</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1503">(1503) More</a></td>
 <td align=center>mcmike567 RoomTech Blender Cluster 1</td>
 <td align=center>RoomTech mcmike567</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>2.80</td>
 <td align=center>11.2</td>
 <td align=center>Duxbury, MA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1502">(1502) More</a></td>
 <td align=center>Cylonet</td>
 <td align=center>FM High Performance Computing Club</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.00</td>
 <td align=center>40</td>
 <td align=center>Manlius</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1501">(1501) More</a></td>
 <td align=center>Trans-Neptunian</td>
 <td align=center>Catalan Institute of Oncology - BBU</td>
 <td align=center>Opteron</td>
 <td align=center>164</td>
 <td align=center>2.10</td>
 <td align=center>688.8</td>
 <td align=center>Barcelona</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1500">(1500) More</a></td>
 <td align=center>ruska</td>
 <td align=center>IFSC</td>
 <td align=center>EM64T</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>36</td>
 <td align=center>Sao Carlos</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1499">(1499) More</a></td>
 <td align=center>Raul</td>
 <td align=center>CSS</td>
 <td align=center>Itanium</td>
 <td align=center>3</td>
 <td align=center>3.20</td>
 <td align=center>38.4</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1498">(1498) More</a></td>
 <td align=center>C-NOOFS Development Grid</td>
 <td align=center>Fisheries and Oceans Canada</td>
 <td align=center>Opteron</td>
 <td align=center>50</td>
 <td align=center>2.80</td>
 <td align=center>280</td>
 <td align=center>St. Johns, NL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1497">(1497) More</a></td>
 <td align=center>grove</td>
 <td align=center>CU Boulder Chemistry Dept, Michl Group</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>2.70</td>
 <td align=center>432</td>
 <td align=center>Boulder USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1495">(1495) More</a></td>
 <td align=center>Argo</td>
 <td align=center>University of Nevada, Reno</td>
 <td align=center>Opteron</td>
 <td align=center>800</td>
 <td align=center>2.10</td>
 <td align=center>3360</td>
 <td align=center>Reno, NV</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1494">(1494) More</a></td>
 <td align=center>Alcatraz</td>
 <td align=center>Indiana University Dept of Medical Genetics</td>
 <td align=center>Opteron</td>
 <td align=center>58</td>
 <td align=center>2.21</td>
 <td align=center>256.36</td>
 <td align=center>Indianapolis, IN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1493">(1493) More</a></td>
 <td align=center>CSH Cluster</td>
 <td align=center>Ball State Univeristy, College of Sciences and Humanities</td>
 <td align=center>EM64T</td>
 <td align=center>126</td>
 <td align=center>3.52</td>
 <td align=center>887.04</td>
 <td align=center>Muncie</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1492">(1492) More</a></td>
 <td align=center>Quark</td>
 <td align=center>Motorola</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>3.06</td>
 <td align=center>48.96</td>
 <td align=center>Schaumburg, IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1491">(1491) More</a></td>
 <td align=center>MLS Abacus</td>
 <td align=center>Microwave Limb Sounder/Jet Propulsion Laboratory</td>
 <td align=center>Unspecified</td>
 <td align=center>56</td>
 <td align=center>3.06</td>
 <td align=center>171.36</td>
 <td align=center>Pasadena, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1490">(1490) More</a></td>
 <td align=center>MLS Cool</td>
 <td align=center>Microwave Limb Sounder/Jet Propulsion Laboratory</td>
 <td align=center>Pentium 3</td>
 <td align=center>28</td>
 <td align=center>1.00</td>
 <td align=center>28</td>
 <td align=center>Pasadena, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1489">(1489) More</a></td>
 <td align=center>TES SIPS Strawman</td>
 <td align=center>Jet Propulsion Laboratory / Tropospheric Emission Spectrometer</td>
 <td align=center>EM64T-4</td>
 <td align=center>976</td>
 <td align=center>3.00</td>
 <td align=center>11712</td>
 <td align=center>Pasadena, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1488">(1488) More</a></td>
 <td align=center>MLS Scramjet</td>
 <td align=center>Microwave Limb Sounder/Jet Propulsion Laboratory</td>
 <td align=center>Pentium 4</td>
 <td align=center>364</td>
 <td align=center>3.06</td>
 <td align=center>2227.68</td>
 <td align=center>Pasadena, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1487">(1487) More</a></td>
 <td align=center>sneth2</td>
 <td align=center>University of Rochester, Dept of Physics and Astronomy</td>
 <td align=center>Other</td>
 <td align=center>5</td>
 <td align=center>3.00</td>
 <td align=center>15</td>
 <td align=center>Rochester, NY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1486">(1486) More</a></td>
 <td align=center>lpqsv6</td>
 <td align=center>Laboratoire de Chimie et Physique Quantiques</td>
 <td align=center>Other</td>
 <td align=center>80</td>
 <td align=center>3.16</td>
 <td align=center>252.8</td>
 <td align=center>Toulouse-France</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1485">(1485) More</a></td>
 <td align=center>GAcluster</td>
 <td align=center>Macrogen</td>
 <td align=center>EM64T-4</td>
 <td align=center>36</td>
 <td align=center>1.86</td>
 <td align=center>267.84</td>
 <td align=center>SEOUL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1484">(1484) More</a></td>
 <td align=center>ORIGINS</td>
 <td align=center>ORIGINS S.A</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>36</td>
 <td align=center>Barcelona</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1482">(1482) More</a></td>
 <td align=center>MartinsClusterHA</td>
 <td align=center>MartinsLabs</td>
 <td align=center>Athlon 64</td>
 <td align=center>4</td>
 <td align=center>2.65</td>
 <td align=center>21.2</td>
 <td align=center>Medellin - Colombia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1481">(1481) More</a></td>
 <td align=center>compute-0-0</td>
 <td align=center>ubsolutions</td>
 <td align=center>Pentium</td>
 <td align=center>1</td>
 <td align=center>3.00</td>
 <td align=center>3</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1480">(1480) More</a></td>
 <td align=center>protoss</td>
 <td align=center>Instituto de Fisica de Sao Carlos</td>
 <td align=center>EM64T</td>
 <td align=center>48</td>
 <td align=center>2.40</td>
 <td align=center>230.4</td>
 <td align=center>Sao Carlos - SP</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1479">(1479) More</a></td>
 <td align=center>hive</td>
 <td align=center>pace</td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>1.80</td>
 <td align=center>5.4</td>
 <td align=center>mangalore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1478">(1478) More</a></td>
 <td align=center>genomnia</td>
 <td align=center>genomnia srl</td>
 <td align=center>Pentium</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>32</td>
 <td align=center>Lainate, Milano, Italy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1477">(1477) More</a></td>
 <td align=center>RIGELK</td>
 <td align=center>CMOP</td>
 <td align=center>Pentium 4</td>
 <td align=center>34</td>
 <td align=center>2.40</td>
 <td align=center>163.2</td>
 <td align=center>Beaverton</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1476">(1476) More</a></td>
 <td align=center>sunfish</td>
 <td align=center>TTU, Center for Biology of Integrated Systems</td>
 <td align=center>Athlon</td>
 <td align=center>11</td>
 <td align=center>2.20</td>
 <td align=center>24.2</td>
 <td align=center>Tallinn, Estonia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1475">(1475) More</a></td>
 <td align=center>kulfy</td>
 <td align=center>LESL</td>
 <td align=center>Opteron</td>
 <td align=center>2</td>
 <td align=center>2.19</td>
 <td align=center>8.76</td>
 <td align=center>Bangalore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1474">(1474) More</a></td>
 <td align=center>AstroSubClusterVienna</td>
 <td align=center>Vienna University, Institute fo Astronomy</td>
 <td align=center>Athlon XP</td>
 <td align=center>2</td>
 <td align=center>2.60</td>
 <td align=center>10.4</td>
 <td align=center>Vienna, Austira, Europe</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1473">(1473) More</a></td>
 <td align=center>AZP</td>
 <td align=center>Princeton University ChemE</td>
 <td align=center>Other</td>
 <td align=center>250</td>
 <td align=center>2.83</td>
 <td align=center>707.5</td>
 <td align=center>Princeton</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1472">(1472) More</a></td>
 <td align=center>Eros</td>
 <td align=center>University of Geneva</td>
 <td align=center>EM64T-4</td>
 <td align=center>20</td>
 <td align=center>2.83</td>
 <td align=center>226.4</td>
 <td align=center>Geneva, Switzerland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1471">(1471) More</a></td>
 <td align=center>Venus</td>
 <td align=center>University of Geneva</td>
 <td align=center>EM64T-4</td>
 <td align=center>16</td>
 <td align=center>2.66</td>
 <td align=center>170.24</td>
 <td align=center>Geneva, Switzerland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1470">(1470) More</a></td>
 <td align=center>grid</td>
 <td align=center>University of Houston-Downtown</td>
 <td align=center>Pentium 4</td>
 <td align=center>48</td>
 <td align=center>1.80</td>
 <td align=center>172.8</td>
 <td align=center>Houston, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1469">(1469) More</a></td>
 <td align=center>GenCluster</td>
 <td align=center>Watt Systems Technologies</td>
 <td align=center>Opteron</td>
 <td align=center>40</td>
 <td align=center>2.60</td>
 <td align=center>208</td>
 <td align=center>Albuquerque, NM</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1468">(1468) More</a></td>
 <td align=center>BiopharmWulf</td>
 <td align=center>Allergan</td>
 <td align=center>Pentium 4</td>
 <td align=center>26</td>
 <td align=center>2.60</td>
 <td align=center>135.2</td>
 <td align=center>Irvine CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1466">(1466) More</a></td>
 <td align=center>prandtl</td>
 <td align=center>University of Nottingham</td>
 <td align=center>Opteron</td>
 <td align=center>138</td>
 <td align=center>2.00</td>
 <td align=center>552</td>
 <td align=center>Nottingham</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1465">(1465) More</a></td>
 <td align=center>HiPeCS</td>
 <td align=center>SINTEF Fisheries and aquaculture</td>
 <td align=center>EM64T-4</td>
 <td align=center>32</td>
 <td align=center>3.30</td>
 <td align=center>422.4</td>
 <td align=center>Trondheim  (Norway)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1464">(1464) More</a></td>
 <td align=center>SILKMASTER</td>
 <td align=center>Centre For DNA Fingerprinting and Diagnostics</td>
 <td align=center>Other</td>
 <td align=center>48</td>
 <td align=center>2.30</td>
 <td align=center>110.4</td>
 <td align=center>Hyderabad, INDIA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1463">(1463) More</a></td>
 <td align=center>rcluster</td>
 <td align=center>Argonne National Laboratory, PMG</td>
 <td align=center>Pentium 4</td>
 <td align=center>60</td>
 <td align=center>2.20</td>
 <td align=center>264</td>
 <td align=center>Argonne</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1462">(1462) More</a></td>
 <td align=center>wowYes</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>3.80</td>
 <td align=center>7.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1461">(1461) More</a></td>
 <td align=center>Pistol Pete</td>
 <td align=center>Oklahoma State University</td>
 <td align=center>EM64T-4</td>
 <td align=center>512</td>
 <td align=center>2.66</td>
 <td align=center>5447.68</td>
 <td align=center>Stillwater</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1460">(1460) More</a></td>
 <td align=center>ECLIPSE</td>
 <td align=center>National Center for Genetic Engineering and Biotechnology</td>
 <td align=center>Opteron</td>
 <td align=center>704</td>
 <td align=center>2.30</td>
 <td align=center>3238.4</td>
 <td align=center>Pathumthani, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1459">(1459) More</a></td>
 <td align=center>Buell Lab</td>
 <td align=center>Michigan State University</td>
 <td align=center>EM64T-4</td>
 <td align=center>58</td>
 <td align=center>2.80</td>
 <td align=center>649.6</td>
 <td align=center>East Lansing, Michigan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1458">(1458) More</a></td>
 <td align=center>Cocle</td>
 <td align=center>UTP, Panamá</td>
 <td align=center>Itanium</td>
 <td align=center>1</td>
 <td align=center>2.30</td>
 <td align=center>9.2</td>
 <td align=center>panama</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1457">(1457) More</a></td>
 <td align=center>LCFT</td>
 <td align=center>LCFT - ITA</td>
 <td align=center>Athlon 64</td>
 <td align=center>56</td>
 <td align=center>1.80</td>
 <td align=center>201.6</td>
 <td align=center>São José dos Campos, Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1456">(1456) More</a></td>
 <td align=center>hercules.polymer</td>
 <td align=center>The University of Akron</td>
 <td align=center>EM64T-4</td>
 <td align=center>92</td>
 <td align=center>2.33</td>
 <td align=center>857.44</td>
 <td align=center>Akron, OH</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1455">(1455) More</a></td>
 <td align=center>Intuition</td>
 <td align=center>Distributed Information and Intelligence Analysis Group</td>
 <td align=center>EM64T</td>
 <td align=center>222</td>
 <td align=center>2.80</td>
 <td align=center>1243.2</td>
 <td align=center>Dartmouth College, Hanover, NH</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1454">(1454) More</a></td>
 <td align=center>watson</td>
 <td align=center>University of Wis by Nor-tech</td>
 <td align=center>EM64T-4</td>
 <td align=center>84</td>
 <td align=center>2.50</td>
 <td align=center>840</td>
 <td align=center>Milwaukee, WI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1453">(1453) More</a></td>
 <td align=center>atom</td>
 <td align=center>University Akron by Nor-tech</td>
 <td align=center>EM64T-4</td>
 <td align=center>132</td>
 <td align=center>2.66</td>
 <td align=center>1404.48</td>
 <td align=center>Akron, OH</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1452">(1452) More</a></td>
 <td align=center>galileo</td>
 <td align=center>Cegep de Sherbrooke</td>
 <td align=center>EM64T</td>
 <td align=center>18</td>
 <td align=center>3.60</td>
 <td align=center>129.6</td>
 <td align=center>Sherbrooke, Qc, CANADA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1451">(1451) More</a></td>
 <td align=center>lightpollution</td>
 <td align=center>CelesTech</td>
 <td align=center>Pentium 4</td>
 <td align=center>7</td>
 <td align=center>3.20</td>
 <td align=center>44.8</td>
 <td align=center>St-Camille, Qc, CANADA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1450">(1450) More</a></td>
 <td align=center>Horizon</td>
 <td align=center>civil</td>
 <td align=center>EM64T-4</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>cula</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1449">(1449) More</a></td>
 <td align=center>Nirvana</td>
 <td align=center>Northeastern University</td>
 <td align=center>EM64T-4</td>
 <td align=center>16</td>
 <td align=center>1.90</td>
 <td align=center>121.6</td>
 <td align=center>Boston</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1448">(1448) More</a></td>
 <td align=center>ILC MSU Cluster</td>
 <td align=center>International Laser Center of Moscow State University</td>
 <td align=center>EM64T</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>Moscow</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1447">(1447) More</a></td>
 <td align=center>superBlazer</td>
 <td align=center>Hood College</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>2.99</td>
 <td align=center>119.6</td>
 <td align=center>Frederick Maryland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1446">(1446) More</a></td>
 <td align=center>FWGrid</td>
 <td align=center>UCSD, CSE</td>
 <td align=center>EM64T</td>
 <td align=center>640</td>
 <td align=center>2.80</td>
 <td align=center>3584</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1445">(1445) More</a></td>
 <td align=center>condor-zeus</td>
 <td align=center>OeRC</td>
 <td align=center>Other</td>
 <td align=center>96</td>
 <td align=center>3.20</td>
 <td align=center>307.2</td>
 <td align=center>Oxford</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1444">(1444) More</a></td>
 <td align=center>Axon</td>
 <td align=center>SRM bioinformatics</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.22</td>
 <td align=center>44.4</td>
 <td align=center>Chennai-India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1443">(1443) More</a></td>
 <td align=center>antennahead</td>
 <td align=center>Queen Mary University of London</td>
 <td align=center>EM64T</td>
 <td align=center>128</td>
 <td align=center>2.00</td>
 <td align=center>512</td>
 <td align=center>London</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1442">(1442) More</a></td>
 <td align=center>TAMU Hercules</td>
 <td align=center>Texas A&M University Geosciences</td>
 <td align=center>EM64T-4</td>
 <td align=center>96</td>
 <td align=center>3.00</td>
 <td align=center>1152</td>
 <td align=center>College Station, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1439">(1439) More</a></td>
 <td align=center>TSU Ares Cluster</td>
 <td align=center>Texas Southern University High Performance Computing Center</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>2.00</td>
 <td align=center>512</td>
 <td align=center>Houston, Texas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1438">(1438) More</a></td>
 <td align=center>nur adlina sofia</td>
 <td align=center>acer</td>
 <td align=center>Pentium</td>
 <td align=center>1</td>
 <td align=center>1.73</td>
 <td align=center>1.73</td>
 <td align=center>Malaysia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1437">(1437) More</a></td>
 <td align=center>dsicluster1</td>
 <td align=center>Museum national d histoire naturelle (MNHN)</td>
 <td align=center>EM64T</td>
 <td align=center>110</td>
 <td align=center>2.00</td>
 <td align=center>440</td>
 <td align=center>Paris, France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1436">(1436) More</a></td>
 <td align=center>Plasmon</td>
 <td align=center>Arizona State University</td>
 <td align=center>Opteron</td>
 <td align=center>128</td>
 <td align=center>2.00</td>
 <td align=center>512</td>
 <td align=center>Mesa, AZ</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1435">(1435) More</a></td>
 <td align=center>Newen</td>
 <td align=center>University of Concepcion</td>
 <td align=center>Itanium</td>
 <td align=center>2</td>
 <td align=center>2.00</td>
 <td align=center>16</td>
 <td align=center>Concepcion, Chile</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1434">(1434) More</a></td>
 <td align=center>Moore Cluster</td>
 <td align=center>Carnegie Mellon University</td>
 <td align=center>Opteron</td>
 <td align=center>176</td>
 <td align=center>2.20</td>
 <td align=center>774.4</td>
 <td align=center>Pittsburgh, PA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1433">(1433) More</a></td>
 <td align=center>LacHongSPC</td>
 <td align=center>Lac Hong University</td>
 <td align=center>Other</td>
 <td align=center>18</td>
 <td align=center>2.00</td>
 <td align=center>36</td>
 <td align=center>Bien Hoa-Dong Nai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1432">(1432) More</a></td>
 <td align=center>Agnito</td>
 <td align=center>Texas Woman's University</td>
 <td align=center>Opteron</td>
 <td align=center>76</td>
 <td align=center>2.40</td>
 <td align=center>364.8</td>
 <td align=center>Denton, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1431">(1431) More</a></td>
 <td align=center>HPCL</td>
 <td align=center>Marquette University by Nor-tech</td>
 <td align=center>Opteron</td>
 <td align=center>18</td>
 <td align=center>2.50</td>
 <td align=center>90</td>
 <td align=center>Milwaukee, WI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1430">(1430) More</a></td>
 <td align=center>Silverbox-mini</td>
 <td align=center>HC3 Projects</td>
 <td align=center>Other</td>
 <td align=center>2</td>
 <td align=center>2.60</td>
 <td align=center>5.2</td>
 <td align=center>Wallmerod, Germany</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1429">(1429) More</a></td>
 <td align=center>TOTAL CLUSTER</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>3.00</td>
 <td align=center>72</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1428">(1428) More</a></td>
 <td align=center>HPCC</td>
 <td align=center>GuangZhou Sanfoo</td>
 <td align=center>Pentium 4</td>
 <td align=center>48</td>
 <td align=center>3.00</td>
 <td align=center>288</td>
 <td align=center>Sanfoo</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1427">(1427) More</a></td>
 <td align=center>MIni Qlab</td>
 <td align=center>ntu</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.00</td>
 <td align=center>12</td>
 <td align=center>Taipei</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1426">(1426) More</a></td>
 <td align=center>LACAD-DFT</td>
 <td align=center>Universidade do Estado do Rio de Janeiro</td>
 <td align=center>EM64T</td>
 <td align=center>20</td>
 <td align=center>2.33</td>
 <td align=center>93.2</td>
 <td align=center>Rio de Janeiro</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1425">(1425) More</a></td>
 <td align=center>Fermat</td>
 <td align=center>UCLM</td>
 <td align=center>EM64T-4</td>
 <td align=center>60</td>
 <td align=center>3.00</td>
 <td align=center>720</td>
 <td align=center>Albacete</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1424">(1424) More</a></td>
 <td align=center>SAMBA</td>
 <td align=center>Universidade Católica de Brasília</td>
 <td align=center>Pentium 4</td>
 <td align=center>18</td>
 <td align=center>3.00</td>
 <td align=center>108</td>
 <td align=center>Brasília</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1423">(1423) More</a></td>
 <td align=center>PALMA</td>
 <td align=center>Universidade Estadual de Feira de Santana</td>
 <td align=center>EM64T</td>
 <td align=center>24</td>
 <td align=center>1.80</td>
 <td align=center>86.4</td>
 <td align=center>Feira de Santana, Bahia, Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1422">(1422) More</a></td>
 <td align=center>miniswing</td>
 <td align=center>gic</td>
 <td align=center>Unspecified</td>
 <td align=center>1</td>
 <td align=center>1.60</td>
 <td align=center>1.6</td>
 <td align=center>guangzhou</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1421">(1421) More</a></td>
 <td align=center>HITFMG</td>
 <td align=center>Harbin Institute of Technology</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.20</td>
 <td align=center>44</td>
 <td align=center>Harbin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1420">(1420) More</a></td>
 <td align=center>somjinPC</td>
 <td align=center>sut</td>
 <td align=center>Athlon</td>
 <td align=center>1</td>
 <td align=center>2.19</td>
 <td align=center>2.19</td>
 <td align=center>thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1419">(1419) More</a></td>
 <td align=center>xfhix</td>
 <td align=center>Fritz-Haber-Institut</td>
 <td align=center>Opteron</td>
 <td align=center>232</td>
 <td align=center>2.30</td>
 <td align=center>1067.2</td>
 <td align=center>Berlin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1418">(1418) More</a></td>
 <td align=center>Topsail</td>
 <td align=center>University of North Carolina - Chapel Hill</td>
 <td align=center>EM64T-4</td>
 <td align=center>4160</td>
 <td align=center>2.30</td>
 <td align=center>38272</td>
 <td align=center>Chapel Hill, NC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1417">(1417) More</a></td>
 <td align=center>AUC</td>
 <td align=center>Ariel University Center</td>
 <td align=center>EM64T-4</td>
 <td align=center>8</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>Israel, Ariel</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1416">(1416) More</a></td>
 <td align=center>blub</td>
 <td align=center>University of St Andrews</td>
 <td align=center>Other</td>
 <td align=center>104</td>
 <td align=center>2.40</td>
 <td align=center>249.6</td>
 <td align=center>Fife, UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1415">(1415) More</a></td>
 <td align=center>WMM</td>
 <td align=center>202.44.12.112</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>2.24</td>
 <td align=center>8.96</td>
 <td align=center>202.44.12.112</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1414">(1414) More</a></td>
 <td align=center>Cimarron</td>
 <td align=center>Oklahoma State University</td>
 <td align=center>EM64T-4</td>
 <td align=center>112</td>
 <td align=center>2.00</td>
 <td align=center>896</td>
 <td align=center>Stillwater, OK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1413">(1413) More</a></td>
 <td align=center>Hal</td>
 <td align=center>University of Arizona, Ecology and Evolutionary Biology</td>
 <td align=center>EM64T-4</td>
 <td align=center>96</td>
 <td align=center>2.33</td>
 <td align=center>894.72</td>
 <td align=center>Tucson</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1412">(1412) More</a></td>
 <td align=center>Cairngorm</td>
 <td align=center>University of St Andrews</td>
 <td align=center>EM64T-4</td>
 <td align=center>80</td>
 <td align=center>1.90</td>
 <td align=center>608</td>
 <td align=center>St Andrews, UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1411">(1411) More</a></td>
 <td align=center>perceval</td>
 <td align=center>univ. paris-sud</td>
 <td align=center>EM64T-4</td>
 <td align=center>44</td>
 <td align=center>2.66</td>
 <td align=center>468.16</td>
 <td align=center>paris</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1410">(1410) More</a></td>
 <td align=center>clouden1</td>
 <td align=center>PMA Media Group</td>
 <td align=center>Pentium</td>
 <td align=center>5</td>
 <td align=center>2.00</td>
 <td align=center>10</td>
 <td align=center>Provo</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1409">(1409) More</a></td>
 <td align=center>btapydcf</td>
 <td align=center>Teacher Traning University</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>2.40</td>
 <td align=center>4.8</td>
 <td align=center>Teharn</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1408">(1408) More</a></td>
 <td align=center>samo</td>
 <td align=center>LPAOSF</td>
 <td align=center>Unspecified</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>14.4</td>
 <td align=center>Dakar</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1406">(1406) More</a></td>
 <td align=center>Waltz</td>
 <td align=center>Novartis</td>
 <td align=center>EM64T-4</td>
 <td align=center>128</td>
 <td align=center>2.33</td>
 <td align=center>1192.96</td>
 <td align=center>Horsham, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1405">(1405) More</a></td>
 <td align=center>HG</td>
 <td align=center>hello</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>3.6</td>
 <td align=center>beijing</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1404">(1404) More</a></td>
 <td align=center>Sol</td>
 <td align=center>Western Michigan University Computer Aided Engineering Center</td>
 <td align=center>Pentium 4</td>
 <td align=center>34</td>
 <td align=center>2.40</td>
 <td align=center>163.2</td>
 <td align=center>Kalamazoo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1403">(1403) More</a></td>
 <td align=center>kolmogorov</td>
 <td align=center>The University of Nottingham</td>
 <td align=center>Pentium 4</td>
 <td align=center>48</td>
 <td align=center>2.83</td>
 <td align=center>271.68</td>
 <td align=center>Nottingham</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1402">(1402) More</a></td>
 <td align=center>Topaz</td>
 <td align=center>Rocky Mountain College</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.40</td>
 <td align=center>38.4</td>
 <td align=center>Billings</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1401">(1401) More</a></td>
 <td align=center>HPC BOSE Cluster</td>
 <td align=center>Instituto de Física La Plata (IFLP, CONICET-UNLP)</td>
 <td align=center>Itanium 2</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>307.2</td>
 <td align=center>La Plata, Argentina</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1400">(1400) More</a></td>
 <td align=center>praveer</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>2</td>
 <td align=center>2.50</td>
 <td align=center>5</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1399">(1399) More</a></td>
 <td align=center>jobaby</td>
 <td align=center>OVS</td>
 <td align=center>Pentium 3</td>
 <td align=center>1</td>
 <td align=center>1.20</td>
 <td align=center>1.2</td>
 <td align=center>Egypt</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1398">(1398) More</a></td>
 <td align=center>esCERT</td>
 <td align=center>esCERT-UPC</td>
 <td align=center>Pentium 4</td>
 <td align=center>9</td>
 <td align=center>2.00</td>
 <td align=center>36</td>
 <td align=center>Barcelona, UPC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1397">(1397) More</a></td>
 <td align=center>p</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.40</td>
 <td align=center>48</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1396">(1396) More</a></td>
 <td align=center>Lupos Test Cluster</td>
 <td align=center>Lupos Private Cluster</td>
 <td align=center>Athlon 64</td>
 <td align=center>31</td>
 <td align=center>2.40</td>
 <td align=center>148.8</td>
 <td align=center>Düsseldorf / Germany</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1394">(1394) More</a></td>
 <td align=center>LMTNL1</td>
 <td align=center>LMTNL</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>2.90</td>
 <td align=center>11.6</td>
 <td align=center>La Caleta de Interian, Garachico, Tenerife</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1393">(1393) More</a></td>
 <td align=center>Niels Bohr</td>
 <td align=center>Long Island University</td>
 <td align=center>Unspecified</td>
 <td align=center>70</td>
 <td align=center>3.00</td>
 <td align=center>210</td>
 <td align=center>Brooklyn, NY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1392">(1392) More</a></td>
 <td align=center>BMBcluster@ohsu</td>
 <td align=center>OHSU</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Portland, OR</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1391">(1391) More</a></td>
 <td align=center>meduza02</td>
 <td align=center>UNESP-IBILCE</td>
 <td align=center>Opteron</td>
 <td align=center>5</td>
 <td align=center>2.20</td>
 <td align=center>22</td>
 <td align=center>S. J. Rio Preto</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1390">(1390) More</a></td>
 <td align=center>TCPMeta</td>
 <td align=center>n/a</td>
 <td align=center>Pentium</td>
 <td align=center>10</td>
 <td align=center>1.33</td>
 <td align=center>13.3</td>
 <td align=center>Jacksonville, FL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1389">(1389) More</a></td>
 <td align=center>VELOCITY</td>
 <td align=center>University of Pretoria</td>
 <td align=center>Pentium 4</td>
 <td align=center>54</td>
 <td align=center>3.20</td>
 <td align=center>345.6</td>
 <td align=center>Pretoria, South Africa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1388">(1388) More</a></td>
 <td align=center>sol05</td>
 <td align=center>CNEA</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.60</td>
 <td align=center>52</td>
 <td align=center>Buenos Aires</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1387">(1387) More</a></td>
 <td align=center>gccrocks</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Athlon</td>
 <td align=center>6</td>
 <td align=center>2.00</td>
 <td align=center>12</td>
 <td align=center>San Antonio</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1386">(1386) More</a></td>
 <td align=center>MII-SAS</td>
 <td align=center>Institute of Mathematics and Informatics, SAS</td>
 <td align=center>Athlon 64</td>
 <td align=center>18</td>
 <td align=center>2.60</td>
 <td align=center>93.6</td>
 <td align=center>Vilnius, LT</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1385">(1385) More</a></td>
 <td align=center>CBCB</td>
 <td align=center>Center for Bioinformatics and Computational Biology</td>
 <td align=center>Athlon MP</td>
 <td align=center>32</td>
 <td align=center>1.80</td>
 <td align=center>115.2</td>
 <td align=center>Iowa City</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1384">(1384) More</a></td>
 <td align=center>jupiter.shef.ac.uk</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>2.00</td>
 <td align=center>32</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1383">(1383) More</a></td>
 <td align=center>AliEn ISS</td>
 <td align=center>Institute of Space Sciences</td>
 <td align=center>EM64T-4</td>
 <td align=center>292</td>
 <td align=center>2.33</td>
 <td align=center>2721.44</td>
 <td align=center>Bucharest, Romania</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1382">(1382) More</a></td>
 <td align=center>Solexa</td>
 <td align=center>University of Toronto</td>
 <td align=center>Other</td>
 <td align=center>7</td>
 <td align=center>1.60</td>
 <td align=center>11.2</td>
 <td align=center>Toronto</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1381">(1381) More</a></td>
 <td align=center>FME Cluster</td>
 <td align=center>Financial and Management Engineering.University of the Aegean</td>
 <td align=center>Opteron</td>
 <td align=center>28</td>
 <td align=center>2.00</td>
 <td align=center>112</td>
 <td align=center>Chios,Greece</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1380">(1380) More</a></td>
 <td align=center>quartz</td>
 <td align=center>quartz</td>
 <td align=center>Athlon</td>
 <td align=center>5</td>
 <td align=center>2.00</td>
 <td align=center>10</td>
 <td align=center>japan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1379">(1379) More</a></td>
 <td align=center>bach</td>
 <td align=center>Princeton University Chemistry</td>
 <td align=center>Pentium 4</td>
 <td align=center>164</td>
 <td align=center>2.40</td>
 <td align=center>787.2</td>
 <td align=center>Princeton</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1378">(1378) More</a></td>
 <td align=center>Anchor</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium</td>
 <td align=center>20</td>
 <td align=center>2.40</td>
 <td align=center>48</td>
 <td align=center>Orlando</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1377">(1377) More</a></td>
 <td align=center>CS420 Parallel Programming</td>
 <td align=center>Johns Hopkins University</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>2.00</td>
 <td align=center>40</td>
 <td align=center>Baltimore, MD</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1376">(1376) More</a></td>
 <td align=center>SMR cluster</td>
 <td align=center>Schlumberger</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>3.00</td>
 <td align=center>192</td>
 <td align=center>Russia, Moscow</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1375">(1375) More</a></td>
 <td align=center>Glab</td>
 <td align=center>UC Berkeley College of Chemistry</td>
 <td align=center>Pentium 4</td>
 <td align=center>48</td>
 <td align=center>2.80</td>
 <td align=center>268.8</td>
 <td align=center>Berkeley</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1374">(1374) More</a></td>
 <td align=center>hpc_phys_sut</td>
 <td align=center>Department of Physics, Sharif University of Technology</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>2.66</td>
 <td align=center>42.56</td>
 <td align=center>Tehran</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1373">(1373) More</a></td>
 <td align=center>CASPAM</td>
 <td align=center>CASPAM, Bahauddin Zakariya University</td>
 <td align=center>EM64T-4</td>
 <td align=center>4</td>
 <td align=center>3.00</td>
 <td align=center>48</td>
 <td align=center>Multan, Pakistan.</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1372">(1372) More</a></td>
 <td align=center>GASPEO</td>
 <td align=center>Environment Canada</td>
 <td align=center>EM64T</td>
 <td align=center>104</td>
 <td align=center>3.20</td>
 <td align=center>665.6</td>
 <td align=center>Montreal</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1371">(1371) More</a></td>
 <td align=center>FOSimLab</td>
 <td align=center>ACTA</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>Vandenberg AFB, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1370">(1370) More</a></td>
 <td align=center>koufax</td>
 <td align=center>University of Richmond</td>
 <td align=center>Pentium 4</td>
 <td align=center>17</td>
 <td align=center>2.80</td>
 <td align=center>95.2</td>
 <td align=center>University of Richmond</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1369">(1369) More</a></td>
 <td align=center>lilithhws</td>
 <td align=center>University of Richmond</td>
 <td align=center>Athlon MP</td>
 <td align=center>36</td>
 <td align=center>1.80</td>
 <td align=center>129.6</td>
 <td align=center>University of Richmond</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1368">(1368) More</a></td>
 <td align=center>Geo bangle cluster</td>
 <td align=center>Prodigy Labs Pvt Ltd</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>Bangalore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1367">(1367) More</a></td>
 <td align=center>Titan-HPC</td>
 <td align=center>University of Minnesota, Aerospace Engineering</td>
 <td align=center>Opteron</td>
 <td align=center>2304</td>
 <td align=center>2.30</td>
 <td align=center>10598.4</td>
 <td align=center>Minneapolis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1366">(1366) More</a></td>
 <td align=center>SIRIUS</td>
 <td align=center>CMOP</td>
 <td align=center>EM64T-4</td>
 <td align=center>128</td>
 <td align=center>2.66</td>
 <td align=center>1361.92</td>
 <td align=center>Beaverton</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1365">(1365) More</a></td>
 <td align=center>Hactar</td>
 <td align=center>NYU Medical Center</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.80</td>
 <td align=center>358.4</td>
 <td align=center>New York</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1364">(1364) More</a></td>
 <td align=center>Sprache HPC</td>
 <td align=center>JAIST</td>
 <td align=center>EM64T-4</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>128</td>
 <td align=center>Ishikawa, Japan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1363">(1363) More</a></td>
 <td align=center>Lucy</td>
 <td align=center>Zoological Institute, University of Kiel</td>
 <td align=center>Opteron</td>
 <td align=center>40</td>
 <td align=center>2.20</td>
 <td align=center>176</td>
 <td align=center>Kiel, Germany</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1362">(1362) More</a></td>
 <td align=center>Tom Paine</td>
 <td align=center>Lamont-Doherty Earth Observatory of Columbia University</td>
 <td align=center>Pentium 3</td>
 <td align=center>10</td>
 <td align=center>0.60</td>
 <td align=center>6</td>
 <td align=center>Palisades, NY, 10964</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1361">(1361) More</a></td>
 <td align=center>lilac</td>
 <td align=center>University of Rochester Med School, Dept of Biochemistry</td>
 <td align=center>EM64T-4</td>
 <td align=center>40</td>
 <td align=center>2.60</td>
 <td align=center>416</td>
 <td align=center>Rochester, NY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1360">(1360) More</a></td>
 <td align=center>Xibalba</td>
 <td align=center>Dell Mexico</td>
 <td align=center>EM64T-4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>358.4</td>
 <td align=center>Mexico City</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1359">(1359) More</a></td>
 <td align=center>Imorphics cluster</td>
 <td align=center>Imorphics</td>
 <td align=center>EM64T</td>
 <td align=center>20</td>
 <td align=center>1.60</td>
 <td align=center>64</td>
 <td align=center>Manchester, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1358">(1358) More</a></td>
 <td align=center>Chapman Cluster</td>
 <td align=center>Chapman University</td>
 <td align=center>Other</td>
 <td align=center>20</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Orange, California</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1357">(1357) More</a></td>
 <td align=center>cluster-1</td>
 <td align=center>UFU - University of Uberlândia</td>
 <td align=center>Pentium 4</td>
 <td align=center>7</td>
 <td align=center>1.80</td>
 <td align=center>25.2</td>
 <td align=center>Minas Gerais, Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1356">(1356) More</a></td>
 <td align=center>Swarm</td>
 <td align=center>Departamento de Genética - Ribeirão Preto - USP</td>
 <td align=center>Pentium</td>
 <td align=center>62</td>
 <td align=center>2.30</td>
 <td align=center>142.6</td>
 <td align=center>Ribeirão Preto, Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1354">(1354) More</a></td>
 <td align=center>biograppe-plus</td>
 <td align=center>C.N.R.S. - L.E.G.S.</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>2.80</td>
 <td align=center>358.4</td>
 <td align=center>Gif sur Yvette - France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1353">(1353) More</a></td>
 <td align=center>Cluster Ceas</td>
 <td align=center>Private Project Computacional Chemistry</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.66</td>
 <td align=center>53.2</td>
 <td align=center>Rajadell (Catalonia-Spain)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1352">(1352) More</a></td>
 <td align=center>NYU Gene</td>
 <td align=center>NYU</td>
 <td align=center>Opteron</td>
 <td align=center>168</td>
 <td align=center>2.60</td>
 <td align=center>873.6</td>
 <td align=center>NYU, NYC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1351">(1351) More</a></td>
 <td align=center>Poor Mans Server</td>
 <td align=center>MegaByte Me Computers</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>2.40</td>
 <td align=center>14.4</td>
 <td align=center>Brisbane</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1350">(1350) More</a></td>
 <td align=center>HAUGA</td>
 <td align=center>IT</td>
 <td align=center>Unspecified</td>
 <td align=center>3</td>
 <td align=center>3.00</td>
 <td align=center>9</td>
 <td align=center>HCM</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1349">(1349) More</a></td>
 <td align=center>100mpix tile display</td>
 <td align=center>School of Information</td>
 <td align=center>Opteron</td>
 <td align=center>14</td>
 <td align=center>2.40</td>
 <td align=center>67.2</td>
 <td align=center>Ann Arbor</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1348">(1348) More</a></td>
 <td align=center>Pomelo</td>
 <td align=center>DIFRA - CAB - CNEA</td>
 <td align=center>EM64T</td>
 <td align=center>44</td>
 <td align=center>1.60</td>
 <td align=center>140.8</td>
 <td align=center>Bariloche</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1347">(1347) More</a></td>
 <td align=center>Plasma Fusion</td>
 <td align=center>Physics Department, Gauhati University</td>
 <td align=center>Itanium 2</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>57.6</td>
 <td align=center>Guwahati, India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1346">(1346) More</a></td>
 <td align=center>trogdor</td>
 <td align=center>Texas A & M HSC College of Medicine</td>
 <td align=center>Opteron</td>
 <td align=center>30</td>
 <td align=center>2.40</td>
 <td align=center>144</td>
 <td align=center>Temple, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1345">(1345) More</a></td>
 <td align=center>Pravah</td>
 <td align=center>IIT Bombay</td>
 <td align=center>EM64T</td>
 <td align=center>24</td>
 <td align=center>2.40</td>
 <td align=center>115.2</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1343">(1343) More</a></td>
 <td align=center>GEOLAB Cluster 1</td>
 <td align=center>GEOALB Ltd.</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>Moscow</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1342">(1342) More</a></td>
 <td align=center>ucc-biocluster</td>
 <td align=center>University College Cork</td>
 <td align=center>Opteron</td>
 <td align=center>30</td>
 <td align=center>2.50</td>
 <td align=center>150</td>
 <td align=center>Cork</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1341">(1341) More</a></td>
 <td align=center>gmpcs</td>
 <td align=center>univercité Paris sud</td>
 <td align=center>EM64T-4</td>
 <td align=center>104</td>
 <td align=center>3.00</td>
 <td align=center>1248</td>
 <td align=center>paris</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1340">(1340) More</a></td>
 <td align=center>Parasol Lab IBM x335 cluster</td>
 <td align=center>Parasol Laboratory, Dept. of Comp. Sci., Texas A & M Univ.</td>
 <td align=center>Pentium 4</td>
 <td align=center>48</td>
 <td align=center>2.40</td>
 <td align=center>230.4</td>
 <td align=center>College Station, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1339">(1339) More</a></td>
 <td align=center>LERIA</td>
 <td align=center>Universite Angers</td>
 <td align=center>EM64T-8</td>
 <td align=center>80</td>
 <td align=center>2.83</td>
 <td align=center>1811.2</td>
 <td align=center>FRANCE</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1338">(1338) More</a></td>
 <td align=center>Azores</td>
 <td align=center>Rice University</td>
 <td align=center>Athlon 64</td>
 <td align=center>36</td>
 <td align=center>2.50</td>
 <td align=center>180</td>
 <td align=center>Houston, Texas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1337">(1337) More</a></td>
 <td align=center>IPE Cluster</td>
 <td align=center>Institute of Petroleum Engineering, University of Tehran</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>3.20</td>
 <td align=center>409.6</td>
 <td align=center>Tehran</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1336">(1336) More</a></td>
 <td align=center>Buster</td>
 <td align=center>Novartis</td>
 <td align=center>EM64T-4</td>
 <td align=center>80</td>
 <td align=center>3.00</td>
 <td align=center>960</td>
 <td align=center>UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1335">(1335) More</a></td>
 <td align=center>The Attic Network</td>
 <td align=center>The Attic Network</td>
 <td align=center>Pentium 3</td>
 <td align=center>5</td>
 <td align=center>1.00</td>
 <td align=center>5</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1334">(1334) More</a></td>
 <td align=center>orr</td>
 <td align=center>UCD</td>
 <td align=center>EM64T-4</td>
 <td align=center>136</td>
 <td align=center>2.60</td>
 <td align=center>1414.4</td>
 <td align=center>Dublin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1333">(1333) More</a></td>
 <td align=center>DeathBox</td>
 <td align=center>netw0rx</td>
 <td align=center>Pentium 3</td>
 <td align=center>6</td>
 <td align=center>1.00</td>
 <td align=center>6</td>
 <td align=center>Colorado</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1332">(1332) More</a></td>
 <td align=center>JNU</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Opteron</td>
 <td align=center>256</td>
 <td align=center>2.60</td>
 <td align=center>1331.2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1331">(1331) More</a></td>
 <td align=center>zin</td>
 <td align=center>MCB, University of Southern California</td>
 <td align=center>EM64T-4</td>
 <td align=center>112</td>
 <td align=center>2.00</td>
 <td align=center>896</td>
 <td align=center>Los Angeles</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1330">(1330) More</a></td>
 <td align=center>stat</td>
 <td align=center>IFAS Statistics, University of Florida</td>
 <td align=center>EM64T-4</td>
 <td align=center>40</td>
 <td align=center>2.00</td>
 <td align=center>320</td>
 <td align=center>Gainesville</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1329">(1329) More</a></td>
 <td align=center>PdxBio_cluster</td>
 <td align=center>Portland Bioscience</td>
 <td align=center>Pentium 3</td>
 <td align=center>6</td>
 <td align=center>1.40</td>
 <td align=center>8.4</td>
 <td align=center>Portland, Or</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1328">(1328) More</a></td>
 <td align=center>The DOOR v3.0</td>
 <td align=center>Isothermal Community College</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Spindale, NC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1327">(1327) More</a></td>
 <td align=center>The DOOR v2.0</td>
 <td align=center>Isothermal Community College</td>
 <td align=center>Pentium 3</td>
 <td align=center>16</td>
 <td align=center>0.65</td>
 <td align=center>10.4</td>
 <td align=center>Spindale, NC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1326">(1326) More</a></td>
 <td align=center>karina</td>
 <td align=center>unam</td>
 <td align=center>Pentium 3</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>1.8</td>
 <td align=center>DF</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1325">(1325) More</a></td>
 <td align=center>plexus-yale</td>
 <td align=center>Yale University</td>
 <td align=center>EM64T</td>
 <td align=center>52</td>
 <td align=center>3.19</td>
 <td align=center>331.76</td>
 <td align=center>New Haven, CT</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1324">(1324) More</a></td>
 <td align=center>HELLO</td>
 <td align=center>HELLO</td>
 <td align=center>Opteron</td>
 <td align=center>256</td>
 <td align=center>2.60</td>
 <td align=center>1331.2</td>
 <td align=center>New Delhi</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1323">(1323) More</a></td>
 <td align=center>hsc2.yidec.org</td>
 <td align=center>Hiroshima University</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>2.66</td>
 <td align=center>85.12</td>
 <td align=center>Higashi-Hiroshima</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1321">(1321) More</a></td>
 <td align=center>3TIER Planaria</td>
 <td align=center>3TIER Group INC</td>
 <td align=center>Opteron</td>
 <td align=center>3152</td>
 <td align=center>2.00</td>
 <td align=center>12608</td>
 <td align=center>Seattle</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1320">(1320) More</a></td>
 <td align=center>slpits-rocks</td>
 <td align=center>Rochester Institute of Technology</td>
 <td align=center>Athlon 64</td>
 <td align=center>24</td>
 <td align=center>3.18</td>
 <td align=center>152.64</td>
 <td align=center>Rochester, New York</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1319">(1319) More</a></td>
 <td align=center>cprlite</td>
 <td align=center>College of Marine Science/U. South FLorida</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>2.50</td>
 <td align=center>10</td>
 <td align=center>St. Petersburg</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1318">(1318) More</a></td>
 <td align=center>quadribol</td>
 <td align=center>Universidade Federal de Juiz de Fora</td>
 <td align=center>EM64T-4</td>
 <td align=center>32</td>
 <td align=center>2.33</td>
 <td align=center>298.24</td>
 <td align=center>Juiz de Fora - MG - Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1317">(1317) More</a></td>
 <td align=center>Halc</td>
 <td align=center>Martin Luther University</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>2.40</td>
 <td align=center>307.2</td>
 <td align=center>Halle - Germany</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1316">(1316) More</a></td>
 <td align=center>blackbird</td>
 <td align=center>USAFA Modeling & Simulation Research Center</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>1.80</td>
 <td align=center>288</td>
 <td align=center>USAF Academy, CO</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1314">(1314) More</a></td>
 <td align=center>ra</td>
 <td align=center>Colorado School of Mines</td>
 <td align=center>EM64T-4</td>
 <td align=center>2144</td>
 <td align=center>2.66</td>
 <td align=center>22812.16</td>
 <td align=center>Golden, CO</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1312">(1312) More</a></td>
 <td align=center>Davistron</td>
 <td align=center>U.C. Davis</td>
 <td align=center>Athlon</td>
 <td align=center>8</td>
 <td align=center>2.10</td>
 <td align=center>16.8</td>
 <td align=center>Davis, California</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1311">(1311) More</a></td>
 <td align=center>FireNet</td>
 <td align=center>The University of Texas at Austin</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>1.80</td>
 <td align=center>43.2</td>
 <td align=center>Austin, Texas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1310">(1310) More</a></td>
 <td align=center>KU nuclear cluster for animal testing</td>
 <td align=center>Klaipeda University</td>
 <td align=center>EM64T-4</td>
 <td align=center>8</td>
 <td align=center>1.60</td>
 <td align=center>51.2</td>
 <td align=center>Lithuania</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1309">(1309) More</a></td>
 <td align=center>Hrothgar.EGR</td>
 <td align=center>University of Houston</td>
 <td align=center>Pentium 3</td>
 <td align=center>34</td>
 <td align=center>0.60</td>
 <td align=center>20.4</td>
 <td align=center>Houston, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1308">(1308) More</a></td>
 <td align=center>rio</td>
 <td align=center>The University of South Dakota</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.60</td>
 <td align=center>332.8</td>
 <td align=center>Vermillion</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1307">(1307) More</a></td>
 <td align=center>venice-ismar</td>
 <td align=center>cnr ismar</td>
 <td align=center>Athlon 64</td>
 <td align=center>24</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>venice</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1306">(1306) More</a></td>
 <td align=center>thole</td>
 <td align=center>Pens-its</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>2.20</td>
 <td align=center>88</td>
 <td align=center>Indonesia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1305">(1305) More</a></td>
 <td align=center>mirna</td>
 <td align=center>UT Southwestern Medical Center</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Dallas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1304">(1304) More</a></td>
 <td align=center>Orasi</td>
 <td align=center>Orasi by Nor-tech</td>
 <td align=center>EM64T-4</td>
 <td align=center>18</td>
 <td align=center>2.66</td>
 <td align=center>191.52</td>
 <td align=center>Minneapolis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1303">(1303) More</a></td>
 <td align=center>CECMI</td>
 <td align=center>State University of Moldova</td>
 <td align=center>Opteron</td>
 <td align=center>52</td>
 <td align=center>1.80</td>
 <td align=center>187.2</td>
 <td align=center>Moldova Republic, Chishinau, str. Mateevici 60</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1302">(1302) More</a></td>
 <td align=center>thrombosis</td>
 <td align=center>NCAT</td>
 <td align=center>EM64T-4</td>
 <td align=center>32</td>
 <td align=center>2.50</td>
 <td align=center>320</td>
 <td align=center>Greensboro</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1301">(1301) More</a></td>
 <td align=center>yingsuifeng</td>
 <td align=center>shihua</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>shihua Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1300">(1300) More</a></td>
 <td align=center>Star</td>
 <td align=center>University of Arkansas</td>
 <td align=center>EM64T-4</td>
 <td align=center>1256</td>
 <td align=center>2.66</td>
 <td align=center>13363.84</td>
 <td align=center>Fayetteville</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1299">(1299) More</a></td>
 <td align=center>Rydberg</td>
 <td align=center>Ursinus College</td>
 <td align=center>EM64T</td>
 <td align=center>48</td>
 <td align=center>3.20</td>
 <td align=center>307.2</td>
 <td align=center>Collegeville, PA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1298">(1298) More</a></td>
 <td align=center>Francis</td>
 <td align=center>Thompson Rivers University</td>
 <td align=center>EM64T-4</td>
 <td align=center>80</td>
 <td align=center>2.83</td>
 <td align=center>905.6</td>
 <td align=center>Kamloops, B.C. Canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1296">(1296) More</a></td>
 <td align=center>Hopper</td>
 <td align=center>California State University East Bay</td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>Hayward, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1295">(1295) More</a></td>
 <td align=center>su-ahpcrc</td>
 <td align=center>Stanford University</td>
 <td align=center>EM64T-4</td>
 <td align=center>1792</td>
 <td align=center>2.33</td>
 <td align=center>16701.44</td>
 <td align=center>Stanford</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1294">(1294) More</a></td>
 <td align=center>su-fpce</td>
 <td align=center>Stanford University</td>
 <td align=center>EM64T-4</td>
 <td align=center>1152</td>
 <td align=center>2.33</td>
 <td align=center>10736.64</td>
 <td align=center>Stanford</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1292">(1292) More</a></td>
 <td align=center>Aryabhatta</td>
 <td align=center>Center for Robust Speech Systems</td>
 <td align=center>Pentium 4</td>
 <td align=center>72</td>
 <td align=center>2.27</td>
 <td align=center>326.88</td>
 <td align=center>Richardson, Texas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1291">(1291) More</a></td>
 <td align=center>Grendel at Bryn Mawr</td>
 <td align=center>Bryn Mawr College</td>
 <td align=center>EM64T</td>
 <td align=center>24</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>Bryn Mawr</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1290">(1290) More</a></td>
 <td align=center>azumaseki</td>
 <td align=center>UCSC</td>
 <td align=center>Other</td>
 <td align=center>20</td>
 <td align=center>2.40</td>
 <td align=center>48</td>
 <td align=center>Santa Cruz</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1289">(1289) More</a></td>
 <td align=center>dharma</td>
 <td align=center>PUC-Rio</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>2.13</td>
 <td align=center>272.64</td>
 <td align=center>Rio de Janeiro</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1288">(1288) More</a></td>
 <td align=center>CEPR</td>
 <td align=center>Department of Computer Science, University of South Florida</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>2.66</td>
 <td align=center>340.48</td>
 <td align=center>Tampa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1287">(1287) More</a></td>
 <td align=center>ocinh64</td>
 <td align=center>Organic Chemistry Institute, University of Zurich</td>
 <td align=center>EM64T-4</td>
 <td align=center>36</td>
 <td align=center>2.80</td>
 <td align=center>403.2</td>
 <td align=center>zurich, switzerland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1286">(1286) More</a></td>
 <td align=center>dtm</td>
 <td align=center>Freie Universtitaet Berlin</td>
 <td align=center>EM64T-4</td>
 <td align=center>48</td>
 <td align=center>3.00</td>
 <td align=center>576</td>
 <td align=center>Berlin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1285">(1285) More</a></td>
 <td align=center>ENPA</td>
 <td align=center>energetica.unisannio.it</td>
 <td align=center>Athlon 64</td>
 <td align=center>32</td>
 <td align=center>2.00</td>
 <td align=center>128</td>
 <td align=center>benevento</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1284">(1284) More</a></td>
 <td align=center>Peregrine</td>
 <td align=center>Purdue University Calumet</td>
 <td align=center>EM64T-4</td>
 <td align=center>36</td>
 <td align=center>3.00</td>
 <td align=center>432</td>
 <td align=center>Hammond, IN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1283">(1283) More</a></td>
 <td align=center>hpcc.brandeis.edu</td>
 <td align=center>Brandeis University</td>
 <td align=center>EM64T-4</td>
 <td align=center>464</td>
 <td align=center>2.83</td>
 <td align=center>5252.48</td>
 <td align=center>Waltham, MA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1282">(1282) More</a></td>
 <td align=center>MEG-PTB</td>
 <td align=center>Physikalisch-Technische Bundesanstalt</td>
 <td align=center>Athlon XP</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>Berlin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1281">(1281) More</a></td>
 <td align=center>Winfirst Cluster</td>
 <td align=center>angelo New World</td>
 <td align=center>Other</td>
 <td align=center>40</td>
 <td align=center>2.13</td>
 <td align=center>85.2</td>
 <td align=center>Kwachon. Kyung ki do. Seoul</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1280">(1280) More</a></td>
 <td align=center>VIRUS</td>
 <td align=center>National Yang-Ming University</td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>2.60</td>
 <td align=center>62.4</td>
 <td align=center>Taipei</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1279">(1279) More</a></td>
 <td align=center>rocks-ecn</td>
 <td align=center>Université Laval</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>Québec</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1278">(1278) More</a></td>
 <td align=center>Unos</td>
 <td align=center>Advanced Science and Technology Institute</td>
 <td align=center>EM64T-4</td>
 <td align=center>48</td>
 <td align=center>2.00</td>
 <td align=center>384</td>
 <td align=center>Quezon City, Philippines</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1277">(1277) More</a></td>
 <td align=center>Azeem Cluster</td>
 <td align=center>private</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>2.00</td>
 <td align=center>24</td>
 <td align=center>Islamabad</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1276">(1276) More</a></td>
 <td align=center>Abarah</td>
 <td align=center>Grupo de Física Básica e Aplicada - Instituto de Fisica - UFBa</td>
 <td align=center>EM64T</td>
 <td align=center>36</td>
 <td align=center>2.40</td>
 <td align=center>172.8</td>
 <td align=center>Salvador-Ba, Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1275">(1275) More</a></td>
 <td align=center>FCC Cluster</td>
 <td align=center>Facultad de Ciencias de Computacion</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>1.36</td>
 <td align=center>87.04</td>
 <td align=center>Puebla, Mexico</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1274">(1274) More</a></td>
 <td align=center>SpecLabLCI</td>
 <td align=center>MIT Harrison Spectroscopy Laboratory</td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>2.40</td>
 <td align=center>7.2</td>
 <td align=center>Cambridge, MA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1272">(1272) More</a></td>
 <td align=center>Weather RND BMG</td>
 <td align=center>Indonesia Meteorological and Geophysical Agency (BMG)</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>3.20</td>
 <td align=center>38.4</td>
 <td align=center>Jakarta</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1271">(1271) More</a></td>
 <td align=center>Hoyohoy</td>
 <td align=center>PAGASA</td>
 <td align=center>EM64T</td>
 <td align=center>12</td>
 <td align=center>3.00</td>
 <td align=center>72</td>
 <td align=center>Quezon City, Philippines</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1270">(1270) More</a></td>
 <td align=center>Xena</td>
 <td align=center>Chemistry - Durham University</td>
 <td align=center>EM64T-4</td>
 <td align=center>62</td>
 <td align=center>2.20</td>
 <td align=center>545.6</td>
 <td align=center>Durham UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1269">(1269) More</a></td>
 <td align=center>Mei</td>
 <td align=center>Uppsala University</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Uppsala</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1268">(1268) More</a></td>
 <td align=center>floresta</td>
 <td align=center>EEAD/CSIC</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Zaragoza</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1267">(1267) More</a></td>
 <td align=center>Temple Of Doom - FreeBSD</td>
 <td align=center>Temple Of Doom</td>
 <td align=center>Pentium 3</td>
 <td align=center>7</td>
 <td align=center>1.40</td>
 <td align=center>9.8</td>
 <td align=center>Sweden</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1266">(1266) More</a></td>
 <td align=center>Gauss01-2</td>
 <td align=center>Seagate</td>
 <td align=center>EM64T-4</td>
 <td align=center>42</td>
 <td align=center>3.00</td>
 <td align=center>504</td>
 <td align=center>Bloomington, MN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1265">(1265) More</a></td>
 <td align=center>A2PG</td>
 <td align=center>Ann Arbor Pharmacometrics Group</td>
 <td align=center>EM64T-4</td>
 <td align=center>24</td>
 <td align=center>2.33</td>
 <td align=center>223.68</td>
 <td align=center>Ann Arbor, Michigan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1264">(1264) More</a></td>
 <td align=center>OCI-NSF</td>
 <td align=center>National Science Foundation/Office of Cyberinfrastructure</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.20</td>
 <td align=center>25.6</td>
 <td align=center>Arlington</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1263">(1263) More</a></td>
 <td align=center>Maxwell</td>
 <td align=center>CeTIC Universidad de Las Palmas de Gran Canaria</td>
 <td align=center>Pentium 4</td>
 <td align=center>24</td>
 <td align=center>2.80</td>
 <td align=center>134.4</td>
 <td align=center>Las Palmas de Gran Canaria</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1262">(1262) More</a></td>
 <td align=center>KUST-Kohat</td>
 <td align=center>Kohat University</td>
 <td align=center>EM64T</td>
 <td align=center>104</td>
 <td align=center>2.00</td>
 <td align=center>416</td>
 <td align=center>Kohat, Khyber Pakhtunkhwa, Pakistan.</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1261">(1261) More</a></td>
 <td align=center>Math Cluster</td>
 <td align=center>University of Puerto Rico</td>
 <td align=center>Itanium 2</td>
 <td align=center>8</td>
 <td align=center>1.46</td>
 <td align=center>46.72</td>
 <td align=center>Mayaguez, Puerto Rico</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1260">(1260) More</a></td>
 <td align=center>rocks.info-ua</td>
 <td align=center>LERIA, University of Angers</td>
 <td align=center>Pentium 4</td>
 <td align=center>30</td>
 <td align=center>2.40</td>
 <td align=center>144</td>
 <td align=center>Angers, FRANCE</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1259">(1259) More</a></td>
 <td align=center>Dr. Hobai St.</td>
 <td align=center>University of Medicine and Pharmacy</td>
 <td align=center>Athlon</td>
 <td align=center>2</td>
 <td align=center>2.30</td>
 <td align=center>4.6</td>
 <td align=center>Targu Mures</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1258">(1258) More</a></td>
 <td align=center>mojito</td>
 <td align=center>Arizona Research Laboratories, University of Arizona</td>
 <td align=center>Pentium 4</td>
 <td align=center>34</td>
 <td align=center>2.80</td>
 <td align=center>190.4</td>
 <td align=center>Tucson</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1257">(1257) More</a></td>
 <td align=center>Jasons VM Cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Athlon 64</td>
 <td align=center>4</td>
 <td align=center>2.19</td>
 <td align=center>17.52</td>
 <td align=center>Colorado</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1256">(1256) More</a></td>
 <td align=center>athena</td>
 <td align=center>University of Washington</td>
 <td align=center>EM64T-4</td>
 <td align=center>256</td>
 <td align=center>2.33</td>
 <td align=center>2385.92</td>
 <td align=center>Seattle, WA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1255">(1255) More</a></td>
 <td align=center>GR-05-DEMOKRITOS</td>
 <td align=center>NCSR Demokritos</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>2.20</td>
 <td align=center>352</td>
 <td align=center>Athens Greece</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1254">(1254) More</a></td>
 <td align=center>sugar</td>
 <td align=center>University of Kaiserslautern,  RHRK</td>
 <td align=center>EM64T</td>
 <td align=center>160</td>
 <td align=center>2.33</td>
 <td align=center>745.6</td>
 <td align=center>Kaiserslautern, Germany</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1253">(1253) More</a></td>
 <td align=center>nopal</td>
 <td align=center>University of Arizona</td>
 <td align=center>EM64T</td>
 <td align=center>60</td>
 <td align=center>3.00</td>
 <td align=center>360</td>
 <td align=center>Tucson</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1252">(1252) More</a></td>
 <td align=center>clusterone</td>
 <td align=center>private</td>
 <td align=center>Opteron</td>
 <td align=center>72</td>
 <td align=center>2.20</td>
 <td align=center>316.8</td>
 <td align=center>Colorado</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1251">(1251) More</a></td>
 <td align=center>beowulf.hpcc.uh.edu</td>
 <td align=center>University of Houston</td>
 <td align=center>Pentium 4</td>
 <td align=center>189</td>
 <td align=center>2.40</td>
 <td align=center>907.2</td>
 <td align=center>Houston, Texas, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1250">(1250) More</a></td>
 <td align=center>EarthOcean TestCluster</td>
 <td align=center>Earth Sciences / Oceanography - Dalhousie University</td>
 <td align=center>Athlon 64</td>
 <td align=center>18</td>
 <td align=center>2.40</td>
 <td align=center>86.4</td>
 <td align=center>Halifax, NS, Canada</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1249">(1249) More</a></td>
 <td align=center>catZ</td>
 <td align=center>Oceanography Dept - Dalhousie University</td>
 <td align=center>Opteron</td>
 <td align=center>216</td>
 <td align=center>2.60</td>
 <td align=center>1123.2</td>
 <td align=center>Halifax, NS, Canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1248">(1248) More</a></td>
 <td align=center>TUS1</td>
 <td align=center>University of Maryland - CASL</td>
 <td align=center>EM64T</td>
 <td align=center>18</td>
 <td align=center>3.70</td>
 <td align=center>133.2</td>
 <td align=center>College Park</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1247">(1247) More</a></td>
 <td align=center>dutton</td>
 <td align=center>Naval Research Laboratory</td>
 <td align=center>Pentium 4</td>
 <td align=center>44</td>
 <td align=center>2.60</td>
 <td align=center>228.8</td>
 <td align=center>Monterey</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1246">(1246) More</a></td>
 <td align=center>bean</td>
 <td align=center>Naval Research Laboratory</td>
 <td align=center>Pentium 4</td>
 <td align=center>44</td>
 <td align=center>2.60</td>
 <td align=center>228.8</td>
 <td align=center>Monterey</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1245">(1245) More</a></td>
 <td align=center>Aeolus</td>
 <td align=center>College of Engineering and Archetecture</td>
 <td align=center>EM64T-4</td>
 <td align=center>240</td>
 <td align=center>2.36</td>
 <td align=center>2265.6</td>
 <td align=center>Pullman, WA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1244">(1244) More</a></td>
 <td align=center>MUMAK-SGDP</td>
 <td align=center>MRC SGDP Research Centre</td>
 <td align=center>Other</td>
 <td align=center>218</td>
 <td align=center>2.40</td>
 <td align=center>523.2</td>
 <td align=center>Camberwell, London, UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1243">(1243) More</a></td>
 <td align=center>canarias</td>
 <td align=center>SUN DIAM</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>1.80</td>
 <td align=center>115.2</td>
 <td align=center>Aversa Italy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1242">(1242) More</a></td>
 <td align=center>Chemistry Linux Terminal (Clint)</td>
 <td align=center>San Jose State University</td>
 <td align=center>Other</td>
 <td align=center>18</td>
 <td align=center>1.86</td>
 <td align=center>33.48</td>
 <td align=center>San Jose, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1241">(1241) More</a></td>
 <td align=center>ExpTher</td>
 <td align=center>LIMM</td>
 <td align=center>Other</td>
 <td align=center>20</td>
 <td align=center>2.30</td>
 <td align=center>46</td>
 <td align=center>Leeds</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1240">(1240) More</a></td>
 <td align=center>pbs</td>
 <td align=center>UCI ESS</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>Irvine, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1239">(1239) More</a></td>
 <td align=center>Devastator</td>
 <td align=center>University Of Alberta</td>
 <td align=center>Athlon 64</td>
 <td align=center>8</td>
 <td align=center>2.00</td>
 <td align=center>32</td>
 <td align=center>Edmonton</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1238">(1238) More</a></td>
 <td align=center>ifp-cluster</td>
 <td align=center>UIUC</td>
 <td align=center>EM64T</td>
 <td align=center>36</td>
 <td align=center>2.80</td>
 <td align=center>201.6</td>
 <td align=center>Urbana IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1237">(1237) More</a></td>
 <td align=center>Unidad de Cálculo Numérico Avanzado - UNICA</td>
 <td align=center>Universidad Nacional de Colombia</td>
 <td align=center>EM64T</td>
 <td align=center>36</td>
 <td align=center>3.60</td>
 <td align=center>259.2</td>
 <td align=center>Medellín, Colombia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1236">(1236) More</a></td>
 <td align=center>Stallo</td>
 <td align=center>University of Tromsø</td>
 <td align=center>EM64T-4</td>
 <td align=center>5632</td>
 <td align=center>2.66</td>
 <td align=center>59924.48</td>
 <td align=center>Tromsø, Norway</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1235">(1235) More</a></td>
 <td align=center>GIU Cluster</td>
 <td align=center>FIMM     http://www.giu.fi</td>
 <td align=center>Opteron</td>
 <td align=center>120</td>
 <td align=center>2.24</td>
 <td align=center>537.6</td>
 <td align=center>Helsinki,Finland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1234">(1234) More</a></td>
 <td align=center>wtmut</td>
 <td align=center>Hydropoint</td>
 <td align=center>Pentium 4</td>
 <td align=center>108</td>
 <td align=center>3.80</td>
 <td align=center>820.8</td>
 <td align=center>Providence</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1233">(1233) More</a></td>
 <td align=center>g49657067</td>
 <td align=center>faculty of engineering</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>1.80</td>
 <td align=center>14.4</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1232">(1232) More</a></td>
 <td align=center>econ</td>
 <td align=center>Department of Economics, University of Minnesota</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>2.33</td>
 <td align=center>298.24</td>
 <td align=center>Minneapolis, Minnesota</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1231">(1231) More</a></td>
 <td align=center>buke</td>
 <td align=center>asiacom</td>
 <td align=center>Itanium 2</td>
 <td align=center>10</td>
 <td align=center>2.00</td>
 <td align=center>80</td>
 <td align=center>BeiJing</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1230">(1230) More</a></td>
 <td align=center>hydra@unipg</td>
 <td align=center>University of Perugia</td>
 <td align=center>Opteron</td>
 <td align=center>56</td>
 <td align=center>1.80</td>
 <td align=center>201.6</td>
 <td align=center>Perugia, Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1229">(1229) More</a></td>
 <td align=center>reciclanet</td>
 <td align=center>Reciclanet</td>
 <td align=center>Pentium 3</td>
 <td align=center>5</td>
 <td align=center>0.80</td>
 <td align=center>4</td>
 <td align=center>Bilbao</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1228">(1228) More</a></td>
 <td align=center>Albiorix</td>
 <td align=center>Department of Plant and Environmental Sciences</td>
 <td align=center>Other</td>
 <td align=center>8</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>Göteborg - Sweden</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1227">(1227) More</a></td>
 <td align=center>sukhamoy</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>23</td>
 <td align=center>1.20</td>
 <td align=center>55.2</td>
 <td align=center>kolkata</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1226">(1226) More</a></td>
 <td align=center>TMDGrid Cluster</td>
 <td align=center>Thai Meteorological Department</td>
 <td align=center>Other</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>28</td>
 <td align=center>Bangkok, THAILAND</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1225">(1225) More</a></td>
 <td align=center>jaws (at NRL)</td>
 <td align=center>Naval Research Laboratory</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>Monterey</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1224">(1224) More</a></td>
 <td align=center>geograppe</td>
 <td align=center>GEOTOP</td>
 <td align=center>Opteron</td>
 <td align=center>350</td>
 <td align=center>2.20</td>
 <td align=center>1540</td>
 <td align=center>Montréal</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1223">(1223) More</a></td>
 <td align=center>VISTA-Aurora</td>
 <td align=center>VISTA - Birmingham University</td>
 <td align=center>Pentium 4</td>
 <td align=center>22</td>
 <td align=center>3.06</td>
 <td align=center>134.64</td>
 <td align=center>Birmingham (UK)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1222">(1222) More</a></td>
 <td align=center>FSU HPC</td>
 <td align=center>Florida State University</td>
 <td align=center>Opteron</td>
 <td align=center>512</td>
 <td align=center>1.80</td>
 <td align=center>1843.2</td>
 <td align=center>Tallahassee, FL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1221">(1221) More</a></td>
 <td align=center>NUBIC Cluster</td>
 <td align=center>Northwestern University</td>
 <td align=center>EM64T</td>
 <td align=center>192</td>
 <td align=center>2.66</td>
 <td align=center>1021.44</td>
 <td align=center>Chicago</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1220">(1220) More</a></td>
 <td align=center>takk</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>1</td>
 <td align=center>1.66</td>
 <td align=center>1.66</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1219">(1219) More</a></td>
 <td align=center>WAVCISCluster</td>
 <td align=center>Louisiana State University</td>
 <td align=center>Unspecified</td>
 <td align=center>40</td>
 <td align=center>1.80</td>
 <td align=center>72</td>
 <td align=center>Baton Rouge</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1218">(1218) More</a></td>
 <td align=center>tempcat</td>
 <td align=center>Case Western Reserve University</td>
 <td align=center>Itanium</td>
 <td align=center>14</td>
 <td align=center>1.00</td>
 <td align=center>56</td>
 <td align=center>Cleveland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1217">(1217) More</a></td>
 <td align=center>Massey Bestgrid</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T</td>
 <td align=center>216</td>
 <td align=center>2.66</td>
 <td align=center>1149.12</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1216">(1216) More</a></td>
 <td align=center>UCL cluster</td>
 <td align=center>UCL - Faculdade do Centro Leste</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>1.86</td>
 <td align=center>29.76</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1215">(1215) More</a></td>
 <td align=center>Gaia-CMC</td>
 <td align=center>Centro de Modelado Científico. La Universidad del Zulia</td>
 <td align=center>Opteron</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>28.8</td>
 <td align=center>Maracaibo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1214">(1214) More</a></td>
 <td align=center>Democritus</td>
 <td align=center>University of Houston</td>
 <td align=center>EM64T-4</td>
 <td align=center>344</td>
 <td align=center>2.27</td>
 <td align=center>3123.52</td>
 <td align=center>Houston</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1213">(1213) More</a></td>
 <td align=center>Parallell Beast</td>
 <td align=center>Grupo de Sistemas Complejos</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>La Plata</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1212">(1212) More</a></td>
 <td align=center>Schur</td>
 <td align=center>LSU</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>3.00</td>
 <td align=center>384</td>
 <td align=center>Baton Rouge</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1211">(1211) More</a></td>
 <td align=center>MAFALDA</td>
 <td align=center>University of Geneva</td>
 <td align=center>Opteron</td>
 <td align=center>194</td>
 <td align=center>3.00</td>
 <td align=center>1164</td>
 <td align=center>Geneva, Switzerland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1210">(1210) More</a></td>
 <td align=center>turpa</td>
 <td align=center>University of Kuopio</td>
 <td align=center>EM64T</td>
 <td align=center>58</td>
 <td align=center>1.86</td>
 <td align=center>215.76</td>
 <td align=center>Kuopio, Finland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1209">(1209) More</a></td>
 <td align=center>Palm</td>
 <td align=center>KMITNB</td>
 <td align=center>Other</td>
 <td align=center>15</td>
 <td align=center>2.80</td>
 <td align=center>42</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1208">(1208) More</a></td>
 <td align=center>rocks1-garland</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T</td>
 <td align=center>6</td>
 <td align=center>2.30</td>
 <td align=center>27.6</td>
 <td align=center>Garland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1207">(1207) More</a></td>
 <td align=center>Memphis</td>
 <td align=center>Folding Farmer</td>
 <td align=center>Opteron</td>
 <td align=center>15</td>
 <td align=center>2.80</td>
 <td align=center>84</td>
 <td align=center>Chicago</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1205">(1205) More</a></td>
 <td align=center>CFD</td>
 <td align=center>University of Kentucky</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>2.30</td>
 <td align=center>294.4</td>
 <td align=center>Lexington, KY</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1204">(1204) More</a></td>
 <td align=center>Chimera</td>
 <td align=center>University of Kentucky</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Lexington, KY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1203">(1203) More</a></td>
 <td align=center>TMC</td>
 <td align=center>University of Kentucky</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>2.80</td>
 <td align=center>358.4</td>
 <td align=center>Lexington, KY</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1202">(1202) More</a></td>
 <td align=center>BlackJack</td>
 <td align=center>Gillett Evernham Motorsports</td>
 <td align=center>Opteron</td>
 <td align=center>96</td>
 <td align=center>2.80</td>
 <td align=center>537.6</td>
 <td align=center>Satesville, NC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1201">(1201) More</a></td>
 <td align=center>ANANTA</td>
 <td align=center>ananta</td>
 <td align=center>Opteron</td>
 <td align=center>4</td>
 <td align=center>10.40</td>
 <td align=center>83.2</td>
 <td align=center>Distrito Federal</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1200">(1200) More</a></td>
 <td align=center>fjord</td>
 <td align=center>Washington University in St. Louis</td>
 <td align=center>Athlon MP</td>
 <td align=center>48</td>
 <td align=center>2.20</td>
 <td align=center>211.2</td>
 <td align=center>St. Louis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1199">(1199) More</a></td>
 <td align=center>Alqudami</td>
 <td align=center>mpic</td>
 <td align=center>Athlon 64</td>
 <td align=center>4</td>
 <td align=center>2.00</td>
 <td align=center>16</td>
 <td align=center>Penang</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1198">(1198) More</a></td>
 <td align=center>NRG</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.20</td>
 <td align=center>12.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1197">(1197) More</a></td>
 <td align=center>KANSASOSG</td>
 <td align=center>University of Kansas Physics and Astronomy</td>
 <td align=center>Other</td>
 <td align=center>20</td>
 <td align=center>2.00</td>
 <td align=center>40</td>
 <td align=center>Lawrence, Kansas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1196">(1196) More</a></td>
 <td align=center>Photon</td>
 <td align=center>Fort Hays State University</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>1.80</td>
 <td align=center>115.2</td>
 <td align=center>Hays</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1195">(1195) More</a></td>
 <td align=center>breogan</td>
 <td align=center>University of La Coruña - School of Civil Engineering</td>
 <td align=center>Opteron</td>
 <td align=center>48</td>
 <td align=center>2.48</td>
 <td align=center>238.08</td>
 <td align=center>La Coruña, Spain</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1194">(1194) More</a></td>
 <td align=center>WCR</td>
 <td align=center>Stanford University</td>
 <td align=center>EM64T-4</td>
 <td align=center>1856</td>
 <td align=center>2.33</td>
 <td align=center>17297.92</td>
 <td align=center>Stanford</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1193">(1193) More</a></td>
 <td align=center>Satolep</td>
 <td align=center>Departamento de Física - IFM - UFPEL</td>
 <td align=center>EM64T</td>
 <td align=center>18</td>
 <td align=center>2.80</td>
 <td align=center>100.8</td>
 <td align=center>Pelotas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1192">(1192) More</a></td>
 <td align=center>Centic</td>
 <td align=center>UIS</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>Bucaramanga</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1191">(1191) More</a></td>
 <td align=center>Shark</td>
 <td align=center>Calit2</td>
 <td align=center>EM64T</td>
 <td align=center>512</td>
 <td align=center>2.33</td>
 <td align=center>2385.92</td>
 <td align=center>La Jolla</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1190">(1190) More</a></td>
 <td align=center>HERD</td>
 <td align=center>SEA LLC</td>
 <td align=center>Athlon 64</td>
 <td align=center>9</td>
 <td align=center>2.60</td>
 <td align=center>46.8</td>
 <td align=center>Albuquerque, NM</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1189">(1189) More</a></td>
 <td align=center>cluster.hpc.org</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Athlon 64</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>3.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1188">(1188) More</a></td>
 <td align=center>PhD</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>70</td>
 <td align=center>2.40</td>
 <td align=center>336</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1187">(1187) More</a></td>
 <td align=center>Odette</td>
 <td align=center>Fairleigh Dickinson University - Becton College Chemistry Dept.</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>0.80</td>
 <td align=center>9.6</td>
 <td align=center>Madison, New Jersey</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1186">(1186) More</a></td>
 <td align=center>Keck</td>
 <td align=center>Baylor University</td>
 <td align=center>Pentium 3</td>
 <td align=center>17</td>
 <td align=center>0.80</td>
 <td align=center>13.6</td>
 <td align=center>Waco Texas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1185">(1185) More</a></td>
 <td align=center>Projeto Velociraptor I</td>
 <td align=center>UNISUL - Universidade do Sul de Santa Catarina</td>
 <td align=center>Pentium 3</td>
 <td align=center>24</td>
 <td align=center>1.80</td>
 <td align=center>43.2</td>
 <td align=center>Palhoça</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1184">(1184) More</a></td>
 <td align=center>Ipazia</td>
 <td align=center>Empa - Materials Science & Technology</td>
 <td align=center>EM64T</td>
 <td align=center>80</td>
 <td align=center>2.33</td>
 <td align=center>372.8</td>
 <td align=center>Duebendorf, Switzerland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1181">(1181) More</a></td>
 <td align=center>CCNi Glasgow University</td>
 <td align=center>Univeristy of Glasgow</td>
 <td align=center>EM64T</td>
 <td align=center>106</td>
 <td align=center>3.60</td>
 <td align=center>763.2</td>
 <td align=center>Glasgow, UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1178">(1178) More</a></td>
 <td align=center>Imapenguin Cluster 1</td>
 <td align=center>Imapenguin</td>
 <td align=center>Athlon 64</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>Fredericksburg VA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1175">(1175) More</a></td>
 <td align=center>Tuna</td>
 <td align=center>University of Oklahoma</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>2.40</td>
 <td align=center>48</td>
 <td align=center>Norman, OK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1171">(1171) More</a></td>
 <td align=center>HUABIF</td>
 <td align=center>CCS Haryana Agricultural University</td>
 <td align=center>Athlon 64</td>
 <td align=center>9</td>
 <td align=center>2.60</td>
 <td align=center>46.8</td>
 <td align=center>HISAR, INDIA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1170">(1170) More</a></td>
 <td align=center>The Door 2.0</td>
 <td align=center>Isothermal Community College</td>
 <td align=center>Pentium 3</td>
 <td align=center>16</td>
 <td align=center>0.53</td>
 <td align=center>8.48</td>
 <td align=center>Spindale, NC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1169">(1169) More</a></td>
 <td align=center>cm134</td>
 <td align=center>Universidad de Oviedo</td>
 <td align=center>EM64T</td>
 <td align=center>54</td>
 <td align=center>1.60</td>
 <td align=center>172.8</td>
 <td align=center>Oviedo, Asturias</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1167">(1167) More</a></td>
 <td align=center>Tera</td>
 <td align=center>Thai National Grid Center</td>
 <td align=center>EM64T</td>
 <td align=center>800</td>
 <td align=center>3.00</td>
 <td align=center>4800</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1166">(1166) More</a></td>
 <td align=center>Birch</td>
 <td align=center>Earth and Planetary Science, UC Berkeley</td>
 <td align=center>Opteron</td>
 <td align=center>8</td>
 <td align=center>2.40</td>
 <td align=center>38.4</td>
 <td align=center>Berkeley, CA, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1164">(1164) More</a></td>
 <td align=center>MARC</td>
 <td align=center>Coastal Carolina University</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.00</td>
 <td align=center>256</td>
 <td align=center>Conway</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1163">(1163) More</a></td>
 <td align=center>HAWK</td>
 <td align=center>Nagoya University</td>
 <td align=center>Opteron</td>
 <td align=center>170</td>
 <td align=center>2.40</td>
 <td align=center>816</td>
 <td align=center>Nagoya, Japan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1162">(1162) More</a></td>
 <td align=center>FU Planetology PR</td>
 <td align=center>Freie Universitaet Berlin</td>
 <td align=center>EM64T-4</td>
 <td align=center>12</td>
 <td align=center>3.00</td>
 <td align=center>144</td>
 <td align=center>Berlin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1161">(1161) More</a></td>
 <td align=center>mariscal</td>
 <td align=center>USC</td>
 <td align=center>EM64T</td>
 <td align=center>128</td>
 <td align=center>2.33</td>
 <td align=center>596.48</td>
 <td align=center>Santiago de Compostela</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1160">(1160) More</a></td>
 <td align=center>PLEIADES</td>
 <td align=center>Coastal Carolina University</td>
 <td align=center>Athlon MP</td>
 <td align=center>16</td>
 <td align=center>1.90</td>
 <td align=center>60.8</td>
 <td align=center>Conway,South Carolina</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1159">(1159) More</a></td>
 <td align=center>MEATBALL</td>
 <td align=center>NOAA NWS MKX</td>
 <td align=center>Other</td>
 <td align=center>10</td>
 <td align=center>2.40</td>
 <td align=center>24</td>
 <td align=center>Dousman, WI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1158">(1158) More</a></td>
 <td align=center>Butte Lab</td>
 <td align=center>Stanford Medical Informatics</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Stanford</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1153">(1153) More</a></td>
 <td align=center>MareBalticum</td>
 <td align=center>KB-11</td>
 <td align=center>EM64T</td>
 <td align=center>24</td>
 <td align=center>2.50</td>
 <td align=center>120</td>
 <td align=center>Kaliningrad</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1151">(1151) More</a></td>
 <td align=center>Genotypic_Dhrona</td>
 <td align=center>Geotyic Technology Pvt Ltd</td>
 <td align=center>Opteron</td>
 <td align=center>4</td>
 <td align=center>1.80</td>
 <td align=center>14.4</td>
 <td align=center>Bangalore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1150">(1150) More</a></td>
 <td align=center>B.U.H.O.S.</td>
 <td align=center>Instituto Tecnologico de Orizaba</td>
 <td align=center>Pentium</td>
 <td align=center>5</td>
 <td align=center>0.50</td>
 <td align=center>2.5</td>
 <td align=center>Orizaba, Veracruz</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1149">(1149) More</a></td>
 <td align=center>Convexus</td>
 <td align=center>Convexus Advisors</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>1.80</td>
 <td align=center>115.2</td>
 <td align=center>San Francisco</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1148">(1148) More</a></td>
 <td align=center>MBI Cluster</td>
 <td align=center>Mind-Brain Institute, Johns Hopkins</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>3.50</td>
 <td align=center>448</td>
 <td align=center>Baltimore, MD</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1146">(1146) More</a></td>
 <td align=center>Solstorm</td>
 <td align=center>NTNU, Dep. Industrial Econ. and Tech Management</td>
 <td align=center>Opteron</td>
 <td align=center>2732</td>
 <td align=center>2.40</td>
 <td align=center>13113.6</td>
 <td align=center>Trondheim, Norway</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1145">(1145) More</a></td>
 <td align=center>clique</td>
 <td align=center>Materials Research Laboratory</td>
 <td align=center>Pentium 4</td>
 <td align=center>68</td>
 <td align=center>3.20</td>
 <td align=center>435.2</td>
 <td align=center>University of California, Santa Barbara</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1144">(1144) More</a></td>
 <td align=center>Boron</td>
 <td align=center>University of the Sciences in Philadelphia</td>
 <td align=center>Athlon 64</td>
 <td align=center>44</td>
 <td align=center>2.60</td>
 <td align=center>228.8</td>
 <td align=center>Philadelphia, PA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1141">(1141) More</a></td>
 <td align=center>inderapura</td>
 <td align=center>Universiti Sains Malaysia</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Penang, Malaysia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1140">(1140) More</a></td>
 <td align=center>D-A-N-Y-X</td>
 <td align=center>CAMBO s.a.s.</td>
 <td align=center>Athlon 64</td>
 <td align=center>30</td>
 <td align=center>2.00</td>
 <td align=center>120</td>
 <td align=center>TELVE</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1139">(1139) More</a></td>
 <td align=center>ETF Beowulf Cluster</td>
 <td align=center>Elektrotehni�?ki fakultet</td>
 <td align=center>Athlon 64</td>
 <td align=center>3</td>
 <td align=center>2.00</td>
 <td align=center>12</td>
 <td align=center>Sarajevo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1136">(1136) More</a></td>
 <td align=center>Velociraptor Unisul</td>
 <td align=center>Unisul</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>1.80</td>
 <td align=center>72</td>
 <td align=center>Sao Jose</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1134">(1134) More</a></td>
 <td align=center>Octopus</td>
 <td align=center>Institute of Molecular Biosciences</td>
 <td align=center>EM64T</td>
 <td align=center>144</td>
 <td align=center>2.83</td>
 <td align=center>815.04</td>
 <td align=center>Frankfurt (Germany)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1133">(1133) More</a></td>
 <td align=center>engendro</td>
 <td align=center>Universidad de Antioquia</td>
 <td align=center>Pentium</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>33.6</td>
 <td align=center>Medellin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1131">(1131) More</a></td>
 <td align=center>LiangLab3</td>
 <td align=center>USTC</td>
 <td align=center>Opteron</td>
 <td align=center>36</td>
 <td align=center>2.30</td>
 <td align=center>165.6</td>
 <td align=center>Anhui Hefei</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1129">(1129) More</a></td>
 <td align=center>Babyrocks</td>
 <td align=center>Rincon Research Corporation</td>
 <td align=center>Athlon 64</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Tucson, AZ</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1128">(1128) More</a></td>
 <td align=center>rocks.ds.geneseo.edu</td>
 <td align=center>SUNY Geneseo</td>
 <td align=center>Opteron</td>
 <td align=center>2</td>
 <td align=center>2.00</td>
 <td align=center>8</td>
 <td align=center>Geneseo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1127">(1127) More</a></td>
 <td align=center>aleph.eii.us.es</td>
 <td align=center>Nonlinear Physics Group</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>2.20</td>
 <td align=center>105.6</td>
 <td align=center>Sevilla (Spain)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1126">(1126) More</a></td>
 <td align=center>KDAIZ FNSPE CTU AMD64 cluster</td>
 <td align=center>Faculty of Nuclear Sciences and Physical Engeneering</td>
 <td align=center>Opteron</td>
 <td align=center>15</td>
 <td align=center>1.80</td>
 <td align=center>54</td>
 <td align=center>Prague</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1125">(1125) More</a></td>
 <td align=center>Ravel</td>
 <td align=center>Computer Science Dept., California Polytechnic State University</td>
 <td align=center>EM64T</td>
 <td align=center>92</td>
 <td align=center>2.00</td>
 <td align=center>368</td>
 <td align=center>San Luis Obispo, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1124">(1124) More</a></td>
 <td align=center>MetSat - UA</td>
 <td align=center>Universidade de Aveiro</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>2.80</td>
 <td align=center>44.8</td>
 <td align=center>Aveiro, Portugal</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1123">(1123) More</a></td>
 <td align=center>Uma</td>
 <td align=center>Alo Groups, LLC</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>2.60</td>
 <td align=center>166.4</td>
 <td align=center>Albuquerque</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1121">(1121) More</a></td>
 <td align=center>Aerocluster</td>
 <td align=center>IIT Bombay</td>
 <td align=center>Pentium 4</td>
 <td align=center>15</td>
 <td align=center>1.86</td>
 <td align=center>55.8</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1120">(1120) More</a></td>
 <td align=center>PIZAG Cluster</td>
 <td align=center>Gazi University, Physisc Department</td>
 <td align=center>EM64T</td>
 <td align=center>30</td>
 <td align=center>3.00</td>
 <td align=center>180</td>
 <td align=center>Ankara</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1119">(1119) More</a></td>
 <td align=center>OMII-Europe Edinburgh Evaluation Infrastructure</td>
 <td align=center>EPCC</td>
 <td align=center>Athlon 64</td>
 <td align=center>36</td>
 <td align=center>1.80</td>
 <td align=center>129.6</td>
 <td align=center>Edinburgh</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1118">(1118) More</a></td>
 <td align=center>Commodore64</td>
 <td align=center>Wayne State University</td>
 <td align=center>Opteron</td>
 <td align=center>450</td>
 <td align=center>2.40</td>
 <td align=center>2160</td>
 <td align=center>Detroit</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1117">(1117) More</a></td>
 <td align=center>Image Sciences Linux Cluster</td>
 <td align=center>Cleveland Clinic</td>
 <td align=center>EM64T</td>
 <td align=center>20</td>
 <td align=center>2.33</td>
 <td align=center>93.2</td>
 <td align=center>Cleveland, Ohio</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1116">(1116) More</a></td>
 <td align=center>tstcl4</td>
 <td align=center>von Karman Institute</td>
 <td align=center>EM64T</td>
 <td align=center>110</td>
 <td align=center>2.40</td>
 <td align=center>528</td>
 <td align=center>Bruxelles, Belgium</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1115">(1115) More</a></td>
 <td align=center>Dinkum-thinkum</td>
 <td align=center>LaBRI/INRIA</td>
 <td align=center>Opteron</td>
 <td align=center>62</td>
 <td align=center>2.60</td>
 <td align=center>322.4</td>
 <td align=center>Bordeaux, France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1114">(1114) More</a></td>
 <td align=center>almond</td>
 <td align=center>BRIDGE, University of Bristol</td>
 <td align=center>Opteron</td>
 <td align=center>36</td>
 <td align=center>2.80</td>
 <td align=center>201.6</td>
 <td align=center>Bristol UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1113">(1113) More</a></td>
 <td align=center>CARES Cluster</td>
 <td align=center>Clarkson University</td>
 <td align=center>Itanium 2</td>
 <td align=center>116</td>
 <td align=center>3.60</td>
 <td align=center>1670.4</td>
 <td align=center>Potsdam, NY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1112">(1112) More</a></td>
 <td align=center>Poseidon</td>
 <td align=center>UW Madison - Dept Atmos. & Oceanic Sci</td>
 <td align=center>Opteron</td>
 <td align=center>36</td>
 <td align=center>2.14</td>
 <td align=center>154.08</td>
 <td align=center>Madison Wisconsin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1111">(1111) More</a></td>
 <td align=center>BERAM</td>
 <td align=center>SMS-Meteocenter</td>
 <td align=center>EM64T-4</td>
 <td align=center>48</td>
 <td align=center>3.00</td>
 <td align=center>576</td>
 <td align=center>Faenza</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1110">(1110) More</a></td>
 <td align=center>Flash.physics...</td>
 <td align=center>Physics Dept., University of Miami</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>2.66</td>
 <td align=center>212.8</td>
 <td align=center>Coral Gables, FL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1109">(1109) More</a></td>
 <td align=center>ydra</td>
 <td align=center>Physics Dept., University of Miami</td>
 <td align=center>EM64T</td>
 <td align=center>200</td>
 <td align=center>2.66</td>
 <td align=center>1064</td>
 <td align=center>Coral Gables, FL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1107">(1107) More</a></td>
 <td align=center>hermes0</td>
 <td align=center>Universidad de Valladolid</td>
 <td align=center>Athlon XP</td>
 <td align=center>10</td>
 <td align=center>1.40</td>
 <td align=center>28</td>
 <td align=center>Valladolid</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1106">(1106) More</a></td>
 <td align=center>Dijkstra</td>
 <td align=center>CompCore, Cal State East Bay</td>
 <td align=center>EM64T-4</td>
 <td align=center>48</td>
 <td align=center>1.86</td>
 <td align=center>357.12</td>
 <td align=center>Hayward, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1105">(1105) More</a></td>
 <td align=center>PPM Cluster</td>
 <td align=center>PPM Energy</td>
 <td align=center>Opteron</td>
 <td align=center>368</td>
 <td align=center>1.80</td>
 <td align=center>1324.8</td>
 <td align=center>Portland, OR</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1104">(1104) More</a></td>
 <td align=center>Calculon</td>
 <td align=center>Michigan State University</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>East Lansing</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1103">(1103) More</a></td>
 <td align=center>Black Dragon 2</td>
 <td align=center>KSS</td>
 <td align=center>Opteron</td>
 <td align=center>38</td>
 <td align=center>2.80</td>
 <td align=center>212.8</td>
 <td align=center>Raunheim / Germany</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1102">(1102) More</a></td>
 <td align=center>NEES Simulation Cluster</td>
 <td align=center>NEESit</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>La Jolla, California</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1101">(1101) More</a></td>
 <td align=center>HotTop</td>
 <td align=center>Private</td>
 <td align=center>Opteron</td>
 <td align=center>138</td>
 <td align=center>2.60</td>
 <td align=center>717.6</td>
 <td align=center>Denmark, Copenhagen</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1100">(1100) More</a></td>
 <td align=center>IBM Austin Research Lab</td>
 <td align=center>IBM Research</td>
 <td align=center>Opteron</td>
 <td align=center>48</td>
 <td align=center>2.20</td>
 <td align=center>211.2</td>
 <td align=center>Austin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1099">(1099) More</a></td>
 <td align=center>SUN 8400</td>
 <td align=center>Aten</td>
 <td align=center>Athlon 64</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>3.6</td>
 <td align=center>Taipei</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1098">(1098) More</a></td>
 <td align=center>QuantCalc Cluster</td>
 <td align=center>QuantComp Co.</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>2.40</td>
 <td align=center>24</td>
 <td align=center>Berkeley, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1097">(1097) More</a></td>
 <td align=center>Sibilla</td>
 <td align=center>University of Camerino, Physics Dept. - INFM/CNR</td>
 <td align=center>Athlon 64</td>
 <td align=center>22</td>
 <td align=center>2.50</td>
 <td align=center>110</td>
 <td align=center>Camerino</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1096">(1096) More</a></td>
 <td align=center>godot</td>
 <td align=center>Paris-Meudon Observatory</td>
 <td align=center>Opteron</td>
 <td align=center>56</td>
 <td align=center>2.20</td>
 <td align=center>246.4</td>
 <td align=center>Meudon</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1095">(1095) More</a></td>
 <td align=center>we</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>15</td>
 <td align=center>1.70</td>
 <td align=center>51</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1094">(1094) More</a></td>
 <td align=center>WPI CS Research Cluster</td>
 <td align=center>WPI</td>
 <td align=center>Opteron</td>
 <td align=center>84</td>
 <td align=center>2.60</td>
 <td align=center>436.8</td>
 <td align=center>Worcester, MA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1093">(1093) More</a></td>
 <td align=center>whataboutbobsV2</td>
 <td align=center>SEI</td>
 <td align=center>Pentium 2</td>
 <td align=center>8</td>
 <td align=center>0.45</td>
 <td align=center>3.6</td>
 <td align=center>San Marcos, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1092">(1092) More</a></td>
 <td align=center>Solace</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>1.70</td>
 <td align=center>13.6</td>
 <td align=center>Herkimer, NY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1091">(1091) More</a></td>
 <td align=center>Stella</td>
 <td align=center>University of Michigan - Human Genetics</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>3.00</td>
 <td align=center>30</td>
 <td align=center>Ann Arbor, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1090">(1090) More</a></td>
 <td align=center>Maryville</td>
 <td align=center>Vienna UT/Inst. f. Theoretical Physics</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.00</td>
 <td align=center>96</td>
 <td align=center>Vienna</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1089">(1089) More</a></td>
 <td align=center>Stefan Virgil Hobai</td>
 <td align=center>Universitatea de Medicina si Farmacie</td>
 <td align=center>Athlon XP</td>
 <td align=center>2</td>
 <td align=center>1.50</td>
 <td align=center>6</td>
 <td align=center>Targu Mures</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1088">(1088) More</a></td>
 <td align=center>mettatron</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 2</td>
 <td align=center>4</td>
 <td align=center>1.20</td>
 <td align=center>4.8</td>
 <td align=center>Rock Port Mo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1087">(1087) More</a></td>
 <td align=center>gvbiobrew</td>
 <td align=center>Penn State Great Valley</td>
 <td align=center>Pentium 3</td>
 <td align=center>20</td>
 <td align=center>0.72</td>
 <td align=center>14.4</td>
 <td align=center>Malvern, PA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1086">(1086) More</a></td>
 <td align=center>Stefan Hobai</td>
 <td align=center>University of Medicine & Pharmacy</td>
 <td align=center>Athlon XP</td>
 <td align=center>1</td>
 <td align=center>2.01</td>
 <td align=center>4.02</td>
 <td align=center>Targu Mures</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1085">(1085) More</a></td>
 <td align=center>Fly</td>
 <td align=center>Hampshire College School of Cognitive Science</td>
 <td align=center>Athlon 64</td>
 <td align=center>158</td>
 <td align=center>3.00</td>
 <td align=center>948</td>
 <td align=center>Amherst, MA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1083">(1083) More</a></td>
 <td align=center>Moqui</td>
 <td align=center>Pacific Northwest National Laboratory</td>
 <td align=center>Itanium 2</td>
 <td align=center>10</td>
 <td align=center>0.90</td>
 <td align=center>36</td>
 <td align=center>Richland, Washington</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1081">(1081) More</a></td>
 <td align=center>jxintercluster</td>
 <td align=center>rst</td>
 <td align=center>Other</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>rst</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1079">(1079) More</a></td>
 <td align=center>amber</td>
 <td align=center>Univeristy of Hyderabad</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>1.80</td>
 <td align=center>28.8</td>
 <td align=center>Hyderabad</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1078">(1078) More</a></td>
 <td align=center>Hyades.astro.virginia.edu</td>
 <td align=center>University of Virginia Astronomy Dept</td>
 <td align=center>EM64T</td>
 <td align=center>58</td>
 <td align=center>2.80</td>
 <td align=center>324.8</td>
 <td align=center>Charlottesville, VA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1077">(1077) More</a></td>
 <td align=center>Black Mamba</td>
 <td align=center>Cinvestav - Langebio</td>
 <td align=center>EM64T</td>
 <td align=center>22</td>
 <td align=center>1.60</td>
 <td align=center>70.4</td>
 <td align=center>Irapuato</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1076">(1076) More</a></td>
 <td align=center>cdac-rtsg</td>
 <td align=center>CDAC</td>
 <td align=center>Opteron</td>
 <td align=center>72</td>
 <td align=center>2.20</td>
 <td align=center>316.8</td>
 <td align=center>Bangalore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1075">(1075) More</a></td>
 <td align=center>Crypt</td>
 <td align=center>C-DAC</td>
 <td align=center>Opteron</td>
 <td align=center>72</td>
 <td align=center>2.20</td>
 <td align=center>316.8</td>
 <td align=center>Bangalore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1073">(1073) More</a></td>
 <td align=center>tornado</td>
 <td align=center>Naval Research Laboratory</td>
 <td align=center>Pentium 4</td>
 <td align=center>40</td>
 <td align=center>2.80</td>
 <td align=center>224</td>
 <td align=center>Monterey</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1072">(1072) More</a></td>
 <td align=center>thunder</td>
 <td align=center>Naval Research Laboratory</td>
 <td align=center>Pentium 3</td>
 <td align=center>24</td>
 <td align=center>1.20</td>
 <td align=center>28.8</td>
 <td align=center>Monterey</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1071">(1071) More</a></td>
 <td align=center>Ateneo MedGrid cluster</td>
 <td align=center>Ateneo de Manila University</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Loyola Heights, Quezon City, Philippines</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1070">(1070) More</a></td>
 <td align=center>ROESCH.NET</td>
 <td align=center>N/A</td>
 <td align=center>Athlon XP</td>
 <td align=center>4</td>
 <td align=center>1.80</td>
 <td align=center>14.4</td>
 <td align=center>Karlsruhe</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1069">(1069) More</a></td>
 <td align=center>Smith v2.0</td>
 <td align=center>AMD Developer Center</td>
 <td align=center>Opteron</td>
 <td align=center>320</td>
 <td align=center>2.80</td>
 <td align=center>1792</td>
 <td align=center>Sunnyvale</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1068">(1068) More</a></td>
 <td align=center>htht</td>
 <td align=center>DTE.THU</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>1.83</td>
 <td align=center>117.12</td>
 <td align=center>Beijing, China</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1066">(1066) More</a></td>
 <td align=center>smarteyes</td>
 <td align=center>Brown University</td>
 <td align=center>Athlon 64</td>
 <td align=center>46</td>
 <td align=center>1.80</td>
 <td align=center>165.6</td>
 <td align=center>Providence, RI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1065">(1065) More</a></td>
 <td align=center>quqnatumchem</td>
 <td align=center>Fuzhou University</td>
 <td align=center>EM64T</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>67.2</td>
 <td align=center>Fuzhou, China</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1063">(1063) More</a></td>
 <td align=center>ACluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Opteron</td>
 <td align=center>120</td>
 <td align=center>2.20</td>
 <td align=center>528</td>
 <td align=center>Burbank, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1062">(1062) More</a></td>
 <td align=center>Nangate</td>
 <td align=center>Nangate Inc.</td>
 <td align=center>EM64T</td>
 <td align=center>265</td>
 <td align=center>3.20</td>
 <td align=center>1696</td>
 <td align=center>Sunnyvale, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1059">(1059) More</a></td>
 <td align=center>Weather Wall</td>
 <td align=center>Atmospheric Oceanic & Space Science</td>
 <td align=center>Opteron</td>
 <td align=center>14</td>
 <td align=center>2.40</td>
 <td align=center>67.2</td>
 <td align=center>University of Michigan Ann Arbor</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1056">(1056) More</a></td>
 <td align=center>Horus</td>
 <td align=center>Codex Remote</td>
 <td align=center>Opteron</td>
 <td align=center>14</td>
 <td align=center>2.40</td>
 <td align=center>67.2</td>
 <td align=center>porto Alegre</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1053">(1053) More</a></td>
 <td align=center>corona.iitb.ac.in</td>
 <td align=center>IIT Bombay</td>
 <td align=center>Opteron</td>
 <td align=center>128</td>
 <td align=center>2.80</td>
 <td align=center>716.8</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1052">(1052) More</a></td>
 <td align=center>alfa</td>
 <td align=center>Instituto de Investigaciones Biotecnologicas</td>
 <td align=center>Opteron</td>
 <td align=center>6</td>
 <td align=center>2.20</td>
 <td align=center>26.4</td>
 <td align=center>San Martin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1039">(1039) More</a></td>
 <td align=center>esignet</td>
 <td align=center>Eindhoven University of Technology</td>
 <td align=center>Opteron</td>
 <td align=center>148</td>
 <td align=center>2.00</td>
 <td align=center>592</td>
 <td align=center>Eindhoven The Netherlands</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1036">(1036) More</a></td>
 <td align=center>SUU Linux Cluster</td>
 <td align=center>Southern Utah University</td>
 <td align=center>EM64T</td>
 <td align=center>60</td>
 <td align=center>1.60</td>
 <td align=center>192</td>
 <td align=center>Cedar City, UT</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1035">(1035) More</a></td>
 <td align=center>The Farm</td>
 <td align=center>University of Michigan - Human Genetics</td>
 <td align=center>EM64T</td>
 <td align=center>604</td>
 <td align=center>3.33</td>
 <td align=center>4022.64</td>
 <td align=center>Ann Arbor, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1031">(1031) More</a></td>
 <td align=center>Kantishna</td>
 <td align=center>NEESit</td>
 <td align=center>Pentium 4</td>
 <td align=center>9</td>
 <td align=center>3.00</td>
 <td align=center>54</td>
 <td align=center>La Jolla, California</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1030">(1030) More</a></td>
 <td align=center>hpc-angel</td>
 <td align=center>Mustafa Kemal University</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Hatay</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1029">(1029) More</a></td>
 <td align=center>gridROCKS</td>
 <td align=center>High Energy Physics</td>
 <td align=center>Other</td>
 <td align=center>40</td>
 <td align=center>2.40</td>
 <td align=center>96</td>
 <td align=center>Tallahassee, FL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1028">(1028) More</a></td>
 <td align=center>comphy</td>
 <td align=center>FSU Department of Physics</td>
 <td align=center>Pentium</td>
 <td align=center>76</td>
 <td align=center>0.60</td>
 <td align=center>45.6</td>
 <td align=center>Tallahassee, FL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1027">(1027) More</a></td>
 <td align=center>UTDCluster</td>
 <td align=center>University of Texas at Dallas</td>
 <td align=center>Pentium 4</td>
 <td align=center>47</td>
 <td align=center>1.80</td>
 <td align=center>169.2</td>
 <td align=center>Dallas TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1024">(1024) More</a></td>
 <td align=center>Radiant</td>
 <td align=center>Kasetsart University, TNGP</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1023">(1023) More</a></td>
 <td align=center>cmu_grid</td>
 <td align=center>Chiangmai University, TNGP</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Chiangmai</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1022">(1022) More</a></td>
 <td align=center>DEQUEUE</td>
 <td align=center>King Monkut Institute of Technology North Bangkok & TNGP</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1020">(1020) More</a></td>
 <td align=center>landau</td>
 <td align=center>Seagate</td>
 <td align=center>Pentium 4</td>
 <td align=center>145</td>
 <td align=center>3.00</td>
 <td align=center>870</td>
 <td align=center>Fremont, CA, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1018">(1018) More</a></td>
 <td align=center>Jade</td>
 <td align=center>AMD Developer Center</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.80</td>
 <td align=center>358.4</td>
 <td align=center>Sunnyvale</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1017">(1017) More</a></td>
 <td align=center>Biosciences</td>
 <td align=center>INSA  - Dept. Biosciences</td>
 <td align=center>Athlon</td>
 <td align=center>20</td>
 <td align=center>2.00</td>
 <td align=center>40</td>
 <td align=center>Villeurbanne</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1016">(1016) More</a></td>
 <td align=center>armada</td>
 <td align=center>Naval Research Laboratory</td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>2.20</td>
 <td align=center>52.8</td>
 <td align=center>Washington, DC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1015">(1015) More</a></td>
 <td align=center>Finacluster</td>
 <td align=center>Quantstar Company LLC.</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>2.80</td>
 <td align=center>28</td>
 <td align=center>Schaumburg</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1013">(1013) More</a></td>
 <td align=center>Uzay</td>
 <td align=center>Trakya Univeristy</td>
 <td align=center>Opteron</td>
 <td align=center>18</td>
 <td align=center>1.80</td>
 <td align=center>64.8</td>
 <td align=center>Edirne</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1012">(1012) More</a></td>
 <td align=center>cfd.etp.ac.cn</td>
 <td align=center>CAS</td>
 <td align=center>Other</td>
 <td align=center>40</td>
 <td align=center>3.00</td>
 <td align=center>120</td>
 <td align=center>Beijing, China</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1011">(1011) More</a></td>
 <td align=center>UNSW PV Gauss</td>
 <td align=center>Key Centre for Photovoltaics, UNSW</td>
 <td align=center>Opteron</td>
 <td align=center>44</td>
 <td align=center>2.00</td>
 <td align=center>176</td>
 <td align=center>Sydney, NSW, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1010">(1010) More</a></td>
 <td align=center>cluster-math.mathst.univ-fcomte.fr</td>
 <td align=center>Mathematics Laboratory</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>1.80</td>
 <td align=center>43.2</td>
 <td align=center>Besancon, France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1009">(1009) More</a></td>
 <td align=center>1111111111111111</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Athlon MP</td>
 <td align=center>2</td>
 <td align=center>1.40</td>
 <td align=center>5.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1008">(1008) More</a></td>
 <td align=center>hydra@uowm</td>
 <td align=center>uowm-enman</td>
 <td align=center>EM64T</td>
 <td align=center>4</td>
 <td align=center>2.20</td>
 <td align=center>17.6</td>
 <td align=center>kozani, greece</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1006">(1006) More</a></td>
 <td align=center>Dryad</td>
 <td align=center>University of California</td>
 <td align=center>Athlon XP</td>
 <td align=center>102</td>
 <td align=center>1.60</td>
 <td align=center>326.4</td>
 <td align=center>Davis</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1004">(1004) More</a></td>
 <td align=center>Training2</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1003">(1003) More</a></td>
 <td align=center>Training1</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1002">(1002) More</a></td>
 <td align=center>1058-R1</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Earth</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=1001">(1001) More</a></td>
 <td align=center>1046-R1</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Earth</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1000">(1000) More</a></td>
 <td align=center>1004-R1</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>28</td>
 <td align=center>2.20</td>
 <td align=center>123.2</td>
 <td align=center>Earth</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=999">(999) More</a></td>
 <td align=center>c11</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=998">(998) More</a></td>
 <td align=center>Bunker1</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=997">(997) More</a></td>
 <td align=center>V&V3</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=996">(996) More</a></td>
 <td align=center>V&V2</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=995">(995) More</a></td>
 <td align=center>V&V1</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.60</td>
 <td align=center>166.4</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=994">(994) More</a></td>
 <td align=center>pegasus</td>
 <td align=center>School of Chemical Engineering, National Technical University of</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>3.00</td>
 <td align=center>192</td>
 <td align=center>Athens, Greece</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=993">(993) More</a></td>
 <td align=center>Luminizer2</td>
 <td align=center>Luminescent Technologies, Inc.</td>
 <td align=center>EM64T</td>
 <td align=center>196</td>
 <td align=center>2.80</td>
 <td align=center>1097.6</td>
 <td align=center>Palo Alto, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=992">(992) More</a></td>
 <td align=center>Luminizer1</td>
 <td align=center>Luminescent Technologies, Inc.</td>
 <td align=center>Pentium 4</td>
 <td align=center>166</td>
 <td align=center>2.80</td>
 <td align=center>929.6</td>
 <td align=center>Palo Alto, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=991">(991) More</a></td>
 <td align=center>A*i*A</td>
 <td align=center>Molecular Biology Institute at UCLA</td>
 <td align=center>Pentium 4</td>
 <td align=center>100</td>
 <td align=center>2.40</td>
 <td align=center>480</td>
 <td align=center>Los Angeles</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=990">(990) More</a></td>
 <td align=center>Comic</td>
 <td align=center>University College London -CS</td>
 <td align=center>EM64T</td>
 <td align=center>76</td>
 <td align=center>2.66</td>
 <td align=center>404.32</td>
 <td align=center>London</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=989">(989) More</a></td>
 <td align=center>Buffy</td>
 <td align=center>University College London -CS</td>
 <td align=center>Pentium</td>
 <td align=center>332</td>
 <td align=center>1.20</td>
 <td align=center>398.4</td>
 <td align=center>London</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=988">(988) More</a></td>
 <td align=center>Comic100</td>
 <td align=center>University College London -CS</td>
 <td align=center>Opteron</td>
 <td align=center>66</td>
 <td align=center>2.40</td>
 <td align=center>316.8</td>
 <td align=center>London</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=987">(987) More</a></td>
 <td align=center>chemcluster</td>
 <td align=center>University of Malaya</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.40</td>
 <td align=center>38.4</td>
 <td align=center>Kuala Lumpur, Malaysia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=986">(986) More</a></td>
 <td align=center>NKS-160</td>
 <td align=center>ICM&MG SB RAS</td>
 <td align=center>Itanium 2</td>
 <td align=center>80</td>
 <td align=center>1.60</td>
 <td align=center>512</td>
 <td align=center>Novosibirsk, Russia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=985">(985) More</a></td>
 <td align=center>grappe</td>
 <td align=center>CNRS</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>3.00</td>
 <td align=center>48</td>
 <td align=center>Saint-Maur des Fosses (Paris)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=984">(984) More</a></td>
 <td align=center>sigurd</td>
 <td align=center>Nemours Biomedical Research</td>
 <td align=center>Athlon 64</td>
 <td align=center>11</td>
 <td align=center>2.00</td>
 <td align=center>44</td>
 <td align=center>Wilmington Delaware</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=982">(982) More</a></td>
 <td align=center>miniCluster2</td>
 <td align=center>University of Michigan - Human Genetics</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>1.70</td>
 <td align=center>17</td>
 <td align=center>Ann Arbor, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=981">(981) More</a></td>
 <td align=center>Cartman</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 3</td>
 <td align=center>28</td>
 <td align=center>1.00</td>
 <td align=center>28</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=980">(980) More</a></td>
 <td align=center>Perovskite</td>
 <td align=center>Carnegie Institution of Washington</td>
 <td align=center>Opteron</td>
 <td align=center>144</td>
 <td align=center>2.20</td>
 <td align=center>633.6</td>
 <td align=center>Washington</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=979">(979) More</a></td>
 <td align=center>Xenia</td>
 <td align=center>Carnegie Institution of Washington</td>
 <td align=center>Pentium 4</td>
 <td align=center>96</td>
 <td align=center>2.80</td>
 <td align=center>537.6</td>
 <td align=center>Washington</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=978">(978) More</a></td>
 <td align=center>CMVDR</td>
 <td align=center>Dalhousie University</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>3.60</td>
 <td align=center>115.2</td>
 <td align=center>Halifax, NS</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=977">(977) More</a></td>
 <td align=center>Trillion</td>
 <td align=center>University of Arkansas</td>
 <td align=center>Opteron</td>
 <td align=center>96</td>
 <td align=center>2.60</td>
 <td align=center>499.2</td>
 <td align=center>Fayetteville, AR</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=972">(972) More</a></td>
 <td align=center>AU-MIT</td>
 <td align=center>Madras Institute of Technology(MIT)</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.80</td>
 <td align=center>44.8</td>
 <td align=center>Chennai, Tamilnadu, India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=970">(970) More</a></td>
 <td align=center>Thermi</td>
 <td align=center>LETEM</td>
 <td align=center>EM64T</td>
 <td align=center>24</td>
 <td align=center>3.20</td>
 <td align=center>153.6</td>
 <td align=center>Champs Sur Marne (France)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=969">(969) More</a></td>
 <td align=center>Jaws</td>
 <td align=center>MHPCC</td>
 <td align=center>EM64T</td>
 <td align=center>1296</td>
 <td align=center>3.00</td>
 <td align=center>7776</td>
 <td align=center>Maui</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=968">(968) More</a></td>
 <td align=center>rho</td>
 <td align=center>Texas A&M University</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>College Station, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=966">(966) More</a></td>
 <td align=center>Firestorm</td>
 <td align=center>Institute of Physiology ASCR</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>2.00</td>
 <td align=center>40</td>
 <td align=center>Prague</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=965">(965) More</a></td>
 <td align=center>Inca</td>
 <td align=center>King Monkut University of Technology Thonburi & TNGP</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Bangkok, Thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=964">(964) More</a></td>
 <td align=center>SUTGRID</td>
 <td align=center>Suranaree University of Technology & Thai National Grid Project</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Nakorn Ratchasrima, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=963">(963) More</a></td>
 <td align=center>HELIOS</td>
 <td align=center>APSTF, Kasetsart University</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>Bangkok, Thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=962">(962) More</a></td>
 <td align=center>Gridmd</td>
 <td align=center>King Monkut Institute of Technology Ladkrabang & TNGP</td>
 <td align=center>EM64T</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>67.2</td>
 <td align=center>Bangkok, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=961">(961) More</a></td>
 <td align=center>CSIM</td>
 <td align=center>Asia Institute of Technology & Thai National Grid Project</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Bangkok, Thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=960">(960) More</a></td>
 <td align=center>Araya</td>
 <td align=center>Thai National Grid Center</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=959">(959) More</a></td>
 <td align=center>AOG</td>
 <td align=center>SIO/IGPP</td>
 <td align=center>Opteron</td>
 <td align=center>22</td>
 <td align=center>1.80</td>
 <td align=center>79.2</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=956">(956) More</a></td>
 <td align=center>mephitis</td>
 <td align=center>ARPAB</td>
 <td align=center>Unspecified</td>
 <td align=center>4</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>Potenza</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=952">(952) More</a></td>
 <td align=center>RedLinx</td>
 <td align=center>Digital Rocket Science</td>
 <td align=center>Athlon 64</td>
 <td align=center>16</td>
 <td align=center>1.00</td>
 <td align=center>32</td>
 <td align=center>Cape Town</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=950">(950) More</a></td>
 <td align=center>FOX</td>
 <td align=center>Nano Medicine Center at the Univ of Illinois at Urbana-Champaign</td>
 <td align=center>Other</td>
 <td align=center>44</td>
 <td align=center>2.80</td>
 <td align=center>123.2</td>
 <td align=center>Urbana IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=948">(948) More</a></td>
 <td align=center>tulla</td>
 <td align=center>MTEM</td>
 <td align=center>Athlon 64</td>
 <td align=center>8</td>
 <td align=center>2.20</td>
 <td align=center>35.2</td>
 <td align=center>Edinburgh, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=946">(946) More</a></td>
 <td align=center>galaxy.iitb</td>
 <td align=center>Indian Institute of Technology</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>3.20</td>
 <td align=center>409.6</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=944">(944) More</a></td>
 <td align=center>BOREAS</td>
 <td align=center>ULPGC</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>2.60</td>
 <td align=center>15.6</td>
 <td align=center>Las Palmas de GC, Spain</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=943">(943) More</a></td>
 <td align=center>cluster.cs.ait.ac.th</td>
 <td align=center>Asian Institute of technology</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Pathumthani</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=942">(942) More</a></td>
 <td align=center>UMSGrid HPC Cluster</td>
 <td align=center>Universiti Malaysia Sabah</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.80</td>
 <td align=center>44.8</td>
 <td align=center>Kota Kinabalu, Sabah MY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=940">(940) More</a></td>
 <td align=center>Golden Labrador</td>
 <td align=center>US Geological Survey</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>1.80</td>
 <td align=center>288</td>
 <td align=center>Golden, Colorado</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=939">(939) More</a></td>
 <td align=center>UMS Grid Project, Universiti Malaysia Sabah</td>
 <td align=center>Universiti Malaysia Sabah</td>
 <td align=center>Pentium 3</td>
 <td align=center>22</td>
 <td align=center>0.50</td>
 <td align=center>11</td>
 <td align=center>Kota Kinabalu, Sabah</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=938">(938) More</a></td>
 <td align=center>hanuman</td>
 <td align=center>Prince of Songkla University</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>2.80</td>
 <td align=center>112</td>
 <td align=center>Songkla</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=937">(937) More</a></td>
 <td align=center>AIT - CSIM Cluster</td>
 <td align=center>AIT - CSIM</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Klong Luang</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=935">(935) More</a></td>
 <td align=center>Onuchic Group</td>
 <td align=center>University of California, San Diego</td>
 <td align=center>Unspecified</td>
 <td align=center>40</td>
 <td align=center>2.00</td>
 <td align=center>80</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=932">(932) More</a></td>
 <td align=center>TubKaewGrid</td>
 <td align=center>Silpakorn University</td>
 <td align=center>Other</td>
 <td align=center>20</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Nakorn Pathom</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=929">(929) More</a></td>
 <td align=center>wind cluster 2</td>
 <td align=center>Tecnosfera</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.20</td>
 <td align=center>12.8</td>
 <td align=center>Portugal</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=928">(928) More</a></td>
 <td align=center>hypernova</td>
 <td align=center>HyperV Technologies</td>
 <td align=center>Opteron</td>
 <td align=center>17</td>
 <td align=center>2.60</td>
 <td align=center>88.4</td>
 <td align=center>Princeton</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=927">(927) More</a></td>
 <td align=center>Wind Cluster</td>
 <td align=center>Tecnosfera</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.40</td>
 <td align=center>13.6</td>
 <td align=center>Portugal</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=926">(926) More</a></td>
 <td align=center>shawnee</td>
 <td align=center>university of illinois at urbana-champaign</td>
 <td align=center>Athlon 64</td>
 <td align=center>2</td>
 <td align=center>2.40</td>
 <td align=center>9.6</td>
 <td align=center>champaign</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=924">(924) More</a></td>
 <td align=center>One</td>
 <td align=center>Test</td>
 <td align=center>Pentium</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>1.8</td>
 <td align=center>Test</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=923">(923) More</a></td>
 <td align=center>Sunyata</td>
 <td align=center>Thai National Grid Center</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=922">(922) More</a></td>
 <td align=center>SRITHAN Cluster</td>
 <td align=center>Khon Kaen University</td>
 <td align=center>EM64T</td>
 <td align=center>20</td>
 <td align=center>2.80</td>
 <td align=center>112</td>
 <td align=center>Khon Kaen</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=920">(920) More</a></td>
 <td align=center>gaia</td>
 <td align=center>Columbia University</td>
 <td align=center>EM64T</td>
 <td align=center>400</td>
 <td align=center>3.00</td>
 <td align=center>2400</td>
 <td align=center>New York</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=918">(918) More</a></td>
 <td align=center>lc3</td>
 <td align=center>University of Virginia/ITC</td>
 <td align=center>EM64T</td>
 <td align=center>400</td>
 <td align=center>3.00</td>
 <td align=center>2400</td>
 <td align=center>Charlottesville</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=917">(917) More</a></td>
 <td align=center>lc2</td>
 <td align=center>University of Virginia/ITC</td>
 <td align=center>Opteron</td>
 <td align=center>252</td>
 <td align=center>1.80</td>
 <td align=center>907.2</td>
 <td align=center>Charlottesville</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=916">(916) More</a></td>
 <td align=center>Igeon</td>
 <td align=center>Chinese Academy of Secience</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.60</td>
 <td align=center>52</td>
 <td align=center>Beijing ,China</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=915">(915) More</a></td>
 <td align=center>HPCC of Sun Yat-sen University</td>
 <td align=center>Sun Yat-sen University</td>
 <td align=center>EM64T</td>
 <td align=center>130</td>
 <td align=center>2.80</td>
 <td align=center>728</td>
 <td align=center>Guangzhou</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=914">(914) More</a></td>
 <td align=center>Galileo</td>
 <td align=center>Franklin University</td>
 <td align=center>Pentium 3</td>
 <td align=center>7</td>
 <td align=center>1.00</td>
 <td align=center>7</td>
 <td align=center>Columbus, Ohio</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=910">(910) More</a></td>
 <td align=center>ABAC</td>
 <td align=center>Assumption University</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.20</td>
 <td align=center>12.8</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=908">(908) More</a></td>
 <td align=center>tribe</td>
 <td align=center>Computational Science and Engineering, UC Davis</td>
 <td align=center>Opteron</td>
 <td align=center>724</td>
 <td align=center>2.20</td>
 <td align=center>3185.6</td>
 <td align=center>Davis</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=906">(906) More</a></td>
 <td align=center>cpada</td>
 <td align=center>IF-UFRGS</td>
 <td align=center>Athlon MP</td>
 <td align=center>11</td>
 <td align=center>1.40</td>
 <td align=center>30.8</td>
 <td align=center>Porto Alegre</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=905">(905) More</a></td>
 <td align=center>rocks.scs.agilent.com</td>
 <td align=center>Agilent Laboratories</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>2.40</td>
 <td align=center>24</td>
 <td align=center>Santa Clara, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=903">(903) More</a></td>
 <td align=center>htc</td>
 <td align=center>The University of Iowa</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>3.00</td>
 <td align=center>192</td>
 <td align=center>Iowa City</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=902">(902) More</a></td>
 <td align=center>cafeteria_vn</td>
 <td align=center>Hsb</td>
 <td align=center>Pentium 4</td>
 <td align=center>100</td>
 <td align=center>1.80</td>
 <td align=center>360</td>
 <td align=center>Hanoi</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=901">(901) More</a></td>
 <td align=center>piranha</td>
 <td align=center>UVa Computational Materials Group</td>
 <td align=center>Opteron</td>
 <td align=center>40</td>
 <td align=center>2.22</td>
 <td align=center>177.6</td>
 <td align=center>Charlottesville, VA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=900">(900) More</a></td>
 <td align=center>ugster.cs</td>
 <td align=center>University of Waterloo</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>Waterloo</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=896">(896) More</a></td>
 <td align=center>homer.dam</td>
 <td align=center>Brown University CCV/Department of Applied Math</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>2.40</td>
 <td align=center>384</td>
 <td align=center>Providence, RI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=895">(895) More</a></td>
 <td align=center>ccmb.ccv.brown.edu</td>
 <td align=center>Brown University Center for Computational Molecular Biology</td>
 <td align=center>Opteron</td>
 <td align=center>20</td>
 <td align=center>2.40</td>
 <td align=center>96</td>
 <td align=center>Providence, RI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=894">(894) More</a></td>
 <td align=center>ETmasterUT</td>
 <td align=center>Hydropoint Data System, Inc</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>3.20</td>
 <td align=center>256</td>
 <td align=center>Logan, Utah</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=893">(893) More</a></td>
 <td align=center>rockscluster</td>
 <td align=center>USC Pharmaceutical Sciences</td>
 <td align=center>Pentium 4</td>
 <td align=center>14</td>
 <td align=center>2.80</td>
 <td align=center>78.4</td>
 <td align=center>Los Angeles, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=891">(891) More</a></td>
 <td align=center>Torvalds</td>
 <td align=center>UNCW Dept of Computer Science</td>
 <td align=center>EM64T</td>
 <td align=center>24</td>
 <td align=center>2.80</td>
 <td align=center>134.4</td>
 <td align=center>Wilmington, North Carolina</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=890">(890) More</a></td>
 <td align=center>Samin</td>
 <td align=center> Climate Research Center</td>
 <td align=center>EM64T</td>
 <td align=center>256</td>
 <td align=center>3.20</td>
 <td align=center>1638.4</td>
 <td align=center>India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=889">(889) More</a></td>
 <td align=center>perdana</td>
 <td align=center>Center for ICT, University of Malaya</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>2.40</td>
 <td align=center>24</td>
 <td align=center>Kuala Lumpur, Malaysia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=888">(888) More</a></td>
 <td align=center>cftvaldivia</td>
 <td align=center>cefete</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>2.00</td>
 <td align=center>4</td>
 <td align=center>valdivia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=885">(885) More</a></td>
 <td align=center>ciril</td>
 <td align=center>los angeles</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.00</td>
 <td align=center>12</td>
 <td align=center>california, usa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=884">(884) More</a></td>
 <td align=center>Lanec</td>
 <td align=center>Lanec/DEPEB/UFSJ</td>
 <td align=center>Athlon 64</td>
 <td align=center>5</td>
 <td align=center>2.00</td>
 <td align=center>20</td>
 <td align=center>Sao Joao del Rei, Minas Gerais, Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=883">(883) More</a></td>
 <td align=center>garuda</td>
 <td align=center>Centre for Development of Advanced Computing (C-DAC)</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>36</td>
 <td align=center>Bangalore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=882">(882) More</a></td>
 <td align=center>ANATTA</td>
 <td align=center>Thai National Grid Center</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>2.60</td>
 <td align=center>208</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=881">(881) More</a></td>
 <td align=center>AliEn@ISS</td>
 <td align=center>Institute of Space Science</td>
 <td align=center>EM64T</td>
 <td align=center>136</td>
 <td align=center>3.00</td>
 <td align=center>816</td>
 <td align=center>Bucharest</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=879">(879) More</a></td>
 <td align=center>Second Punic Cluster</td>
 <td align=center>hack-mod.com</td>
 <td align=center>Pentium 3</td>
 <td align=center>4</td>
 <td align=center>1.00</td>
 <td align=center>4</td>
 <td align=center>Stuarts Draft</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=878">(878) More</a></td>
 <td align=center>ocikbviz</td>
 <td align=center>University of Zurich</td>
 <td align=center>EM64T</td>
 <td align=center>18</td>
 <td align=center>2.80</td>
 <td align=center>100.8</td>
 <td align=center>Zurich, Switzerland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=877">(877) More</a></td>
 <td align=center>phetchcluster</td>
 <td align=center>su</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>1.60</td>
 <td align=center>3.2</td>
 <td align=center>Phetchaburi</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=876">(876) More</a></td>
 <td align=center>test</td>
 <td align=center>codexremote</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Porto Alegre</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=875">(875) More</a></td>
 <td align=center>aragorn</td>
 <td align=center>University of Illinois</td>
 <td align=center>Athlon</td>
 <td align=center>34</td>
 <td align=center>1.60</td>
 <td align=center>54.4</td>
 <td align=center>Urbana-Champaign</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=874">(874) More</a></td>
 <td align=center>Gauss02</td>
 <td align=center>Seagate</td>
 <td align=center>EM64T</td>
 <td align=center>76</td>
 <td align=center>3.60</td>
 <td align=center>547.2</td>
 <td align=center>Bloomington, MN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=873">(873) More</a></td>
 <td align=center>BELLE, Panjab Univ</td>
 <td align=center>Panjab University Chandigarh</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>2.60</td>
 <td align=center>5.2</td>
 <td align=center>Chandigarh, INDIA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=872">(872) More</a></td>
 <td align=center>cmsdaq</td>
 <td align=center>Panjab University Chandigarh</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>2.66</td>
 <td align=center>5.32</td>
 <td align=center>Chandigarh, INDIA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=871">(871) More</a></td>
 <td align=center>ProvAR</td>
 <td align=center>Provincia di Arezzo</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>Arezzo</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=870">(870) More</a></td>
 <td align=center>Protein-Evolution-UCB-Chem</td>
 <td align=center>UC Berkeley</td>
 <td align=center>Athlon XP</td>
 <td align=center>15</td>
 <td align=center>2.40</td>
 <td align=center>72</td>
 <td align=center>Berkeley</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=869">(869) More</a></td>
 <td align=center>Solaris-UCB-Chem</td>
 <td align=center>UC Berkeley</td>
 <td align=center>Athlon 64</td>
 <td align=center>15</td>
 <td align=center>2.00</td>
 <td align=center>60</td>
 <td align=center>Berkeley</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=868">(868) More</a></td>
 <td align=center>Virgo</td>
 <td align=center>The University of Texas at El Paso</td>
 <td align=center>Pentium 4</td>
 <td align=center>40</td>
 <td align=center>3.06</td>
 <td align=center>244.8</td>
 <td align=center>ElPaso, Texas, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=867">(867) More</a></td>
 <td align=center>LETSIM</td>
 <td align=center>LET - CNRS</td>
 <td align=center>Opteron</td>
 <td align=center>18</td>
 <td align=center>2.40</td>
 <td align=center>86.4</td>
 <td align=center>Lyon</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=866">(866) More</a></td>
 <td align=center>UA HPC</td>
 <td align=center>The University of Alabama</td>
 <td align=center>EM64T</td>
 <td align=center>260</td>
 <td align=center>3.20</td>
 <td align=center>1664</td>
 <td align=center>Tuscaloosa, AL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=864">(864) More</a></td>
 <td align=center>antoniomachine</td>
 <td align=center>Universitat de Lleida</td>
 <td align=center>Opteron</td>
 <td align=center>512</td>
 <td align=center>2.00</td>
 <td align=center>2048</td>
 <td align=center>LLEIDA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=863">(863) More</a></td>
 <td align=center>Samurai</td>
 <td align=center>Michigan Tech University</td>
 <td align=center>Athlon 64</td>
 <td align=center>10</td>
 <td align=center>2.00</td>
 <td align=center>40</td>
 <td align=center>Houghton, MI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=859">(859) More</a></td>
 <td align=center>HSC.YIDEC</td>
 <td align=center>IDEC,Hiroshima University</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>3.40</td>
 <td align=center>108.8</td>
 <td align=center>Higasi-Hiroshima</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=858">(858) More</a></td>
 <td align=center>Young</td>
 <td align=center>Hongik University</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.20</td>
 <td align=center>25.6</td>
 <td align=center>Seoul, Korea</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=857">(857) More</a></td>
 <td align=center>edclxc005</td>
 <td align=center>USGS EROS/U.S. Forest Service</td>
 <td align=center>Opteron</td>
 <td align=center>34</td>
 <td align=center>2.00</td>
 <td align=center>136</td>
 <td align=center>Sioux Falls, SD, USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=856">(856) More</a></td>
 <td align=center>LevLab</td>
 <td align=center>JHU</td>
 <td align=center>EM64T</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>120</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=853">(853) More</a></td>
 <td align=center>Ptah</td>
 <td align=center>The University of Memphis, Dept. of Chemistry</td>
 <td align=center>Pentium 3</td>
 <td align=center>29</td>
 <td align=center>0.60</td>
 <td align=center>17.4</td>
 <td align=center>Memphis, TN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=852">(852) More</a></td>
 <td align=center>Sekhmet</td>
 <td align=center>The University of Memphis, Dept. of Chemistry</td>
 <td align=center>Pentium 4</td>
 <td align=center>39</td>
 <td align=center>3.00</td>
 <td align=center>234</td>
 <td align=center>Memphis, TN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=846">(846) More</a></td>
 <td align=center>ETmasterCA</td>
 <td align=center>Hydropoint Data Systems</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>2.80</td>
 <td align=center>358.4</td>
 <td align=center>Petaluma California</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=844">(844) More</a></td>
 <td align=center>UETCluster</td>
 <td align=center>University of Engineering and Technology, Taxila, Pakistan</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>Taxila</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=839">(839) More</a></td>
 <td align=center>Alindahaw</td>
 <td align=center>ASTI-DOST</td>
 <td align=center>Pentium 3</td>
 <td align=center>3</td>
 <td align=center>1.13</td>
 <td align=center>3.39</td>
 <td align=center>Quezon City, PHILIPPINES</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=838">(838) More</a></td>
 <td align=center>Longitude</td>
 <td align=center>Case Western Reserve University</td>
 <td align=center>Pentium 4</td>
 <td align=center>28</td>
 <td align=center>2.80</td>
 <td align=center>156.8</td>
 <td align=center>Cleveland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=835">(835) More</a></td>
 <td align=center>biodome</td>
 <td align=center>Eindhoven University of Technology</td>
 <td align=center>Opteron</td>
 <td align=center>48</td>
 <td align=center>1.60</td>
 <td align=center>153.6</td>
 <td align=center>Eindhoven, The Netherlands</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=834">(834) More</a></td>
 <td align=center>noise</td>
 <td align=center>Eindhoven University of Technology</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.40</td>
 <td align=center>307.2</td>
 <td align=center>Eindhoven, The Netherlands</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=832">(832) More</a></td>
 <td align=center>Ollin</td>
 <td align=center>ICN UNAM</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>Mexico</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=831">(831) More</a></td>
 <td align=center>Flash</td>
 <td align=center>University of Wisconsin-Madison</td>
 <td align=center>EM64T</td>
 <td align=center>36</td>
 <td align=center>3.00</td>
 <td align=center>216</td>
 <td align=center>Madison</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=830">(830) More</a></td>
 <td align=center>EMPIRE</td>
 <td align=center>University of Extremadura</td>
 <td align=center>Opteron</td>
 <td align=center>21</td>
 <td align=center>2.60</td>
 <td align=center>109.2</td>
 <td align=center>Cáceres (SPAIN)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=826">(826) More</a></td>
 <td align=center>Hydra-UAB</td>
 <td align=center>Universitat Autonoma de Barcelona</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>2.20</td>
 <td align=center>140.8</td>
 <td align=center>Barcelona</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=823">(823) More</a></td>
 <td align=center>klasszter</td>
 <td align=center>Department of Fluid Mechanics</td>
 <td align=center>Athlon 64</td>
 <td align=center>8</td>
 <td align=center>2.25</td>
 <td align=center>36</td>
 <td align=center>Budapest</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=821">(821) More</a></td>
 <td align=center>Melting</td>
 <td align=center>ICME @ Stanford</td>
 <td align=center>EM64T</td>
 <td align=center>96</td>
 <td align=center>3.40</td>
 <td align=center>652.8</td>
 <td align=center>Stanford</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=820">(820) More</a></td>
 <td align=center>TITANOSAUR</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Athlon 64</td>
 <td align=center>7</td>
 <td align=center>2.00</td>
 <td align=center>28</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=819">(819) More</a></td>
 <td align=center>UFlorida-PG</td>
 <td align=center>University of Florida</td>
 <td align=center>Opteron</td>
 <td align=center>240</td>
 <td align=center>2.20</td>
 <td align=center>1056</td>
 <td align=center>Gainesville, Florida</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=818">(818) More</a></td>
 <td align=center>UFlorida-IHEPA</td>
 <td align=center>University of Florida</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>2.20</td>
 <td align=center>352</td>
 <td align=center>Gainesville, Florida</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=816">(816) More</a></td>
 <td align=center>czar</td>
 <td align=center>Home Tests</td>
 <td align=center>Pentium 3</td>
 <td align=center>4</td>
 <td align=center>0.50</td>
 <td align=center>2</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=814">(814) More</a></td>
 <td align=center>ROX</td>
 <td align=center>Memorial University of Newfoundland</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.20</td>
 <td align=center>281.6</td>
 <td align=center>St. John`s, Canada</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=812">(812) More</a></td>
 <td align=center>Mercury</td>
 <td align=center>NACAD - COPPE/UFRJ</td>
 <td align=center>Pentium 3</td>
 <td align=center>16</td>
 <td align=center>1.00</td>
 <td align=center>16</td>
 <td align=center>Rio de Janeiro</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=811">(811) More</a></td>
 <td align=center>physcome</td>
 <td align=center>University of Freiburg</td>
 <td align=center>Opteron</td>
 <td align=center>28</td>
 <td align=center>1.80</td>
 <td align=center>100.8</td>
 <td align=center>Freiburg, Germany</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=807">(807) More</a></td>
 <td align=center>3TIER medusa</td>
 <td align=center>3TIER Environmental Forecast Group</td>
 <td align=center>Opteron</td>
 <td align=center>34</td>
 <td align=center>1.80</td>
 <td align=center>122.4</td>
 <td align=center>Seattle</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=805">(805) More</a></td>
 <td align=center>CCMP</td>
 <td align=center>SUT</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>2.20</td>
 <td align=center>140.8</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=801">(801) More</a></td>
 <td align=center>Parafisio</td>
 <td align=center>Parafisio/UFJF</td>
 <td align=center>Athlon 64</td>
 <td align=center>8</td>
 <td align=center>3.00</td>
 <td align=center>48</td>
 <td align=center>Juiz de Fora-MG/Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=798">(798) More</a></td>
 <td align=center>rescluster</td>
 <td align=center>Partners HealthCare</td>
 <td align=center>Opteron</td>
 <td align=center>30</td>
 <td align=center>1.40</td>
 <td align=center>84</td>
 <td align=center>Boston</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=794">(794) More</a></td>
 <td align=center>aec2-cluster</td>
 <td align=center>UdL</td>
 <td align=center>Pentium 4</td>
 <td align=center>7</td>
 <td align=center>1.80</td>
 <td align=center>25.2</td>
 <td align=center>LLeida</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=792">(792) More</a></td>
 <td align=center>Bee</td>
 <td align=center>Howard University</td>
 <td align=center>Opteron</td>
 <td align=center>56</td>
 <td align=center>2.60</td>
 <td align=center>291.2</td>
 <td align=center>Washington DC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=789">(789) More</a></td>
 <td align=center>URS Medusa</td>
 <td align=center>URS Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>250</td>
 <td align=center>3.00</td>
 <td align=center>1500</td>
 <td align=center>Gaithersburg, MD</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=783">(783) More</a></td>
 <td align=center>hpc</td>
 <td align=center>Istituto Nazionale di Geofisica e Vulcanologia sezione di Pisa</td>
 <td align=center>Opteron</td>
 <td align=center>94</td>
 <td align=center>2.40</td>
 <td align=center>451.2</td>
 <td align=center>Pisa - Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=780">(780) More</a></td>
 <td align=center>Ptpool</td>
 <td align=center>EPFL</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.00</td>
 <td align=center>256</td>
 <td align=center>Lausanne, Switzerland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=779">(779) More</a></td>
 <td align=center>Kristal Cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>1.70</td>
 <td align=center>435.2</td>
 <td align=center>Korea Daejeon</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=775">(775) More</a></td>
 <td align=center>Black Dragon</td>
 <td align=center>KSS</td>
 <td align=center>Opteron</td>
 <td align=center>14</td>
 <td align=center>2.20</td>
 <td align=center>61.6</td>
 <td align=center>Raunheim / Germany</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=774">(774) More</a></td>
 <td align=center>single</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>1.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=773">(773) More</a></td>
 <td align=center>media</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>1.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=771">(771) More</a></td>
 <td align=center>Catavinya</td>
 <td align=center>CICESE</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>1.75</td>
 <td align=center>280</td>
 <td align=center>Ensenada, B.C. Mexico</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=770">(770) More</a></td>
 <td align=center>nalottexpetly</td>
 <td align=center>nalottexpetly</td>
 <td align=center>Pentium 4</td>
 <td align=center>34</td>
 <td align=center>2.20</td>
 <td align=center>149.6</td>
 <td align=center>United States</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=769">(769) More</a></td>
 <td align=center>LDEO</td>
 <td align=center>Lamont-Doherty Earth Observatory</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>3.00</td>
 <td align=center>12</td>
 <td align=center>Palisades, New York</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=767">(767) More</a></td>
 <td align=center>wilmot</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>17</td>
 <td align=center>3.00</td>
 <td align=center>102</td>
 <td align=center>Kashiwa, Chiba</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=765">(765) More</a></td>
 <td align=center>typhoon2</td>
 <td align=center>Naval Research Laboratory</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>2.00</td>
 <td align=center>40</td>
 <td align=center>Monterey</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=764">(764) More</a></td>
 <td align=center>typhoon1</td>
 <td align=center>Naval Research Laboratory</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>2.00</td>
 <td align=center>40</td>
 <td align=center>Monterey</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=762">(762) More</a></td>
 <td align=center>itanium</td>
 <td align=center>National Electronics and Computer Technology Center</td>
 <td align=center>Itanium 2</td>
 <td align=center>64</td>
 <td align=center>1.40</td>
 <td align=center>358.4</td>
 <td align=center>Pathumthani, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=761">(761) More</a></td>
 <td align=center>IU School of Medicine (Biochemistry & Proteomics)</td>
 <td align=center>IU School of Medicine</td>
 <td align=center>Itanium</td>
 <td align=center>18</td>
 <td align=center>3.20</td>
 <td align=center>230.4</td>
 <td align=center>Indianapolis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=760">(760) More</a></td>
 <td align=center>datagrid1</td>
 <td align=center>University of Malaya</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>1.80</td>
 <td align=center>10.8</td>
 <td align=center>Kuala Lumpur</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=759">(759) More</a></td>
 <td align=center>ENQUEUE</td>
 <td align=center>KMITNB</td>
 <td align=center>Athlon MP</td>
 <td align=center>16</td>
 <td align=center>2.13</td>
 <td align=center>68.16</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=758">(758) More</a></td>
 <td align=center>albert</td>
 <td align=center>MechAssociates, LLC</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>Victoria, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=757">(757) More</a></td>
 <td align=center>SSOMBC</td>
 <td align=center>Loyola University Chicago Stritch School of Medicine</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>Chicago</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=756">(756) More</a></td>
 <td align=center>wipeout</td>
 <td align=center>Naval Postgraduate School</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>Monterey</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=755">(755) More</a></td>
 <td align=center>Puffin</td>
 <td align=center>Forsyth Technical Community College</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>3.40</td>
 <td align=center>108.8</td>
 <td align=center>Winston-Salem, NC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=754">(754) More</a></td>
 <td align=center>Titan (CENCAR)</td>
 <td align=center>Universidad de Guadalajara</td>
 <td align=center>Athlon 64</td>
 <td align=center>24</td>
 <td align=center>2.00</td>
 <td align=center>96</td>
 <td align=center>Guadalajara, Jalisco, Mexico</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=753">(753) More</a></td>
 <td align=center>cluster.physics.ewc.edu</td>
 <td align=center>Edward Waters College</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>3.40</td>
 <td align=center>81.6</td>
 <td align=center>1658 Kings Road, Jacksonville, FL 32209</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=752">(752) More</a></td>
 <td align=center>Medea</td>
 <td align=center>West Bohemia University</td>
 <td align=center>Pentium</td>
 <td align=center>2</td>
 <td align=center>0.45</td>
 <td align=center>0.9</td>
 <td align=center>Pilsen</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=750">(750) More</a></td>
 <td align=center>kyle</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Unspecified</td>
 <td align=center>50</td>
 <td align=center>1.20</td>
 <td align=center>60</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=747">(747) More</a></td>
 <td align=center>cluster FM</td>
 <td align=center>Technical University of Liberec</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>2.60</td>
 <td align=center>166.4</td>
 <td align=center>Liberec, Czech Republic</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=746">(746) More</a></td>
 <td align=center>Hua</td>
 <td align=center>Department of Civil Engineering National Ilan University</td>
 <td align=center>Pentium 4</td>
 <td align=center>24</td>
 <td align=center>3.40</td>
 <td align=center>163.2</td>
 <td align=center>Ilan, Taiwan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=745">(745) More</a></td>
 <td align=center>Adam</td>
 <td align=center>University of Houston, Department of Physics</td>
 <td align=center>Opteron</td>
 <td align=center>21</td>
 <td align=center>1.80</td>
 <td align=center>75.6</td>
 <td align=center>Houston, Tx</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=744">(744) More</a></td>
 <td align=center>Bagels CVA</td>
 <td align=center>Stanford University, Concurrent VLSI Architecture Group</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>2.20</td>
 <td align=center>352</td>
 <td align=center>Palo Alto, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=743">(743) More</a></td>
 <td align=center>Biocluster</td>
 <td align=center>Howard University</td>
 <td align=center>EM64T</td>
 <td align=center>14</td>
 <td align=center>3.20</td>
 <td align=center>89.6</td>
 <td align=center>Washginton DC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=740">(740) More</a></td>
 <td align=center>hpcmath</td>
 <td align=center>math kmutt</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>Bangkok Thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=739">(739) More</a></td>
 <td align=center>BUBBA</td>
 <td align=center>University of Nevada, Reno</td>
 <td align=center>Opteron</td>
 <td align=center>120</td>
 <td align=center>1.80</td>
 <td align=center>432</td>
 <td align=center>Reno</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=738">(738) More</a></td>
 <td align=center>Donkeykong</td>
 <td align=center>Villanova University</td>
 <td align=center>Other</td>
 <td align=center>11</td>
 <td align=center>2.80</td>
 <td align=center>30.8</td>
 <td align=center>Philadelphia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=736">(736) More</a></td>
 <td align=center>servidor</td>
 <td align=center>Escola Dr. Francisco Sanches</td>
 <td align=center>Pentium 3</td>
 <td align=center>4</td>
 <td align=center>0.87</td>
 <td align=center>3.48</td>
 <td align=center>Braga - Portugal</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=735">(735) More</a></td>
 <td align=center>marsrocks</td>
 <td align=center>UCLA</td>
 <td align=center>Pentium 3</td>
 <td align=center>10</td>
 <td align=center>1.30</td>
 <td align=center>13</td>
 <td align=center>Los Angeles</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=733">(733) More</a></td>
 <td align=center>Falcon</td>
 <td align=center>Physics Deptt., Jamia Millia Islamia (A central university)</td>
 <td align=center>Pentium 4</td>
 <td align=center>9</td>
 <td align=center>3.00</td>
 <td align=center>54</td>
 <td align=center>New Delhi, India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=732">(732) More</a></td>
 <td align=center>Caprock</td>
 <td align=center>H</td>
 <td align=center>Athlon 64</td>
 <td align=center>8</td>
 <td align=center>2.20</td>
 <td align=center>35.2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=731">(731) More</a></td>
 <td align=center>Atmosfera</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Other</td>
 <td align=center>3</td>
 <td align=center>2.53</td>
 <td align=center>7.59</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=730">(730) More</a></td>
 <td align=center>Kant</td>
 <td align=center>Dr Morales TTU Chem</td>
 <td align=center>Athlon</td>
 <td align=center>5</td>
 <td align=center>1.60</td>
 <td align=center>8</td>
 <td align=center>Lubbock, Texas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=729">(729) More</a></td>
 <td align=center>Ikelite</td>
 <td align=center>Calit2</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>3.20</td>
 <td align=center>409.6</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=727">(727) More</a></td>
 <td align=center>Aurora</td>
 <td align=center>Grid Computing Lab,</td>
 <td align=center>Pentium 4</td>
 <td align=center>34</td>
 <td align=center>1.40</td>
 <td align=center>95.2</td>
 <td align=center>Universiti Sains Malaysia (USM), Penang</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=726">(726) More</a></td>
 <td align=center>lilligrid</td>
 <td align=center>Istituto per le Applicazioni del Calcolo Mauro Picone CNR</td>
 <td align=center>Opteron</td>
 <td align=center>38</td>
 <td align=center>2.20</td>
 <td align=center>167.2</td>
 <td align=center>Napoli</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=725">(725) More</a></td>
 <td align=center>Mickeys first cluster</td>
 <td align=center>Mountain computer Company</td>
 <td align=center>Athlon 64</td>
 <td align=center>1</td>
 <td align=center>2.00</td>
 <td align=center>4</td>
 <td align=center>Germanton</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=723">(723) More</a></td>
 <td align=center>Photonics</td>
 <td align=center>Nano and Micro Devices Center, Univ. of Alabama in Huntsville</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.00</td>
 <td align=center>128</td>
 <td align=center>Huntsville, AL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=722">(722) More</a></td>
 <td align=center>c10</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=721">(721) More</a></td>
 <td align=center>c9</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.20</td>
 <td align=center>140.8</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=720">(720) More</a></td>
 <td align=center>sOfficklib</td>
 <td align=center>sOfficklib</td>
 <td align=center>Athlon</td>
 <td align=center>18</td>
 <td align=center>2.40</td>
 <td align=center>43.2</td>
 <td align=center>USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=719">(719) More</a></td>
 <td align=center>c7</td>
 <td align=center>TomoTherapy Incorporated</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=718">(718) More</a></td>
 <td align=center>pv-jet</td>
 <td align=center>Burnham Institute</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>SAn Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=717">(717) More</a></td>
 <td align=center>Hrothgar</td>
 <td align=center>Texas Tech University</td>
 <td align=center>EM64T</td>
 <td align=center>256</td>
 <td align=center>3.20</td>
 <td align=center>1638.4</td>
 <td align=center>Lubbock, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=716">(716) More</a></td>
 <td align=center>Zeus</td>
 <td align=center>Embry Riddle Aeronautical University</td>
 <td align=center>EM64T</td>
 <td align=center>512</td>
 <td align=center>3.20</td>
 <td align=center>3276.8</td>
 <td align=center>Daytona Beach, FL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=715">(715) More</a></td>
 <td align=center>c6</td>
 <td align=center>TomoTherapy Incoporated</td>
 <td align=center>Athlon MP</td>
 <td align=center>24</td>
 <td align=center>1.40</td>
 <td align=center>67.2</td>
 <td align=center>Madison, WI, USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=714">(714) More</a></td>
 <td align=center>Pingo</td>
 <td align=center>Risoe DTU</td>
 <td align=center>Pentium 4</td>
 <td align=center>24</td>
 <td align=center>2.80</td>
 <td align=center>134.4</td>
 <td align=center>Denmark, Roskilde</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=713">(713) More</a></td>
 <td align=center>NPGRID</td>
 <td align=center>Hadronic Nuclear Physics, Florida State University</td>
 <td align=center>Athlon MP</td>
 <td align=center>55</td>
 <td align=center>2.60</td>
 <td align=center>286</td>
 <td align=center>Tallahassee, Florida USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=711">(711) More</a></td>
 <td align=center>Hattoncluster66</td>
 <td align=center>MIT</td>
 <td align=center>EM64T</td>
 <td align=center>36</td>
 <td align=center>3.60</td>
 <td align=center>259.2</td>
 <td align=center>Cambridge</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=710">(710) More</a></td>
 <td align=center>goldorak</td>
 <td align=center>Quebec Bioinformatics Network</td>
 <td align=center>Athlon MP</td>
 <td align=center>24</td>
 <td align=center>2.40</td>
 <td align=center>115.2</td>
 <td align=center>Montreal, Qc</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=709">(709) More</a></td>
 <td align=center>TSC Thunder Strike</td>
 <td align=center>TSC Server Engineering</td>
 <td align=center>Opteron</td>
 <td align=center>40</td>
 <td align=center>2.40</td>
 <td align=center>192</td>
 <td align=center>Fletcher, OH</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=708">(708) More</a></td>
 <td align=center>newton</td>
 <td align=center>IIT</td>
 <td align=center>EM64T</td>
 <td align=center>14</td>
 <td align=center>3.00</td>
 <td align=center>84</td>
 <td align=center>Mumbai</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=707">(707) More</a></td>
 <td align=center>McKendree College Cluster</td>
 <td align=center>McKendree College CSI Dept</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>2.00</td>
 <td align=center>80</td>
 <td align=center>Lebanon, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=706">(706) More</a></td>
 <td align=center>diei092</td>
 <td align=center>udl</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.00</td>
 <td align=center>16</td>
 <td align=center>Lleida</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=705">(705) More</a></td>
 <td align=center>nano_cluster</td>
 <td align=center>ccmc-unam</td>
 <td align=center>Opteron</td>
 <td align=center>6</td>
 <td align=center>3.20</td>
 <td align=center>38.4</td>
 <td align=center>Ensenada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=704">(704) More</a></td>
 <td align=center>tortota</td>
 <td align=center>CIMAT</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>Guanajuato</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=703">(703) More</a></td>
 <td align=center>Hanks Beowulf Cluster</td>
 <td align=center>Hanks High School</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>1.70</td>
 <td align=center>17</td>
 <td align=center>El Paso, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=702">(702) More</a></td>
 <td align=center>Atmos</td>
 <td align=center>Malaysian Meteorological Department/Open Source Systems Sdn Bhd</td>
 <td align=center>Opteron</td>
 <td align=center>40</td>
 <td align=center>2.20</td>
 <td align=center>176</td>
 <td align=center>Petaling Jaya</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=701">(701) More</a></td>
 <td align=center>malibu</td>
 <td align=center>Dep. Quimica Fisica-Universitat de Valencia</td>
 <td align=center>Opteron</td>
 <td align=center>54</td>
 <td align=center>1.60</td>
 <td align=center>172.8</td>
 <td align=center>Burjassot (Valencia)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=700">(700) More</a></td>
 <td align=center>KTS Supercomptuer</td>
 <td align=center>Kowloon Technical School</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.00</td>
 <td align=center>96</td>
 <td align=center>Hong Kong</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=699">(699) More</a></td>
 <td align=center><a href="http://hpc.uio.no">TITAN III</a></td>
 <td align=center><a href="http://www.uio.no/english">University of Oslo</a></td>
 <td align=center>EM64T-4</td>
 <td align=center>4376</td>
 <td align=center>2.30</td>
 <td align=center>40259.2</td>
 <td align=center>Oslo, Norway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=698">(698) More</a></td>
 <td align=center>butterfly cluster</td>
 <td align=center>Valencia Community College</td>
 <td align=center>Pentium 4</td>
 <td align=center>9</td>
 <td align=center>2.00</td>
 <td align=center>36</td>
 <td align=center>Orlando</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=697">(697) More</a></td>
 <td align=center>Micro Machine II</td>
 <td align=center>GCD (Grup de Computacio Distribuïda)</td>
 <td align=center>Pentium 4</td>
 <td align=center>19</td>
 <td align=center>3.00</td>
 <td align=center>114</td>
 <td align=center>University of Lleida. Lleida (Spain)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=696">(696) More</a></td>
 <td align=center>yet01</td>
 <td align=center>University of Oriental Piedmont</td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>Alessandria - Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=695">(695) More</a></td>
 <td align=center>now01</td>
 <td align=center>University of Oriental Piedmon</td>
 <td align=center>Athlon</td>
 <td align=center>30</td>
 <td align=center>1.00</td>
 <td align=center>30</td>
 <td align=center>Alessandria - Italy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=694">(694) More</a></td>
 <td align=center>Try More(99)</td>
 <td align=center>sat</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>2.50</td>
 <td align=center>5</td>
 <td align=center>abcd</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=693">(693) More</a></td>
 <td align=center>archipelago</td>
 <td align=center>CCM - Centro de Ciências Matemáticas</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>3.00</td>
 <td align=center>72</td>
 <td align=center>Madeira Island, Portugal</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=691">(691) More</a></td>
 <td align=center>Bicho</td>
 <td align=center>Universidad Nacional de Educación a Distancia</td>
 <td align=center>EM64T</td>
 <td align=center>9</td>
 <td align=center>3.00</td>
 <td align=center>54</td>
 <td align=center>Madrid</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=690">(690) More</a></td>
 <td align=center>Atlantico</td>
 <td align=center>Grupo EDANYA. Universidad de Malaga</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>3.00</td>
 <td align=center>768</td>
 <td align=center>Malaga (Spain)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=689">(689) More</a></td>
 <td align=center>NIC Cluster</td>
 <td align=center>University of Missouri - Rolla</td>
 <td align=center>EM64T</td>
 <td align=center>80</td>
 <td align=center>3.20</td>
 <td align=center>512</td>
 <td align=center>Rolla</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=688">(688) More</a></td>
 <td align=center>nhnphu</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>4.00</td>
 <td align=center>8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=686">(686) More</a></td>
 <td align=center>Wapiti</td>
 <td align=center>University Of Calgary Biocomputing</td>
 <td align=center>EM64T</td>
 <td align=center>88</td>
 <td align=center>3.06</td>
 <td align=center>538.56</td>
 <td align=center>Calgary, Alberta Canada</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=685">(685) More</a></td>
 <td align=center>Tatanka</td>
 <td align=center>University Of Calgary Biocomputing</td>
 <td align=center>EM64T</td>
 <td align=center>624</td>
 <td align=center>3.40</td>
 <td align=center>4243.2</td>
 <td align=center>Calgary, Alberta Canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=683">(683) More</a></td>
 <td align=center>MyCluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>200</td>
 <td align=center>3.06</td>
 <td align=center>1224</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=682">(682) More</a></td>
 <td align=center>Crayfish</td>
 <td align=center>Louisiana State University</td>
 <td align=center>Pentium 4</td>
 <td align=center>160</td>
 <td align=center>3.06</td>
 <td align=center>979.2</td>
 <td align=center>Shreveport, Louisiana</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=681">(681) More</a></td>
 <td align=center>Doll</td>
 <td align=center>Cancer Epidemiology - Northwestern University</td>
 <td align=center>Opteron</td>
 <td align=center>20</td>
 <td align=center>2.40</td>
 <td align=center>96</td>
 <td align=center>Chicago</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=680">(680) More</a></td>
 <td align=center>flower.ccgb</td>
 <td align=center>Center for Computational Genomics and Bioinformatics</td>
 <td align=center>Pentium 3</td>
 <td align=center>14</td>
 <td align=center>1.40</td>
 <td align=center>19.6</td>
 <td align=center>Minneapolis, MN USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=679">(679) More</a></td>
 <td align=center>kudzu</td>
 <td align=center>Center for Computational Genomics and Bioinformatics</td>
 <td align=center>Pentium 4</td>
 <td align=center>30</td>
 <td align=center>2.80</td>
 <td align=center>168</td>
 <td align=center>Minneapolis, MN USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=678">(678) More</a></td>
 <td align=center>cirrus</td>
 <td align=center>CGUL</td>
 <td align=center>Pentium 4</td>
 <td align=center>9</td>
 <td align=center>3.20</td>
 <td align=center>57.6</td>
 <td align=center>Lisbon</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=677">(677) More</a></td>
 <td align=center>vortex</td>
 <td align=center>CGUL</td>
 <td align=center>Pentium 3</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>51.2</td>
 <td align=center>Lisbon</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=676">(676) More</a></td>
 <td align=center>NCEAS MicroCluster</td>
 <td align=center>NCEAS</td>
 <td align=center>Pentium 4</td>
 <td align=center>14</td>
 <td align=center>1.50</td>
 <td align=center>42</td>
 <td align=center>Santa Barbara</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=675">(675) More</a></td>
 <td align=center>mc-cc</td>
 <td align=center>Stanford University -ME</td>
 <td align=center>Pentium 4</td>
 <td align=center>92</td>
 <td align=center>3.00</td>
 <td align=center>552</td>
 <td align=center>Stanford</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=674">(674) More</a></td>
 <td align=center>regia</td>
 <td align=center>Washington University in St. Louis</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>St. Louis, Missouri</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=673">(673) More</a></td>
 <td align=center>zeus.ltfd.ufrj.br</td>
 <td align=center>LTFD/COPPE/UFRJ</td>
 <td align=center>Pentium 4</td>
 <td align=center>17</td>
 <td align=center>3.00</td>
 <td align=center>102</td>
 <td align=center>Rio de Janeiro, Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=672">(672) More</a></td>
 <td align=center>hera</td>
 <td align=center>LTFD/COPPE/UFRJ</td>
 <td align=center>Athlon XP</td>
 <td align=center>8</td>
 <td align=center>2.10</td>
 <td align=center>33.6</td>
 <td align=center>Rio de Janeiro, Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=671">(671) More</a></td>
 <td align=center>fusion</td>
 <td align=center>University of Kansas</td>
 <td align=center>EM64T</td>
 <td align=center>128</td>
 <td align=center>3.20</td>
 <td align=center>819.2</td>
 <td align=center>Lawrence</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=670">(670) More</a></td>
 <td align=center>marclus1</td>
 <td align=center>Marin</td>
 <td align=center>EM64T</td>
 <td align=center>4</td>
 <td align=center>3.20</td>
 <td align=center>25.6</td>
 <td align=center>Wagening, The Netherlands</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=669">(669) More</a></td>
 <td align=center>Earth-Cluster</td>
 <td align=center>PotashCorp</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>1.60</td>
 <td align=center>51.2</td>
 <td align=center>Saskatoon</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=668">(668) More</a></td>
 <td align=center>icbcluster2</td>
 <td align=center>ICB-CNR</td>
 <td align=center>Opteron</td>
 <td align=center>8</td>
 <td align=center>2.20</td>
 <td align=center>35.2</td>
 <td align=center>Pozzuoli (NA) - Italy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=667">(667) More</a></td>
 <td align=center>EOS</td>
 <td align=center>Team Gemini</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>2.80</td>
 <td align=center>33.6</td>
 <td align=center>Bradley University</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=666">(666) More</a></td>
 <td align=center>cluster_home</td>
 <td align=center>Burnash Computing Solutions</td>
 <td align=center>Pentium 3</td>
 <td align=center>7</td>
 <td align=center>0.93</td>
 <td align=center>6.51</td>
 <td align=center>Bernardsville, NJ</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=665">(665) More</a></td>
 <td align=center>odLZREIiVc</td>
 <td align=center>odLZREIiVc</td>
 <td align=center>Itanium</td>
 <td align=center>4</td>
 <td align=center>2.40</td>
 <td align=center>38.4</td>
 <td align=center>Menlo Park, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=664">(664) More</a></td>
 <td align=center>Tempest</td>
 <td align=center>Impa</td>
 <td align=center>Opteron</td>
 <td align=center>18</td>
 <td align=center>2.40</td>
 <td align=center>86.4</td>
 <td align=center>Rio de Janeiro</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=663">(663) More</a></td>
 <td align=center>TOROSAUR</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Opteron</td>
 <td align=center>7</td>
 <td align=center>3.40</td>
 <td align=center>47.6</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=662">(662) More</a></td>
 <td align=center>Computation</td>
 <td align=center>HPCC</td>
 <td align=center>Opteron</td>
 <td align=center>40</td>
 <td align=center>2.00</td>
 <td align=center>160</td>
 <td align=center>Ha Noi</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=661">(661) More</a></td>
 <td align=center>Cerberus</td>
 <td align=center>NCSU</td>
 <td align=center>EM64T</td>
 <td align=center>186</td>
 <td align=center>3.20</td>
 <td align=center>1190.4</td>
 <td align=center>Raleigh</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=660">(660) More</a></td>
 <td align=center>Tombstone</td>
 <td align=center>EDSC</td>
 <td align=center>Pentium 3</td>
 <td align=center>2</td>
 <td align=center>0.93</td>
 <td align=center>1.86</td>
 <td align=center>Meaux</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=659">(659) More</a></td>
 <td align=center>Nutzy</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 3</td>
 <td align=center>4</td>
 <td align=center>0.50</td>
 <td align=center>2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=658">(658) More</a></td>
 <td align=center>Coco</td>
 <td align=center>Centre des materiaux - Ecole des mines de Paris</td>
 <td align=center>Opteron</td>
 <td align=center>224</td>
 <td align=center>2.20</td>
 <td align=center>985.6</td>
 <td align=center>Evry - France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=657">(657) More</a></td>
 <td align=center>AIS GSM</td>
 <td align=center>NONSI</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>1.80</td>
 <td align=center>3.6</td>
 <td align=center>Bangkok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=656">(656) More</a></td>
 <td align=center>Basalt</td>
 <td align=center>Edith Cowan University</td>
 <td align=center>Athlon XP</td>
 <td align=center>45</td>
 <td align=center>1.80</td>
 <td align=center>162</td>
 <td align=center>Perth, Western Australia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=655">(655) More</a></td>
 <td align=center>Cluster Fisica</td>
 <td align=center>Instituto de Fisica, Universidad de Antioquia</td>
 <td align=center>Pentium 4</td>
 <td align=center>38</td>
 <td align=center>2.73</td>
 <td align=center>207.48</td>
 <td align=center>Medellin, Colombia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=654">(654) More</a></td>
 <td align=center>BRONTOSAURUS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>44</td>
 <td align=center>3.20</td>
 <td align=center>281.6</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=653">(653) More</a></td>
 <td align=center>Search</td>
 <td align=center>Universidade do Minho</td>
 <td align=center>EM64T</td>
 <td align=center>92</td>
 <td align=center>3.20</td>
 <td align=center>588.8</td>
 <td align=center>Portugal</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=652">(652) More</a></td>
 <td align=center>Athena_69</td>
 <td align=center>ACME</td>
 <td align=center>EM64T</td>
 <td align=center>969</td>
 <td align=center>3.40</td>
 <td align=center>6589.2</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=651">(651) More</a></td>
 <td align=center>latitude</td>
 <td align=center>CWRU</td>
 <td align=center>EM64T</td>
 <td align=center>14</td>
 <td align=center>3.00</td>
 <td align=center>84</td>
 <td align=center>Cleveland OH</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=650">(650) More</a></td>
 <td align=center>BRACHIOSAURUS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>3.00</td>
 <td align=center>192</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=649">(649) More</a></td>
 <td align=center>ANKYLOSAURUS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Athlon 64</td>
 <td align=center>32</td>
 <td align=center>3.00</td>
 <td align=center>192</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=648">(648) More</a></td>
 <td align=center>shredder</td>
 <td align=center>cm</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>2.40</td>
 <td align=center>14.4</td>
 <td align=center>cm</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=647">(647) More</a></td>
 <td align=center>Lummerland</td>
 <td align=center>UC Davis</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>3.00</td>
 <td align=center>6</td>
 <td align=center>Davis,CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=645">(645) More</a></td>
 <td align=center>Nick</td>
 <td align=center>USC College of Engineering and Information Technology</td>
 <td align=center>EM64T</td>
 <td align=center>152</td>
 <td align=center>3.40</td>
 <td align=center>1033.6</td>
 <td align=center>Columbia, SC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=644">(644) More</a></td>
 <td align=center>PitLab</td>
 <td align=center>Virginia Tech</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.80</td>
 <td align=center>22.4</td>
 <td align=center>Blacksburg</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=643">(643) More</a></td>
 <td align=center>redox</td>
 <td align=center>Stanford University</td>
 <td align=center>Opteron</td>
 <td align=center>34</td>
 <td align=center>2.00</td>
 <td align=center>136</td>
 <td align=center>Stanford</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=642">(642) More</a></td>
 <td align=center>Bonanza</td>
 <td align=center>University of Washington Chemistry</td>
 <td align=center>EM64T</td>
 <td align=center>422</td>
 <td align=center>3.40</td>
 <td align=center>2869.6</td>
 <td align=center>Seattle</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=641">(641) More</a></td>
 <td align=center>DreamTinyCluster</td>
 <td align=center>Dream Lab, UCI</td>
 <td align=center>Pentium 3</td>
 <td align=center>5</td>
 <td align=center>0.55</td>
 <td align=center>2.75</td>
 <td align=center>Irvine, California, U.S.</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=640">(640) More</a></td>
 <td align=center>grisu</td>
 <td align=center>Nuovo Pignone S.p.A.</td>
 <td align=center>Pentium 3</td>
 <td align=center>12</td>
 <td align=center>1.00</td>
 <td align=center>12</td>
 <td align=center>Firenze - Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=639">(639) More</a></td>
 <td align=center>Olympus</td>
 <td align=center>Univ. of Alabama at Birmingham - Computer & Information Sciences</td>
 <td align=center>EM64T</td>
 <td align=center>256</td>
 <td align=center>3.20</td>
 <td align=center>1638.4</td>
 <td align=center>Birmingham, AL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=638">(638) More</a></td>
 <td align=center>Peanut</td>
 <td align=center>Weber State University Computer Science Dept.</td>
 <td align=center>Pentium 3</td>
 <td align=center>16</td>
 <td align=center>1.80</td>
 <td align=center>28.8</td>
 <td align=center>Ogden UT 84408</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=637">(637) More</a></td>
 <td align=center>Titan Cluster</td>
 <td align=center>Dept. of Electronics Engineering of TEI of Athens</td>
 <td align=center>Pentium 4</td>
 <td align=center>19</td>
 <td align=center>3.00</td>
 <td align=center>114</td>
 <td align=center>Athens</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=636">(636) More</a></td>
 <td align=center>HPC PRI</td>
 <td align=center>KUM Institute Psychophysiology and Rehabilitation</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>3.14</td>
 <td align=center>18.84</td>
 <td align=center>Palanga, Lithuania</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=635">(635) More</a></td>
 <td align=center>VDUPDC</td>
 <td align=center>Vytautas Magnus University</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>2.94</td>
 <td align=center>29.4</td>
 <td align=center>Kaunas, Lithuania</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=634">(634) More</a></td>
 <td align=center>MEGALOSAURUS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>EM64T</td>
 <td align=center>9</td>
 <td align=center>3.00</td>
 <td align=center>54</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=633">(633) More</a></td>
 <td align=center>euler.tp1.rub.de</td>
 <td align=center>Institut für Theoretische Physik I</td>
 <td align=center>Opteron</td>
 <td align=center>64</td>
 <td align=center>2.40</td>
 <td align=center>307.2</td>
 <td align=center>Bochum, Germany</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=632">(632) More</a></td>
 <td align=center>Lynnwood Cluster</td>
 <td align=center>Geomatrix Consultants</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>2.40</td>
 <td align=center>115.2</td>
 <td align=center>Seattle</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=629">(629) More</a></td>
 <td align=center>vdw</td>
 <td align=center>University of Waterloo</td>
 <td align=center>Opteron</td>
 <td align=center>4</td>
 <td align=center>1.60</td>
 <td align=center>12.8</td>
 <td align=center>Waterloo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=628">(628) More</a></td>
 <td align=center>CCMP-FJNU</td>
 <td align=center>Fujian Normal University, P. R. China</td>
 <td align=center>Opteron</td>
 <td align=center>33</td>
 <td align=center>2.00</td>
 <td align=center>132</td>
 <td align=center>Fuzhou</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=627">(627) More</a></td>
 <td align=center>STYRACOSAURUS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Athlon 64</td>
 <td align=center>7</td>
 <td align=center>3.20</td>
 <td align=center>44.8</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=625">(625) More</a></td>
 <td align=center>icim</td>
 <td align=center>interdisciplinary Center for Immersive Media, Cal State East Bay</td>
 <td align=center>Pentium 3</td>
 <td align=center>5</td>
 <td align=center>0.60</td>
 <td align=center>3</td>
 <td align=center>Hayward,CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=624">(624) More</a></td>
 <td align=center>ABACUS</td>
 <td align=center>Artificial Evolution Group (GEA), Universidad de Extremadura</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.33</td>
 <td align=center>46.6</td>
 <td align=center>Mérida, Spain</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=623">(623) More</a></td>
 <td align=center>sums</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 3</td>
 <td align=center>134</td>
 <td align=center>1.00</td>
 <td align=center>134</td>
 <td align=center>Pasadena</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=622">(622) More</a></td>
 <td align=center>UOLHPC</td>
 <td align=center>University of Luton</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>2.80</td>
 <td align=center>358.4</td>
 <td align=center>Luton, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=621">(621) More</a></td>
 <td align=center>Azamat</td>
 <td align=center>National IT Center</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.80</td>
 <td align=center>22.4</td>
 <td align=center>Bishkek, Kyrgyzstan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=620">(620) More</a></td>
 <td align=center>Grendel-IME</td>
 <td align=center>IME</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>Rio de Janeiro</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=618">(618) More</a></td>
 <td align=center>pakiPoweR</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.20</td>
 <td align=center>25.6</td>
 <td align=center>Islamabad</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=617">(617) More</a></td>
 <td align=center>Gauss01</td>
 <td align=center>Seagate</td>
 <td align=center>EM64T</td>
 <td align=center>124</td>
 <td align=center>3.60</td>
 <td align=center>892.8</td>
 <td align=center>Bloomington, MN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=615">(615) More</a></td>
 <td align=center>juggling</td>
 <td align=center>Swartz Center for Computational Neuroscience, INC, UCSD</td>
 <td align=center>Opteron</td>
 <td align=center>72</td>
 <td align=center>2.40</td>
 <td align=center>345.6</td>
 <td align=center>La Jolla</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=614">(614) More</a></td>
 <td align=center>ALiCE</td>
 <td align=center>N/A</td>
 <td align=center>Pentium 3</td>
 <td align=center>128</td>
 <td align=center>0.50</td>
 <td align=center>64</td>
 <td align=center>London, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=613">(613) More</a></td>
 <td align=center>THEROPODS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Athlon 64</td>
 <td align=center>9</td>
 <td align=center>3.20</td>
 <td align=center>57.6</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=612">(612) More</a></td>
 <td align=center>CERATOSAURUS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.00</td>
 <td align=center>96</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=611">(611) More</a></td>
 <td align=center>TSC Tornado</td>
 <td align=center>Systemax Manufacturing</td>
 <td align=center>EM64T</td>
 <td align=center>40</td>
 <td align=center>3.40</td>
 <td align=center>272</td>
 <td align=center>Fletcher Ohio</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=610">(610) More</a></td>
 <td align=center>Anfinsen</td>
 <td align=center>Uppsala University</td>
 <td align=center>Opteron</td>
 <td align=center>125</td>
 <td align=center>2.00</td>
 <td align=center>500</td>
 <td align=center>Uppsala, Sweden</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=609">(609) More</a></td>
 <td align=center>Bioinfo</td>
 <td align=center>Cientistas Associados</td>
 <td align=center>Athlon 64</td>
 <td align=center>20</td>
 <td align=center>2.20</td>
 <td align=center>88</td>
 <td align=center>Sao Carlos- Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=608">(608) More</a></td>
 <td align=center>Candi</td>
 <td align=center>HPC</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>1.00</td>
 <td align=center>8</td>
 <td align=center>State College</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=607">(607) More</a></td>
 <td align=center>Unab Cluster</td>
 <td align=center>Universidad Autonoma de Bucaramanga</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>1.00</td>
 <td align=center>6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=606">(606) More</a></td>
 <td align=center>Precise-Rocks-5</td>
 <td align=center>Precise-ITC, inc.</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>Kanata (Ottawa), Ontario, Canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=605">(605) More</a></td>
 <td align=center>notus</td>
 <td align=center>Wichita State University</td>
 <td align=center>EM64T</td>
 <td align=center>92</td>
 <td align=center>3.60</td>
 <td align=center>662.4</td>
 <td align=center>Wichita, KS</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=604">(604) More</a></td>
 <td align=center>KTS PIII cluster</td>
 <td align=center>Kowloon Technical School</td>
 <td align=center>Pentium 3</td>
 <td align=center>4</td>
 <td align=center>1.30</td>
 <td align=center>5.2</td>
 <td align=center>Hong Kong</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=603">(603) More</a></td>
 <td align=center>obsidian</td>
 <td align=center>LSA, University of Michgan</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Ann Arbor</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=602">(602) More</a></td>
 <td align=center>Black Star</td>
 <td align=center>Rapture BioMedical Research</td>
 <td align=center>Pentium 2</td>
 <td align=center>5</td>
 <td align=center>1.60</td>
 <td align=center>8</td>
 <td align=center>Houston</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=601">(601) More</a></td>
 <td align=center>calving</td>
 <td align=center>ICME @ Stanford University</td>
 <td align=center>EM64T</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>120</td>
 <td align=center>Stanford</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=600">(600) More</a></td>
 <td align=center>Research Cluster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>EM64T</td>
 <td align=center>130</td>
 <td align=center>3.20</td>
 <td align=center>832</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=599">(599) More</a></td>
 <td align=center>Sepeli (Mgrid)</td>
 <td align=center>CSC - Scientific Computing Ltd.</td>
 <td align=center>Opteron</td>
 <td align=center>768</td>
 <td align=center>2.20</td>
 <td align=center>3379.2</td>
 <td align=center>Espoo, Finland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=598">(598) More</a></td>
 <td align=center>iwan</td>
 <td align=center>BRIDGE, University of Bristol</td>
 <td align=center>Opteron</td>
 <td align=center>80</td>
 <td align=center>2.50</td>
 <td align=center>400</td>
 <td align=center>Bristol</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=596">(596) More</a></td>
 <td align=center>LCCcluster</td>
 <td align=center>Laboratory of Computational Chemistry - UNS-VNU-HCMC</td>
 <td align=center>EM64T</td>
 <td align=center>20</td>
 <td align=center>2.40</td>
 <td align=center>96</td>
 <td align=center>HCMC -Vietnam</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=595">(595) More</a></td>
 <td align=center>Pandora</td>
 <td align=center>Physics Department, Texas Tech University</td>
 <td align=center>Opteron</td>
 <td align=center>22</td>
 <td align=center>2.20</td>
 <td align=center>96.8</td>
 <td align=center>Lubbock TX, USA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=594">(594) More</a></td>
 <td align=center>KTS cluster</td>
 <td align=center>Kowloon Technical School</td>
 <td align=center>Pentium 3</td>
 <td align=center>4</td>
 <td align=center>1.30</td>
 <td align=center>5.2</td>
 <td align=center>Hong Kong</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=592">(592) More</a></td>
 <td align=center>LCC of UNS-VNU</td>
 <td align=center>Laboratory of Computational Chemistry</td>
 <td align=center>Itanium 2</td>
 <td align=center>4</td>
 <td align=center>0.90</td>
 <td align=center>14.4</td>
 <td align=center>Hochiminh City</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=591">(591) More</a></td>
 <td align=center>PTERODACTYLUS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Athlon</td>
 <td align=center>7</td>
 <td align=center>1.80</td>
 <td align=center>12.6</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=590">(590) More</a></td>
 <td align=center>ALLOSAURUS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>3.20</td>
 <td align=center>409.6</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=589">(589) More</a></td>
 <td align=center>supernova_0</td>
 <td align=center>Franklin University</td>
 <td align=center>Pentium 3</td>
 <td align=center>6</td>
 <td align=center>0.60</td>
 <td align=center>3.6</td>
 <td align=center>Columbus, Ohio</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=587">(587) More</a></td>
 <td align=center>pruebas-1</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Athlon 64</td>
 <td align=center>160</td>
 <td align=center>2.00</td>
 <td align=center>640</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=586">(586) More</a></td>
 <td align=center>thylacine</td>
 <td align=center>jsdnet - private research</td>
 <td align=center>Pentium 2</td>
 <td align=center>16</td>
 <td align=center>0.20</td>
 <td align=center>3.2</td>
 <td align=center>Snowy NSW - Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=585">(585) More</a></td>
 <td align=center>fold</td>
 <td align=center>University Frankfurt Biophysical Chemistry</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>Frankfurt/ Main</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=584">(584) More</a></td>
 <td align=center>micro machine</td>
 <td align=center>GCD (Grup de Computació Distribuïda). Universitat de Lleida</td>
 <td align=center>Pentium 4</td>
 <td align=center>28</td>
 <td align=center>2.40</td>
 <td align=center>134.4</td>
 <td align=center>Lleida</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=583">(583) More</a></td>
 <td align=center>Geochemistry and Astrobiology Simulator</td>
 <td align=center>UCLA</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>3.20</td>
 <td align=center>76.8</td>
 <td align=center>Los Angeles</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=581">(581) More</a></td>
 <td align=center>orincon</td>
 <td align=center>Orincon Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>San Diego, CA USA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=580">(580) More</a></td>
 <td align=center>Gaggle</td>
 <td align=center>University of Stuttgart</td>
 <td align=center>Opteron</td>
 <td align=center>14</td>
 <td align=center>2.00</td>
 <td align=center>56</td>
 <td align=center>Stuttgart</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=579">(579) More</a></td>
 <td align=center>Pallas</td>
 <td align=center>IBMB, University of Wroclaw</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>67.2</td>
 <td align=center>Wroclaw, Poland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=578">(578) More</a></td>
 <td align=center>Lamsinh</td>
 <td align=center>admin of Mard</td>
 <td align=center>Athlon 64</td>
 <td align=center>25</td>
 <td align=center>1.80</td>
 <td align=center>90</td>
 <td align=center>Ha Noi, Viet Nam</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=577">(577) More</a></td>
 <td align=center>IBM TEST</td>
 <td align=center>TP.HCM</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.00</td>
 <td align=center>8</td>
 <td align=center>Viet Nam</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=575">(575) More</a></td>
 <td align=center>Cold vs.Hot</td>
 <td align=center>Cadpro</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>1.70</td>
 <td align=center>27.2</td>
 <td align=center>Ha Noi - Viet Nam</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=573">(573) More</a></td>
 <td align=center>Terminator</td>
 <td align=center>Huawei Vietnam</td>
 <td align=center>Pentium 4</td>
 <td align=center>18</td>
 <td align=center>2.20</td>
 <td align=center>79.2</td>
 <td align=center>Hanoi, Vietnam</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=572">(572) More</a></td>
 <td align=center>topaasi</td>
 <td align=center>University of Turku</td>
 <td align=center>Opteron</td>
 <td align=center>24</td>
 <td align=center>2.20</td>
 <td align=center>105.6</td>
 <td align=center>Turku, Finland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=571">(571) More</a></td>
 <td align=center>EMGS-rocks</td>
 <td align=center>EMGS</td>
 <td align=center>EM64T</td>
 <td align=center>1060</td>
 <td align=center>3.40</td>
 <td align=center>7208</td>
 <td align=center>Trondheim, Norway</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=570">(570) More</a></td>
 <td align=center>STEGOSAURUS (GRID)</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>3.20</td>
 <td align=center>204.8</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=569">(569) More</a></td>
 <td align=center>SEISMOSAURUS (GRID)</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>3.20</td>
 <td align=center>409.6</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=568">(568) More</a></td>
 <td align=center>Simpson</td>
 <td align=center>Florida International University</td>
 <td align=center>EM64T</td>
 <td align=center>68</td>
 <td align=center>3.60</td>
 <td align=center>489.6</td>
 <td align=center>Miami</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=567">(567) More</a></td>
 <td align=center>Grendel</td>
 <td align=center>Luther College</td>
 <td align=center>Pentium 3</td>
 <td align=center>14</td>
 <td align=center>0.75</td>
 <td align=center>10.5</td>
 <td align=center>Decorah, IA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=566">(566) More</a></td>
 <td align=center>akaatti (mgrid)</td>
 <td align=center>Tampere University of Technology</td>
 <td align=center>Opteron</td>
 <td align=center>96</td>
 <td align=center>2.20</td>
 <td align=center>422.4</td>
 <td align=center>Tampere, Finland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=565">(565) More</a></td>
 <td align=center>Spektroliitti</td>
 <td align=center>Lappeenranta University of Technology</td>
 <td align=center>Opteron</td>
 <td align=center>29</td>
 <td align=center>1.80</td>
 <td align=center>104.4</td>
 <td align=center>Lappeenranta, Finland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=564">(564) More</a></td>
 <td align=center>kvartsi (Mgrid)</td>
 <td align=center>Helsinki University of Technology</td>
 <td align=center>Opteron</td>
 <td align=center>192</td>
 <td align=center>2.30</td>
 <td align=center>883.2</td>
 <td align=center>Espoo, Finland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=563">(563) More</a></td>
 <td align=center>Obelix</td>
 <td align=center>Centre Robert Cedergren</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Montreal, Quebec, Canada</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=562">(562) More</a></td>
 <td align=center>Skylla</td>
 <td align=center>ClearSpeed</td>
 <td align=center>Athlon XP</td>
 <td align=center>4</td>
 <td align=center>1.80</td>
 <td align=center>14.4</td>
 <td align=center>Bristol, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=561">(561) More</a></td>
 <td align=center>luisbriones</td>
 <td align=center>ACSA</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.20</td>
 <td align=center>25.6</td>
 <td align=center>Santiago</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=560">(560) More</a></td>
 <td align=center>READ c0</td>
 <td align=center>READ ASA</td>
 <td align=center>EM64T</td>
 <td align=center>70</td>
 <td align=center>3.20</td>
 <td align=center>448</td>
 <td align=center>Oslo, Norway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=559">(559) More</a></td>
 <td align=center>MASTODON</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>3.20</td>
 <td align=center>76.8</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=558">(558) More</a></td>
 <td align=center>TROODON</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 3</td>
 <td align=center>9</td>
 <td align=center>1.80</td>
 <td align=center>16.2</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=557">(557) More</a></td>
 <td align=center>TRICERATOPS</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 3</td>
 <td align=center>3</td>
 <td align=center>1.70</td>
 <td align=center>5.1</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=556">(556) More</a></td>
 <td align=center>Rocky</td>
 <td align=center>Indiana University Chemistry Department</td>
 <td align=center>Pentium 3</td>
 <td align=center>20</td>
 <td align=center>0.67</td>
 <td align=center>13.4</td>
 <td align=center>Bloomington, IN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=555">(555) More</a></td>
 <td align=center>zero-cluster</td>
 <td align=center>Politecnico di Milano, Dipartimento di Meccanica</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>Milano, Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=554">(554) More</a></td>
 <td align=center>colato</td>
 <td align=center>Div. Colisiones Atómicas</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>3.00</td>
 <td align=center>30</td>
 <td align=center>S. C. de Bariloche, Argentina</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=553">(553) More</a></td>
 <td align=center>RockNRoll</td>
 <td align=center>National and Kapodistrian University of Athens</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>3.00</td>
 <td align=center>18</td>
 <td align=center>Athens</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=552">(552) More</a></td>
 <td align=center>MEGATERIO</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 3</td>
 <td align=center>12</td>
 <td align=center>1.70</td>
 <td align=center>20.4</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=551">(551) More</a></td>
 <td align=center>Hercules</td>
 <td align=center>Instituto de Fisica, Universidad de Antioquia</td>
 <td align=center>Pentium 4</td>
 <td align=center>26</td>
 <td align=center>2.40</td>
 <td align=center>124.8</td>
 <td align=center>Medellín - Antioquia, Colombia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=550">(550) More</a></td>
 <td align=center>ngc3200</td>
 <td align=center>CNR Istituto di Ricerche sulla Combustione</td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>Napoli</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=549">(549) More</a></td>
 <td align=center>argus.irb.hr</td>
 <td align=center>Institute Rudjer Boskovic</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>2.80</td>
 <td align=center>44.8</td>
 <td align=center>Zagreb, Croatia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=548">(548) More</a></td>
 <td align=center>KORG</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>3.20</td>
 <td align=center>51.2</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=547">(547) More</a></td>
 <td align=center>SMILODON</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>3.20</td>
 <td align=center>204.8</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=546">(546) More</a></td>
 <td align=center>VELOCIRAPTOR</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>3.20</td>
 <td align=center>409.6</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=545">(545) More</a></td>
 <td align=center>Taurus</td>
 <td align=center>Oak Ridge National Laboratory</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>2.00</td>
 <td align=center>128</td>
 <td align=center>Oak Ridge, TN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=544">(544) More</a></td>
 <td align=center>Wrangler</td>
 <td align=center>TACC</td>
 <td align=center>EM64T</td>
 <td align=center>256</td>
 <td align=center>3.20</td>
 <td align=center>1638.4</td>
 <td align=center>Austin, Texas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=543">(543) More</a></td>
 <td align=center>TSP</td>
 <td align=center>Institute of Physics</td>
 <td align=center>Athlon 64</td>
 <td align=center>5</td>
 <td align=center>1.80</td>
 <td align=center>18</td>
 <td align=center>Saigon, Vietnam</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=542">(542) More</a></td>
 <td align=center>T-REX</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>3.20</td>
 <td align=center>204.8</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=541">(541) More</a></td>
 <td align=center>G-REX</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Athlon MP</td>
 <td align=center>64</td>
 <td align=center>3.00</td>
 <td align=center>384</td>
 <td align=center>Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=540">(540) More</a></td>
 <td align=center>MAMMOTH</td>
 <td align=center>Mammoth Corporation</td>
 <td align=center>Athlon 64</td>
 <td align=center>16</td>
 <td align=center>3.00</td>
 <td align=center>96</td>
 <td align=center>Brazil</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=539">(539) More</a></td>
 <td align=center>Auger</td>
 <td align=center>Dept. of Chemistry, Casey Group University Nevada, Reno</td>
 <td align=center>Athlon 64</td>
 <td align=center>7</td>
 <td align=center>2.00</td>
 <td align=center>28</td>
 <td align=center>Reno</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=538">(538) More</a></td>
 <td align=center>Taos 1</td>
 <td align=center>Materials Design, Inc.</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>Taos, NM</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=537">(537) More</a></td>
 <td align=center>hydra.arnold.af.mil</td>
 <td align=center>ATA</td>
 <td align=center>Athlon MP</td>
 <td align=center>17</td>
 <td align=center>1.60</td>
 <td align=center>54.4</td>
 <td align=center>Arnold AFB, TN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=536">(536) More</a></td>
 <td align=center>davinci2</td>
 <td align=center>ATA</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>3.40</td>
 <td align=center>68</td>
 <td align=center>Arnold AFB, TN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=535">(535) More</a></td>
 <td align=center>SCEC Dynamic Cluster</td>
 <td align=center>Southern California Earthquake Center</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>University of Southern California (Los Angeles)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=534">(534) More</a></td>
 <td align=center>kisti</td>
 <td align=center>University of Michigan Atmospheric, Oceanic and Space Sciences</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=533">(533) More</a></td>
 <td align=center>phoomum</td>
 <td align=center>Personal</td>
 <td align=center>Athlon 64</td>
 <td align=center>2</td>
 <td align=center>2.20</td>
 <td align=center>8.8</td>
 <td align=center>Knoxville, TN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=532">(532) More</a></td>
 <td align=center>ChemClus</td>
 <td align=center>Department of Chemistry, University of Stellenbosch</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>67.2</td>
 <td align=center>Stellenbosch, South Africa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=531">(531) More</a></td>
 <td align=center>samdog</td>
 <td align=center>UT Southwestern Medical Center</td>
 <td align=center>Opteron</td>
 <td align=center>8</td>
 <td align=center>1.60</td>
 <td align=center>25.6</td>
 <td align=center>Dallas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=530">(530) More</a></td>
 <td align=center>thor</td>
 <td align=center>SAIC, CESS Group</td>
 <td align=center>Opteron</td>
 <td align=center>66</td>
 <td align=center>1.80</td>
 <td align=center>237.6</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=529">(529) More</a></td>
 <td align=center>CRSS</td>
 <td align=center>Center for Risk Studies and Safety, University of Santa Barbara</td>
 <td align=center>Pentium 4</td>
 <td align=center>28</td>
 <td align=center>3.06</td>
 <td align=center>171.36</td>
 <td align=center>Santa Barbara, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=528">(528) More</a></td>
 <td align=center>Dionysos</td>
 <td align=center>Bradley University Business Computer Systems Department</td>
 <td align=center>Pentium</td>
 <td align=center>5</td>
 <td align=center>0.80</td>
 <td align=center>4</td>
 <td align=center>Peoria, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=527">(527) More</a></td>
 <td align=center>Neuronic</td>
 <td align=center>University of Oregon Neuroinformatics Center</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Eugene, OR</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=526">(526) More</a></td>
 <td align=center>UMSGridProjects</td>
 <td align=center>Universiti Malaysia Sabah</td>
 <td align=center>Pentium 4</td>
 <td align=center>9</td>
 <td align=center>2.80</td>
 <td align=center>50.4</td>
 <td align=center>Kota Kinabalu, Sabah, MALAYSIA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=525">(525) More</a></td>
 <td align=center>Blue</td>
 <td align=center>Old Dominion University</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.00</td>
 <td align=center>48</td>
 <td align=center>Norfolk</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=524">(524) More</a></td>
 <td align=center>Dyna</td>
 <td align=center>Center for Applied Biomechanics</td>
 <td align=center>Pentium 4</td>
 <td align=center>7</td>
 <td align=center>2.00</td>
 <td align=center>28</td>
 <td align=center>Charlottesville, VA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=523">(523) More</a></td>
 <td align=center>ee-cluster</td>
 <td align=center>Aston University</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Birmingham, UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=522">(522) More</a></td>
 <td align=center>THUNDERGRID</td>
 <td align=center>NASA/Goddard Space Flight Center</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>2.20</td>
 <td align=center>88</td>
 <td align=center>Greenbelt, MD</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=520">(520) More</a></td>
 <td align=center>Cloudbase</td>
 <td align=center>University of Bath, TSaR Group</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>67.2</td>
 <td align=center>Bath, United Kingdom</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=519">(519) More</a></td>
 <td align=center>Badger Half Horsepower</td>
 <td align=center>University of Maryland</td>
 <td align=center>Pentium 3</td>
 <td align=center>4</td>
 <td align=center>0.70</td>
 <td align=center>2.8</td>
 <td align=center>College Park, Maryland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=518">(518) More</a></td>
 <td align=center>expedition</td>
 <td align=center>University of Missouri - St. Louis</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>3.06</td>
 <td align=center>783.36</td>
 <td align=center>St. Louis, MO</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=517">(517) More</a></td>
 <td align=center>Bose</td>
 <td align=center>Atomic and Laser Physics, University of Oxford</td>
 <td align=center>Pentium 4</td>
 <td align=center>26</td>
 <td align=center>2.40</td>
 <td align=center>124.8</td>
 <td align=center>Oxford</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=516">(516) More</a></td>
 <td align=center>HAHAHA</td>
 <td align=center>UB</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>120</td>
 <td align=center>Buffalo</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=515">(515) More</a></td>
 <td align=center>cares</td>
 <td align=center>Clarkson University</td>
 <td align=center>Pentium 4</td>
 <td align=center>60</td>
 <td align=center>2.80</td>
 <td align=center>336</td>
 <td align=center>Potsdam, NY</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=512">(512) More</a></td>
 <td align=center>Rohan</td>
 <td align=center>Georgia Tech College of Computing (Dell)</td>
 <td align=center>EM64T</td>
 <td align=center>128</td>
 <td align=center>3.20</td>
 <td align=center>819.2</td>
 <td align=center>Atlanta, Georgia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=511">(511) More</a></td>
 <td align=center>Euler</td>
 <td align=center>Georgia Tech Aerospace Engineering (Dell)</td>
 <td align=center>EM64T</td>
 <td align=center>256</td>
 <td align=center>3.20</td>
 <td align=center>1638.4</td>
 <td align=center>Atlanta, Georgia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=510">(510) More</a></td>
 <td align=center>Zohar</td>
 <td align=center>Georgia Tech Physics (Dell)</td>
 <td align=center>EM64T</td>
 <td align=center>512</td>
 <td align=center>3.20</td>
 <td align=center>3276.8</td>
 <td align=center>Atlanta, Georgia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=508">(508) More</a></td>
 <td align=center>CS-ROCKS</td>
 <td align=center>Dept. of Comp. Sci., Princeton University</td>
 <td align=center>Pentium 3</td>
 <td align=center>150</td>
 <td align=center>0.93</td>
 <td align=center>139.5</td>
 <td align=center>Princeton, NJ</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=506">(506) More</a></td>
 <td align=center>GP001</td>
 <td align=center>GRIDPLEXUS</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=505">(505) More</a></td>
 <td align=center>Zurichsehen</td>
 <td align=center>University of Zurich</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>3.20</td>
 <td align=center>204.8</td>
 <td align=center>Zurich, Switzerland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=504">(504) More</a></td>
 <td align=center>taniwha</td>
 <td align=center>ARC Centre of Excellence for Quantum-Atom Optics</td>
 <td align=center>EM64T</td>
 <td align=center>72</td>
 <td align=center>3.60</td>
 <td align=center>518.4</td>
 <td align=center>Brisbane</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=503">(503) More</a></td>
 <td align=center>TIFR - Belle</td>
 <td align=center>Tata Inistitute Of Fundamental Research</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.00</td>
 <td align=center>96</td>
 <td align=center>Mumbai (India)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=502">(502) More</a></td>
 <td align=center>Granite</td>
 <td align=center>University of California San Diego, Bioengineering</td>
 <td align=center>EM64T</td>
 <td align=center>210</td>
 <td align=center>3.20</td>
 <td align=center>1344</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=501">(501) More</a></td>
 <td align=center>vulcan</td>
 <td align=center>University of Florida - Department of Materials Science</td>
 <td align=center>Pentium 4</td>
 <td align=center>268</td>
 <td align=center>3.00</td>
 <td align=center>1608</td>
 <td align=center>Gainesville FL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=500">(500) More</a></td>
 <td align=center>Genesis961</td>
 <td align=center>Brigham and Womens Hospital</td>
 <td align=center>Opteron</td>
 <td align=center>2</td>
 <td align=center>2.80</td>
 <td align=center>11.2</td>
 <td align=center>Boston</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=499">(499) More</a></td>
 <td align=center>kryptonite</td>
 <td align=center>National Biomedical Computation Resource (UCSD)</td>
 <td align=center>EM64T</td>
 <td align=center>210</td>
 <td align=center>3.20</td>
 <td align=center>1344</td>
 <td align=center>San Diego, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=497">(497) More</a></td>
 <td align=center>Tungsten 2</td>
 <td align=center>NCSA</td>
 <td align=center>EM64T</td>
 <td align=center>1040</td>
 <td align=center>3.60</td>
 <td align=center>7488</td>
 <td align=center>Urbana, IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=496">(496) More</a></td>
 <td align=center>Orion</td>
 <td align=center>Seconda Università di Napoli</td>
 <td align=center>Pentium 4</td>
 <td align=center>18</td>
 <td align=center>2.40</td>
 <td align=center>86.4</td>
 <td align=center>Aversa, Italy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=495">(495) More</a></td>
 <td align=center>cygnus</td>
 <td align=center>Seconda Università di Napoli</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.00</td>
 <td align=center>8</td>
 <td align=center>Aversa, Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=494">(494) More</a></td>
 <td align=center>JMD</td>
 <td align=center>UBC - Physics and Astronomy</td>
 <td align=center>Opteron</td>
 <td align=center>68</td>
 <td align=center>2.20</td>
 <td align=center>299.2</td>
 <td align=center>Vancouver</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=493">(493) More</a></td>
 <td align=center>Systemax Super Cluster</td>
 <td align=center>Systemax Manufacturing</td>
 <td align=center>Athlon 64</td>
 <td align=center>200</td>
 <td align=center>2.40</td>
 <td align=center>960</td>
 <td align=center>Fletcher Ohio</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=492">(492) More</a></td>
 <td align=center>KLOCS</td>
 <td align=center>Kalypsys, Inc.</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=491">(491) More</a></td>
 <td align=center>Andor</td>
 <td align=center>The University of Kansas - Mathematics</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Lawrence, KS</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=489">(489) More</a></td>
 <td align=center>UVA Astronomy</td>
 <td align=center>UVA Astronomy Dept</td>
 <td align=center>Pentium 4</td>
 <td align=center>24</td>
 <td align=center>2.80</td>
 <td align=center>134.4</td>
 <td align=center>Charlottesville, VA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=488">(488) More</a></td>
 <td align=center>MIRTH Simulator</td>
 <td align=center>UCLA Dept. Earth and Space Sciences</td>
 <td align=center>Pentium 4</td>
 <td align=center>82</td>
 <td align=center>3.20</td>
 <td align=center>524.8</td>
 <td align=center>Los Angeles</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=487">(487) More</a></td>
 <td align=center>VIG1</td>
 <td align=center>Viglen</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>3.00</td>
 <td align=center>96</td>
 <td align=center>Alperton, London</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=486">(486) More</a></td>
 <td align=center>VIG0</td>
 <td align=center>Viglen</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Alperton, London</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=485">(485) More</a></td>
 <td align=center>LATTICE</td>
 <td align=center>Yonsei University</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Seoul, Korea</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=483">(483) More</a></td>
 <td align=center>Rising Star</td>
 <td align=center>High Energy Accelerator Research Organization</td>
 <td align=center>Pentium 4</td>
 <td align=center>53</td>
 <td align=center>2.80</td>
 <td align=center>296.8</td>
 <td align=center>Tsukuba-shi, Japan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=482">(482) More</a></td>
 <td align=center>Cycluster</td>
 <td align=center>Iowa State University</td>
 <td align=center>Pentium 2</td>
 <td align=center>24</td>
 <td align=center>0.45</td>
 <td align=center>10.8</td>
 <td align=center>Ames</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=481">(481) More</a></td>
 <td align=center>EhlersII</td>
 <td align=center>University of Michigan Geology</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.53</td>
 <td align=center>80.96</td>
 <td align=center>Ann Arbor, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=480">(480) More</a></td>
 <td align=center>Ehlers</td>
 <td align=center>University of Michigan Geology</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>1.80</td>
 <td align=center>115.2</td>
 <td align=center>Ann Arbor, MI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=479">(479) More</a></td>
 <td align=center>trans</td>
 <td align=center>University of Michigan Geology</td>
 <td align=center>Pentium 4</td>
 <td align=center>36</td>
 <td align=center>2.53</td>
 <td align=center>182.16</td>
 <td align=center>Ann Arbor, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=478">(478) More</a></td>
 <td align=center>mpcluster</td>
 <td align=center>Cross Cancer Institute</td>
 <td align=center>Opteron</td>
 <td align=center>22</td>
 <td align=center>2.00</td>
 <td align=center>88</td>
 <td align=center>Edmonton, Alberta</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=477">(477) More</a></td>
 <td align=center>janus</td>
 <td align=center>New Mexico State University</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>120</td>
 <td align=center>Las Cruces</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=476">(476) More</a></td>
 <td align=center>StanfordSFGF</td>
 <td align=center>Stanford School of Medicine</td>
 <td align=center>EM64T</td>
 <td align=center>48</td>
 <td align=center>3.00</td>
 <td align=center>288</td>
 <td align=center>Palo Alto</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=474">(474) More</a></td>
 <td align=center>strokes</td>
 <td align=center>University of Illinois at Chicago</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>3.06</td>
 <td align=center>195.84</td>
 <td align=center>Chicago</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=472">(472) More</a></td>
 <td align=center>MCSRGrid</td>
 <td align=center>MS Center for Supercomputing Research</td>
 <td align=center>Pentium 3</td>
 <td align=center>3</td>
 <td align=center>0.50</td>
 <td align=center>1.5</td>
 <td align=center>Oxford, Mississippi</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=471">(471) More</a></td>
 <td align=center>MCC Cluster</td>
 <td align=center>Materials Computation Center</td>
 <td align=center>Other</td>
 <td align=center>42</td>
 <td align=center>2.40</td>
 <td align=center>100.8</td>
 <td align=center>Urbana, IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=470">(470) More</a></td>
 <td align=center>hillo</td>
 <td align=center>VTT</td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>Finland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=468">(468) More</a></td>
 <td align=center>G29</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Opteron</td>
 <td align=center>3</td>
 <td align=center>1.70</td>
 <td align=center>10.2</td>
 <td align=center>Murray Hill, NJ</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=466">(466) More</a></td>
 <td align=center>MovesCluster</td>
 <td align=center>Naval Postgraduate School</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.40</td>
 <td align=center>48</td>
 <td align=center>Monterey</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=465">(465) More</a></td>
 <td align=center>GTMC</td>
 <td align=center>FaMAF, UNC</td>
 <td align=center>EM64T-4</td>
 <td align=center>20</td>
 <td align=center>2.50</td>
 <td align=center>200</td>
 <td align=center>cordoba, Argentina</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=463">(463) More</a></td>
 <td align=center>redback</td>
 <td align=center>Space Science and Engineering Center, UW-Madison</td>
 <td align=center>Opteron</td>
 <td align=center>20</td>
 <td align=center>2.20</td>
 <td align=center>88</td>
 <td align=center>Madison, Wisconsin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=462">(462) More</a></td>
 <td align=center>ShallowThought</td>
 <td align=center>Student</td>
 <td align=center>Pentium 3</td>
 <td align=center>3</td>
 <td align=center>0.50</td>
 <td align=center>1.5</td>
 <td align=center>Lubbock Texas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=461">(461) More</a></td>
 <td align=center>cluster</td>
 <td align=center>Arete Associates</td>
 <td align=center>EM64T</td>
 <td align=center>10</td>
 <td align=center>3.00</td>
 <td align=center>60</td>
 <td align=center>Sherman Oaks, California</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=460">(460) More</a></td>
 <td align=center>Matrix_NeuroengineeringUpenn</td>
 <td align=center>University of Pennsylvania</td>
 <td align=center>Pentium 4</td>
 <td align=center>26</td>
 <td align=center>2.80</td>
 <td align=center>145.6</td>
 <td align=center>Philadelphia, PA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=459">(459) More</a></td>
 <td align=center>matt</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=458">(458) More</a></td>
 <td align=center>logdog</td>
 <td align=center>MAISON</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>1.00</td>
 <td align=center>4</td>
 <td align=center>lucien</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=456">(456) More</a></td>
 <td align=center>cluster0</td>
 <td align=center>Dorian Research, Inc</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>2.40</td>
 <td align=center>24</td>
 <td align=center>Berkeley</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=455">(455) More</a></td>
 <td align=center>Mechanical Engineering Rocks</td>
 <td align=center>Mechanical Engineering, University of Alabama</td>
 <td align=center>EM64T</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>Tuscaloosa</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=454">(454) More</a></td>
 <td align=center>Olympus Mons</td>
 <td align=center>TIGEM</td>
 <td align=center>Pentium 4</td>
 <td align=center>68</td>
 <td align=center>3.00</td>
 <td align=center>408</td>
 <td align=center>Naples (Italy)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=453">(453) More</a></td>
 <td align=center>espresso</td>
 <td align=center>University of Puerto Rico</td>
 <td align=center>Pentium 4</td>
 <td align=center>172</td>
 <td align=center>2.40</td>
 <td align=center>825.6</td>
 <td align=center>San Juan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=452">(452) More</a></td>
 <td align=center>Seawulf</td>
 <td align=center>University of Toronto</td>
 <td align=center>Opteron</td>
 <td align=center>130</td>
 <td align=center>1.60</td>
 <td align=center>416</td>
 <td align=center>Toronto, ON</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=451">(451) More</a></td>
 <td align=center>crick</td>
 <td align=center>Universidade Católica de Brasília</td>
 <td align=center>Athlon XP</td>
 <td align=center>8</td>
 <td align=center>2.08</td>
 <td align=center>33.28</td>
 <td align=center>Brasília-DF-Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=450">(450) More</a></td>
 <td align=center>Interim Cluster</td>
 <td align=center>University Kansas ITTC</td>
 <td align=center>Pentium 3</td>
 <td align=center>12</td>
 <td align=center>0.80</td>
 <td align=center>9.6</td>
 <td align=center>Lawerence, Kansas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=449">(449) More</a></td>
 <td align=center>opaali</td>
 <td align=center>University of Jyväskylä</td>
 <td align=center>Opteron</td>
 <td align=center>26</td>
 <td align=center>1.80</td>
 <td align=center>93.6</td>
 <td align=center>Jyväskylä</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=448">(448) More</a></td>
 <td align=center>ametisti (M-grid)</td>
 <td align=center>University of Helsinki</td>
 <td align=center>Opteron</td>
 <td align=center>260</td>
 <td align=center>2.05</td>
 <td align=center>1066</td>
 <td align=center>Helsinki, Finland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=447">(447) More</a></td>
 <td align=center>icbcluster1</td>
 <td align=center>ICB-CNR</td>
 <td align=center>Athlon MP</td>
 <td align=center>4</td>
 <td align=center>1.66</td>
 <td align=center>13.28</td>
 <td align=center>Pozzuoli (NA), Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=445">(445) More</a></td>
 <td align=center>genesis.sega</td>
 <td align=center>None</td>
 <td align=center>Pentium 3</td>
 <td align=center>7</td>
 <td align=center>0.55</td>
 <td align=center>3.85</td>
 <td align=center>Reno, NV</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=444">(444) More</a></td>
 <td align=center>wcp</td>
 <td align=center>Westmont College</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Santa Barbara</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=443">(443) More</a></td>
 <td align=center>MiniCluster</td>
 <td align=center>NSWC, Crane Division</td>
 <td align=center>Pentium 3</td>
 <td align=center>12</td>
 <td align=center>1.00</td>
 <td align=center>12</td>
 <td align=center>Crane, IN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=442">(442) More</a></td>
 <td align=center>Clio</td>
 <td align=center>University of Cologne ZAIK/RRZK</td>
 <td align=center>Opteron</td>
 <td align=center>258</td>
 <td align=center>2.20</td>
 <td align=center>1135.2</td>
 <td align=center>Cologne, Germany</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=441">(441) More</a></td>
 <td align=center>Psiche</td>
 <td align=center>Chiron Vaccines</td>
 <td align=center>Pentium 4</td>
 <td align=center>113</td>
 <td align=center>2.80</td>
 <td align=center>632.8</td>
 <td align=center>Siena (Italy)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=440">(440) More</a></td>
 <td align=center>Lightning</td>
 <td align=center>University of Arizona</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.80</td>
 <td align=center>56</td>
 <td align=center>Tucson</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=439">(439) More</a></td>
 <td align=center>Vilkas</td>
 <td align=center>Vilnius Gediminas Technical University</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>Vilnius, Lithuania</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=438">(438) More</a></td>
 <td align=center>DoubleHelix</td>
 <td align=center>Massey University</td>
 <td align=center>Opteron</td>
 <td align=center>52</td>
 <td align=center>2.40</td>
 <td align=center>249.6</td>
 <td align=center>Albany Campus, Auckland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=437">(437) More</a></td>
 <td align=center>rock</td>
 <td align=center>EMGS</td>
 <td align=center>EM64T</td>
 <td align=center>80</td>
 <td align=center>3.06</td>
 <td align=center>489.6</td>
 <td align=center>Trondheim, Norway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=436">(436) More</a></td>
 <td align=center>Kivi (Mgrid)</td>
 <td align=center>CSC - Scientific Computing Ltd.</td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>2.20</td>
 <td align=center>52.8</td>
 <td align=center>Espoo, Finland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=435">(435) More</a></td>
 <td align=center>iacslc01</td>
 <td align=center>EPFL / SB / IACS</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>1.60</td>
 <td align=center>32</td>
 <td align=center>Lausanne, Switzerland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=434">(434) More</a></td>
 <td align=center>1425</td>
 <td align=center>Dell Inc.</td>
 <td align=center>EM64T</td>
 <td align=center>64</td>
 <td align=center>3.60</td>
 <td align=center>460.8</td>
 <td align=center>Austin, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=433">(433) More</a></td>
 <td align=center>1750</td>
 <td align=center>Dell Inc</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>3.20</td>
 <td align=center>819.2</td>
 <td align=center>Auxtin, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=432">(432) More</a></td>
 <td align=center>BioUzel</td>
 <td align=center>Stephen F Austin State University</td>
 <td align=center>Pentium 4</td>
 <td align=center>44</td>
 <td align=center>2.80</td>
 <td align=center>246.4</td>
 <td align=center>Nacogdoches</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=431">(431) More</a></td>
 <td align=center>TSC Supercomputer Cluster 2</td>
 <td align=center>Systemax TSC Server Engineering</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>Fletcher</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=430">(430) More</a></td>
 <td align=center>Hydra.esam.northwestern.edu</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>66</td>
 <td align=center>2.66</td>
 <td align=center>351.12</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=429">(429) More</a></td>
 <td align=center>lucio</td>
 <td align=center>ICCOM-CNR</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>3.40</td>
 <td align=center>54.4</td>
 <td align=center>Firenze (Italy)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=428">(428) More</a></td>
 <td align=center>The Giant Gila Monster Cluster</td>
 <td align=center>University of Arizona, ACMS</td>
 <td align=center>Opteron</td>
 <td align=center>62</td>
 <td align=center>2.20</td>
 <td align=center>272.8</td>
 <td align=center>Tucson, AZ</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=427">(427) More</a></td>
 <td align=center>Genomics cluster</td>
 <td align=center>CSE/Genomics UC Davis</td>
 <td align=center>Opteron</td>
 <td align=center>48</td>
 <td align=center>2.20</td>
 <td align=center>211.2</td>
 <td align=center>Davis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=426">(426) More</a></td>
 <td align=center>Amala</td>
 <td align=center>CSE/Geology UC Davis</td>
 <td align=center>Opteron</td>
 <td align=center>66</td>
 <td align=center>1.80</td>
 <td align=center>237.6</td>
 <td align=center>Davis</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=425">(425) More</a></td>
 <td align=center>Belle-KEK-Dell</td>
 <td align=center>High Energy Accelerator Research Organization</td>
 <td align=center>EM64T</td>
 <td align=center>300</td>
 <td align=center>3.40</td>
 <td align=center>2040</td>
 <td align=center>Tsukuba-shi, Japan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=424">(424) More</a></td>
 <td align=center>pendon</td>
 <td align=center>College of Engineering</td>
 <td align=center>EM64T</td>
 <td align=center>96</td>
 <td align=center>3.40</td>
 <td align=center>652.8</td>
 <td align=center>Univ. of Washington / Seattle, WA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=423">(423) More</a></td>
 <td align=center>cptcrunch</td>
 <td align=center>Lakehead University</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Thunder Bay</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=420">(420) More</a></td>
 <td align=center>gromada</td>
 <td align=center>Wroclaw Centre for Networking and Supercomputing</td>
 <td align=center>Itanium 2</td>
 <td align=center>66</td>
 <td align=center>1.40</td>
 <td align=center>369.6</td>
 <td align=center>Wroclaw, Poland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=419">(419) More</a></td>
 <td align=center>opie</td>
 <td align=center>Aerospace Testing Alliance</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>2.20</td>
 <td align=center>44</td>
 <td align=center>Arnold Air Force Base, TN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=418">(418) More</a></td>
 <td align=center>renoir</td>
 <td align=center>Aerospace Testing Alliance</td>
 <td align=center>Pentium 4</td>
 <td align=center>18</td>
 <td align=center>2.20</td>
 <td align=center>79.2</td>
 <td align=center>Arnold AFB, TN</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=417">(417) More</a></td>
 <td align=center>behemoth</td>
 <td align=center>IECB</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Bordeaux, France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=414">(414) More</a></td>
 <td align=center>superchode</td>
 <td align=center>codefactory.org</td>
 <td align=center>Pentium 3</td>
 <td align=center>18</td>
 <td align=center>0.66</td>
 <td align=center>11.88</td>
 <td align=center>Sheffield, UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=413">(413) More</a></td>
 <td align=center>GMPS</td>
 <td align=center>ISS</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.40</td>
 <td align=center>19.2</td>
 <td align=center>Bucharest, Romania</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=411">(411) More</a></td>
 <td align=center>octet</td>
 <td align=center>U. S. Naval Research Laboratory</td>
 <td align=center>Athlon MP</td>
 <td align=center>16</td>
 <td align=center>1.80</td>
 <td align=center>57.6</td>
 <td align=center>Washington, DC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=409">(409) More</a></td>
 <td align=center>Argus</td>
 <td align=center>Northwestern University</td>
 <td align=center>Pentium 3</td>
 <td align=center>12</td>
 <td align=center>1.00</td>
 <td align=center>12</td>
 <td align=center>Evanston, Illinois</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=407">(407) More</a></td>
 <td align=center>Armoury</td>
 <td align=center>Telstra Research Laboratories</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.80</td>
 <td align=center>44.8</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=404">(404) More</a></td>
 <td align=center>Sean's Cluster</td>
 <td align=center>Personal</td>
 <td align=center>Athlon XP</td>
 <td align=center>2</td>
 <td align=center>1.40</td>
 <td align=center>5.6</td>
 <td align=center>Rotonda, FL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=403">(403) More</a></td>
 <td align=center>medusa</td>
 <td align=center>Dept. of Computer Science, Oslo University College</td>
 <td align=center>Pentium 4</td>
 <td align=center>15</td>
 <td align=center>3.00</td>
 <td align=center>90</td>
 <td align=center>Oslo, Norway</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=402">(402) More</a></td>
 <td align=center>TWG #1</td>
 <td align=center>TWG Engineering</td>
 <td align=center>Athlon</td>
 <td align=center>4</td>
 <td align=center>2.00</td>
 <td align=center>8</td>
 <td align=center>Indianapolis, IN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=401">(401) More</a></td>
 <td align=center>Grape</td>
 <td align=center>Urumqi Observatory, NAO-CAS</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>Urumqi, P. R. China</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=399">(399) More</a></td>
 <td align=center>odin</td>
 <td align=center>Washington State University</td>
 <td align=center>Athlon MP</td>
 <td align=center>22</td>
 <td align=center>1.67</td>
 <td align=center>73.48</td>
 <td align=center>Pullman, WA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=395">(395) More</a></td>
 <td align=center>Oceano</td>
 <td align=center>Institute Oceanography, University Lisbon</td>
 <td align=center>Opteron</td>
 <td align=center>8</td>
 <td align=center>2.40</td>
 <td align=center>38.4</td>
 <td align=center>Lisboa, Portugal</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=394">(394) More</a></td>
 <td align=center>assegai</td>
 <td align=center>University Of Kwazulu-Natal</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>Durban</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=392">(392) More</a></td>
 <td align=center>Muskrat</td>
 <td align=center>ASU Computer Science Department</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>0.93</td>
 <td align=center>18.6</td>
 <td align=center>Jonesboro, AR</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=391">(391) More</a></td>
 <td align=center>Zeus Cluster</td>
 <td align=center>Northwestern University, Mechanical Engineering, TAM group</td>
 <td align=center>Athlon MP</td>
 <td align=center>32</td>
 <td align=center>1.40</td>
 <td align=center>89.6</td>
 <td align=center>Evanston, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=390">(390) More</a></td>
 <td align=center>TRLabs Rocks</td>
 <td align=center>TRLabs</td>
 <td align=center>Other</td>
 <td align=center>10</td>
 <td align=center>2.40</td>
 <td align=center>24</td>
 <td align=center>Winnipeg, Manitoba, Canada</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=389">(389) More</a></td>
 <td align=center>CLVT</td>
 <td align=center>CINES</td>
 <td align=center>Opteron</td>
 <td align=center>44</td>
 <td align=center>1.80</td>
 <td align=center>158.4</td>
 <td align=center>Montpellier</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=388">(388) More</a></td>
 <td align=center>Monster2</td>
 <td align=center>Polymer Phyics, University of Bristol</td>
 <td align=center>Athlon XP</td>
 <td align=center>21</td>
 <td align=center>2.20</td>
 <td align=center>92.4</td>
 <td align=center>Bristol</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=385">(385) More</a></td>
 <td align=center>Espinosa</td>
 <td align=center>Northwestern University Mechanical Engineering Department</td>
 <td align=center>Pentium 4</td>
 <td align=center>23</td>
 <td align=center>3.00</td>
 <td align=center>138</td>
 <td align=center>Evanston, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=384">(384) More</a></td>
 <td align=center>return</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Athlon</td>
 <td align=center>1</td>
 <td align=center>2.40</td>
 <td align=center>2.4</td>
 <td align=center>hk</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=382">(382) More</a></td>
 <td align=center>PAUILLAC</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>EVRY (FRANCE)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=381">(381) More</a></td>
 <td align=center>Neuroimaging Lab - University of Florida</td>
 <td align=center>University of Florida/VA Medical Center</td>
 <td align=center>Opteron</td>
 <td align=center>18</td>
 <td align=center>1.80</td>
 <td align=center>64.8</td>
 <td align=center>Gainesville, FL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=380">(380) More</a></td>
 <td align=center>susquehanna</td>
 <td align=center>university of illinois at urbana-champaign</td>
 <td align=center>EM64T</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>champaign</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=378">(378) More</a></td>
 <td align=center>BoccaLupo</td>
 <td align=center>University of Arizona, Dept Geosciences</td>
 <td align=center>Pentium 4</td>
 <td align=center>40</td>
 <td align=center>3.00</td>
 <td align=center>240</td>
 <td align=center>Tucson</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=377">(377) More</a></td>
 <td align=center>Marvin</td>
 <td align=center>University of Leicester</td>
 <td align=center>Opteron</td>
 <td align=center>9</td>
 <td align=center>1.80</td>
 <td align=center>32.4</td>
 <td align=center>Leicester, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=376">(376) More</a></td>
 <td align=center>WSU Campus Grid</td>
 <td align=center>Wayne State University</td>
 <td align=center>Pentium 4</td>
 <td align=center>1054</td>
 <td align=center>2.50</td>
 <td align=center>5270</td>
 <td align=center>Detroit Michigan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=375">(375) More</a></td>
 <td align=center>Fimm</td>
 <td align=center>Bergen Center for Computational Science</td>
 <td align=center>Opteron</td>
 <td align=center>178</td>
 <td align=center>2.40</td>
 <td align=center>854.4</td>
 <td align=center>Bergen, Norway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=372">(372) More</a></td>
 <td align=center>dalecluster</td>
 <td align=center>University of California, San Diego</td>
 <td align=center>Pentium 4</td>
 <td align=center>70</td>
 <td align=center>3.00</td>
 <td align=center>420</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=370">(370) More</a></td>
 <td align=center>GFunk</td>
 <td align=center>ICME @ Stanford University</td>
 <td align=center>Pentium 4</td>
 <td align=center>164</td>
 <td align=center>2.66</td>
 <td align=center>872.48</td>
 <td align=center>Stanford, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=369">(369) More</a></td>
 <td align=center>Regelation</td>
 <td align=center>ICME @ Stanford University</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>3.06</td>
 <td align=center>48.96</td>
 <td align=center>Stanford, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=368">(368) More</a></td>
 <td align=center>Sintering</td>
 <td align=center>ICME @ Stanford University</td>
 <td align=center>Opteron</td>
 <td align=center>48</td>
 <td align=center>1.60</td>
 <td align=center>153.6</td>
 <td align=center>Stanford, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=367">(367) More</a></td>
 <td align=center>Firn</td>
 <td align=center>ICME @ Stanford University</td>
 <td align=center>Pentium 3</td>
 <td align=center>112</td>
 <td align=center>1.00</td>
 <td align=center>112</td>
 <td align=center>Stanford, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=366">(366) More</a></td>
 <td align=center>JSUHPC</td>
 <td align=center>Jacksonville State University</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>3.20</td>
 <td align=center>102.4</td>
 <td align=center>Jacksonville, AL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=364">(364) More</a></td>
 <td align=center>quimicas1</td>
 <td align=center>Universidad Nacional de Cordoba - Facultad de Ciencias Quimicas</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>0.93</td>
 <td align=center>7.44</td>
 <td align=center>Argentina</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=361">(361) More</a></td>
 <td align=center>Lihue</td>
 <td align=center>Berkeley Phylogenomics Group</td>
 <td align=center>Pentium 4</td>
 <td align=center>46</td>
 <td align=center>1.80</td>
 <td align=center>165.6</td>
 <td align=center>Berkeley</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=360">(360) More</a></td>
 <td align=center>Neper</td>
 <td align=center>unieuro</td>
 <td align=center>Itanium 2</td>
 <td align=center>8</td>
 <td align=center>0.90</td>
 <td align=center>28.8</td>
 <td align=center>Brasilia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=359">(359) More</a></td>
 <td align=center>BAMA</td>
 <td align=center>University of Alabama</td>
 <td align=center>Athlon</td>
 <td align=center>24</td>
 <td align=center>1.40</td>
 <td align=center>33.6</td>
 <td align=center>Tuscaloosa</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=358">(358) More</a></td>
 <td align=center>Fishtracker</td>
 <td align=center>University of Puerto Rico Mayaguez Campus</td>
 <td align=center>Opteron</td>
 <td align=center>8</td>
 <td align=center>1.40</td>
 <td align=center>22.4</td>
 <td align=center>Mayaguez, Puerto Rico</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=355">(355) More</a></td>
 <td align=center>SVG DELL</td>
 <td align=center>CESGA</td>
 <td align=center>Pentium 4</td>
 <td align=center>80</td>
 <td align=center>3.20</td>
 <td align=center>512</td>
 <td align=center>Santiago de Compostela - Galicia - SPAIN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=354">(354) More</a></td>
 <td align=center>Jaspis Cluster (Mgrid)</td>
 <td align=center>Helsinki Institute of Physics</td>
 <td align=center>Opteron</td>
 <td align=center>19</td>
 <td align=center>1.80</td>
 <td align=center>68.4</td>
 <td align=center>Espoo, Finland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=352">(352) More</a></td>
 <td align=center>IO/USP LabMon Cluster</td>
 <td align=center>University of Sao Paulo / IO</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>1.60</td>
 <td align=center>32</td>
 <td align=center>Sao Paulo</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=351">(351) More</a></td>
 <td align=center>Parrillada completa</td>
 <td align=center>Departement Theory and Computer Simulation</td>
 <td align=center>EM64T</td>
 <td align=center>92</td>
 <td align=center>2.80</td>
 <td align=center>515.2</td>
 <td align=center>Marseille (France)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=350">(350) More</a></td>
 <td align=center>TreeLab Hydra</td>
 <td align=center>Universite de Sherbrooke</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Sherbrooke Quebec</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=349">(349) More</a></td>
 <td align=center>karan</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Athlon MP</td>
 <td align=center>450</td>
 <td align=center>2.40</td>
 <td align=center>2160</td>
 <td align=center>san diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=347">(347) More</a></td>
 <td align=center>Opal</td>
 <td align=center>OptIPuter</td>
 <td align=center>Opteron</td>
 <td align=center>34</td>
 <td align=center>1.60</td>
 <td align=center>108.8</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=345">(345) More</a></td>
 <td align=center>Montague</td>
 <td align=center>CSIRO Petroleum</td>
 <td align=center>Pentium 4</td>
 <td align=center>11</td>
 <td align=center>3.20</td>
 <td align=center>70.4</td>
 <td align=center>Melbourne, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=344">(344) More</a></td>
 <td align=center>Hydro Hydra</td>
 <td align=center>University of Washington Hydrology Gruop</td>
 <td align=center>Pentium 4</td>
 <td align=center>14</td>
 <td align=center>2.80</td>
 <td align=center>78.4</td>
 <td align=center>Seattle</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=340">(340) More</a></td>
 <td align=center>Dolphin</td>
 <td align=center>PSERC, Cornell</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>3.20</td>
 <td align=center>76.8</td>
 <td align=center>Ithaca</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=339">(339) More</a></td>
 <td align=center>CHEPREO FIU Cluster</td>
 <td align=center>Florida International University</td>
 <td align=center>Pentium 4</td>
 <td align=center>42</td>
 <td align=center>2.67</td>
 <td align=center>224.28</td>
 <td align=center>Miami</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=337">(337) More</a></td>
 <td align=center>UAI Rocks Cluster</td>
 <td align=center>UAI, Inc.</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>2.40</td>
 <td align=center>14.4</td>
 <td align=center>Huntsville, AL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=335">(335) More</a></td>
 <td align=center>Undergrad Lab Cluster</td>
 <td align=center>University of Toronto, Dept. of Chemistry</td>
 <td align=center>Athlon XP</td>
 <td align=center>22</td>
 <td align=center>2.10</td>
 <td align=center>92.4</td>
 <td align=center>Toronto</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=333">(333) More</a></td>
 <td align=center>clues</td>
 <td align=center>INFM</td>
 <td align=center>Athlon MP</td>
 <td align=center>198</td>
 <td align=center>2.13</td>
 <td align=center>843.48</td>
 <td align=center>Naples, Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=330">(330) More</a></td>
 <td align=center>Smithsonian Hydra</td>
 <td align=center>Smithsonian Institution</td>
 <td align=center>Opteron</td>
 <td align=center>1800</td>
 <td align=center>2.30</td>
 <td align=center>8280</td>
 <td align=center>Herndon, VA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=329">(329) More</a></td>
 <td align=center>Chempossible</td>
 <td align=center>National Biomedical Computational Resource</td>
 <td align=center>Pentium 4</td>
 <td align=center>42</td>
 <td align=center>2.80</td>
 <td align=center>235.2</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=327">(327) More</a></td>
 <td align=center>Clustis</td>
 <td align=center>NTNU</td>
 <td align=center>Pentium 4</td>
 <td align=center>22</td>
 <td align=center>3.40</td>
 <td align=center>149.6</td>
 <td align=center>Trondheim</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=326">(326) More</a></td>
 <td align=center>Alborz</td>
 <td align=center>San Diego State University</td>
 <td align=center>EM64T-4</td>
 <td align=center>70</td>
 <td align=center>2.00</td>
 <td align=center>560</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=325">(325) More</a></td>
 <td align=center>ATOMS</td>
 <td align=center>Aerodynamic Research Center, UTA</td>
 <td align=center>Pentium 3</td>
 <td align=center>2</td>
 <td align=center>0.50</td>
 <td align=center>1</td>
 <td align=center>Arlington</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=322">(322) More</a></td>
 <td align=center>Baraddur</td>
 <td align=center>Dept. of Physics, KAIST</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Daejeon, Republic of Korea</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=321">(321) More</a></td>
 <td align=center>Arjun</td>
 <td align=center>Indiana Centers for Applied Protein Science</td>
 <td align=center>Pentium 4</td>
 <td align=center>116</td>
 <td align=center>3.20</td>
 <td align=center>742.4</td>
 <td align=center>Indianapolis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=319">(319) More</a></td>
 <td align=center>Auxilium Cluster</td>
 <td align=center>Auxilium Software Development</td>
 <td align=center>Pentium 4</td>
 <td align=center>2</td>
 <td align=center>1.80</td>
 <td align=center>7.2</td>
 <td align=center>Delft</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=315">(315) More</a></td>
 <td align=center>ROCKBIT</td>
 <td align=center>Baird Petrophysical International, Inc.</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.80</td>
 <td align=center>22.4</td>
 <td align=center>Houston, Texas U.S.A.</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=314">(314) More</a></td>
 <td align=center>ROCKPOR</td>
 <td align=center>Baird Petrophysical International, Inc.</td>
 <td align=center>Athlon XP</td>
 <td align=center>8</td>
 <td align=center>2.00</td>
 <td align=center>32</td>
 <td align=center>Houston, Texas U.S.A.</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=313">(313) More</a></td>
 <td align=center>MOVES</td>
 <td align=center>MOVES institute</td>
 <td align=center>Pentium 3</td>
 <td align=center>6</td>
 <td align=center>0.50</td>
 <td align=center>3</td>
 <td align=center>Monterey, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=310">(310) More</a></td>
 <td align=center>Scalar_UIS</td>
 <td align=center>SCALAR Servicio de Computo de Alto Rendimiento</td>
 <td align=center>Pentium 2</td>
 <td align=center>10</td>
 <td align=center>0.35</td>
 <td align=center>3.5</td>
 <td align=center>Bucaramanga, Colombia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=309">(309) More</a></td>
 <td align=center>THORIUM</td>
 <td align=center>Computationa Chemistry, Venezuelan Research Institute</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>120</td>
 <td align=center>Caracas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=306">(306) More</a></td>
 <td align=center>Aspen</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>2.80</td>
 <td align=center>33.6</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=305">(305) More</a></td>
 <td align=center>Themis Cluster</td>
 <td align=center>IUPUI</td>
 <td align=center>Pentium 3</td>
 <td align=center>9</td>
 <td align=center>1.33</td>
 <td align=center>11.97</td>
 <td align=center>Indianapolis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=304">(304) More</a></td>
 <td align=center>Altosys01</td>
 <td align=center>Altosys Software Technologies Ltd.</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>1.80</td>
 <td align=center>57.6</td>
 <td align=center>Chennai, India</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=302">(302) More</a></td>
 <td align=center>TUXs</td>
 <td align=center>HPC Project, System Support Dept, Technology Supply Co., Ltd.</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.53</td>
 <td align=center>20.24</td>
 <td align=center>Seri Center, Bangkok, Thailand.</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=301">(301) More</a></td>
 <td align=center>Nivation</td>
 <td align=center>ICME @ Stanford University</td>
 <td align=center>Pentium 4</td>
 <td align=center>172</td>
 <td align=center>3.06</td>
 <td align=center>1052.64</td>
 <td align=center>Palo Alto, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=299">(299) More</a></td>
 <td align=center>USCMS Fermilab Tier1</td>
 <td align=center>Fermi National Accelerator Lab</td>
 <td align=center>EM64T-4</td>
 <td align=center>7600</td>
 <td align=center>2.66</td>
 <td align=center>80864</td>
 <td align=center>Batavia,IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=298">(298) More</a></td>
 <td align=center>UC SanDiegoPG</td>
 <td align=center>UCSD High Energy Physics</td>
 <td align=center>Pentium 4</td>
 <td align=center>192</td>
 <td align=center>2.60</td>
 <td align=center>998.4</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=296">(296) More</a></td>
 <td align=center>MDS_cluster</td>
 <td align=center>Medical Data Systems Limited</td>
 <td align=center>Pentium 3</td>
 <td align=center>5</td>
 <td align=center>2.00</td>
 <td align=center>10</td>
 <td align=center>Stanmore London</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=295">(295) More</a></td>
 <td align=center>Systemax Super Computer</td>
 <td align=center>Systemax Manufacturing</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>Fletcher Ohio</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=294">(294) More</a></td>
 <td align=center>Geowulf</td>
 <td align=center>Geowulf</td>
 <td align=center>Athlon</td>
 <td align=center>2</td>
 <td align=center>1.80</td>
 <td align=center>3.6</td>
 <td align=center>Round Rock, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=291">(291) More</a></td>
 <td align=center>CAMETA</td>
 <td align=center>Computational Fluid Dynamics Laboratory</td>
 <td align=center>Athlon XP</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Suranaree University of Technology, Nakhon Ratchasima, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=290">(290) More</a></td>
 <td align=center>Niobe</td>
 <td align=center>AMD Developer Center</td>
 <td align=center>Opteron</td>
 <td align=center>288</td>
 <td align=center>2.00</td>
 <td align=center>1152</td>
 <td align=center>Sunnyvale, Ca</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=284">(284) More</a></td>
 <td align=center>Miniwulf</td>
 <td align=center>Goddard Space Flight Center</td>
 <td align=center>Pentium 2</td>
 <td align=center>4</td>
 <td align=center>0.40</td>
 <td align=center>1.6</td>
 <td align=center>Greenbelt, Maryland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=283">(283) More</a></td>
 <td align=center>Idea</td>
 <td align=center>SONY IDL</td>
 <td align=center>Opteron</td>
 <td align=center>352</td>
 <td align=center>2.20</td>
 <td align=center>1548.8</td>
 <td align=center>TOKYO Japan</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=281">(281) More</a></td>
 <td align=center>FSUHEP CMS Grid</td>
 <td align=center>Florida State University</td>
 <td align=center>Pentium 4</td>
 <td align=center>7</td>
 <td align=center>2.40</td>
 <td align=center>33.6</td>
 <td align=center>Tallahassee, FL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=279">(279) More</a></td>
 <td align=center>ares</td>
 <td align=center>Tulane University</td>
 <td align=center>Opteron</td>
 <td align=center>12</td>
 <td align=center>2.00</td>
 <td align=center>48</td>
 <td align=center>New Orleans</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=278">(278) More</a></td>
 <td align=center>MAEKA</td>
 <td align=center>Department of CPE, Kasetsart University</td>
 <td align=center>EM64T-4</td>
 <td align=center>64</td>
 <td align=center>2.40</td>
 <td align=center>614.4</td>
 <td align=center>Bangkok, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=276">(276) More</a></td>
 <td align=center>NetworkBooster Research Cluster</td>
 <td align=center>NetworkBooster</td>
 <td align=center>Pentium 3</td>
 <td align=center>10</td>
 <td align=center>1.00</td>
 <td align=center>10</td>
 <td align=center>Mississauga, Canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=274">(274) More</a></td>
 <td align=center>SRITHAN</td>
 <td align=center>Khon Kaen University</td>
 <td align=center>Pentium 3</td>
 <td align=center>4</td>
 <td align=center>0.87</td>
 <td align=center>3.48</td>
 <td align=center>Khon Kaen, Thailand</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=273">(273) More</a></td>
 <td align=center>prisms.ices</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 3</td>
 <td align=center>1</td>
 <td align=center>0.80</td>
 <td align=center>0.8</td>
 <td align=center><font color=#616161>N/A</font></td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=272">(272) More</a></td>
 <td align=center>Debora</td>
 <td align=center>Johns Hopkins University</td>
 <td align=center>Pentium 2</td>
 <td align=center>24</td>
 <td align=center>0.45</td>
 <td align=center>10.8</td>
 <td align=center>Baltimore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=271">(271) More</a></td>
 <td align=center>ACI lpqsv11</td>
 <td align=center>Laboratoire de Physique Quantique</td>
 <td align=center>Opteron</td>
 <td align=center>78</td>
 <td align=center>2.00</td>
 <td align=center>312</td>
 <td align=center>Toulouse - France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=268">(268) More</a></td>
 <td align=center>elfie</td>
 <td align=center>ZIB</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.20</td>
 <td align=center>140.8</td>
 <td align=center>Berlin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=265">(265) More</a></td>
 <td align=center>SetiBuster</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 3</td>
 <td align=center>16</td>
 <td align=center>0.50</td>
 <td align=center>8</td>
 <td align=center>San Juan Puerto Rico</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=264">(264) More</a></td>
 <td align=center>BiCEPs</td>
 <td align=center>University of Bielefeld</td>
 <td align=center>Opteron</td>
 <td align=center>26</td>
 <td align=center>2.20</td>
 <td align=center>114.4</td>
 <td align=center>Bielefeld, Germany</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=260">(260) More</a></td>
 <td align=center>SAURON</td>
 <td align=center>Laboratorio de Computación de Alto Rendimiento UNET</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>1.70</td>
 <td align=center>27.2</td>
 <td align=center>San Cristobal - Venezuela</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=259">(259) More</a></td>
 <td align=center>IIM-SUN</td>
 <td align=center>Instituto de Investigaciones en Materiales</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Mexico City</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=258">(258) More</a></td>
 <td align=center>Hermes</td>
 <td align=center>UCLM Computational Chemistry Group</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.61</td>
 <td align=center>62.64</td>
 <td align=center>Ciudad Real (Spain)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=257">(257) More</a></td>
 <td align=center>Ralph</td>
 <td align=center>White Eagle Engineering</td>
 <td align=center>Pentium 3</td>
 <td align=center>32</td>
 <td align=center>1.00</td>
 <td align=center>32</td>
 <td align=center>Olney, Maryland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=256">(256) More</a></td>
 <td align=center>VSCluster</td>
 <td align=center>Laboratory for Solid State Chemistry</td>
 <td align=center>Pentium 4</td>
 <td align=center>14</td>
 <td align=center>2.80</td>
 <td align=center>78.4</td>
 <td align=center>Nijmegen, The Netherlands</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=255">(255) More</a></td>
 <td align=center>InGRID</td>
 <td align=center>Institute of Space Sciences</td>
 <td align=center>EM64T</td>
 <td align=center>25</td>
 <td align=center>2.40</td>
 <td align=center>120</td>
 <td align=center>Magurele</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=254">(254) More</a></td>
 <td align=center>Raster</td>
 <td align=center>NCMIR/UCSD</td>
 <td align=center>Opteron</td>
 <td align=center>42</td>
 <td align=center>2.00</td>
 <td align=center>168</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=253">(253) More</a></td>
 <td align=center>OCTOPUS</td>
 <td align=center>Universidad Técnica Federico Santa Maria</td>
 <td align=center>Athlon XP</td>
 <td align=center>3</td>
 <td align=center>1.90</td>
 <td align=center>11.4</td>
 <td align=center>Valparaiso, Chile</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=251">(251) More</a></td>
 <td align=center>Pit</td>
 <td align=center>Johns Hopkins Bloomberg School of Public Health</td>
 <td align=center>Opteron</td>
 <td align=center>68</td>
 <td align=center>2.20</td>
 <td align=center>299.2</td>
 <td align=center>Baltimore, MD</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=250">(250) More</a></td>
 <td align=center>Spider</td>
 <td align=center>LMT-COPPE-UFRJ</td>
 <td align=center>EM64T-8</td>
 <td align=center>18</td>
 <td align=center>2.40</td>
 <td align=center>345.6</td>
 <td align=center>PEM-COPPE/UFRJ, Rio de Janeiro, Brasil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=248">(248) More</a></td>
 <td align=center>Isabella</td>
 <td align=center>University Computing Centre - SRCE</td>
 <td align=center>Pentium 4</td>
 <td align=center>160</td>
 <td align=center>3.40</td>
 <td align=center>1088</td>
 <td align=center>Zagreb, Croatia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=247">(247) More</a></td>
 <td align=center>Mouse</td>
 <td align=center>AMD Developer Center</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>2.00</td>
 <td align=center>64</td>
 <td align=center>Sunnyvale</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=246">(246) More</a></td>
 <td align=center>Emerald</td>
 <td align=center>AMD Developer Center</td>
 <td align=center>Opteron</td>
 <td align=center>5</td>
 <td align=center>2.80</td>
 <td align=center>28</td>
 <td align=center>Sunnyvale</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=245">(245) More</a></td>
 <td align=center>Norgrid NTNU</td>
 <td align=center>NTNU</td>
 <td align=center>Pentium 4</td>
 <td align=center>66</td>
 <td align=center>3.40</td>
 <td align=center>448.8</td>
 <td align=center>Trondheim, Norway</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=244">(244) More</a></td>
 <td align=center>cxkurue</td>
 <td align=center>Walailak U</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.40</td>
 <td align=center>76.8</td>
 <td align=center>Nakhorsrithumarach  Thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=242">(242) More</a></td>
 <td align=center>InfoCluster</td>
 <td align=center>CENAPAD-MG/CO</td>
 <td align=center>Pentium 3</td>
 <td align=center>12</td>
 <td align=center>1.00</td>
 <td align=center>12</td>
 <td align=center>Universidade Federal Minas Gerais, Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=240">(240) More</a></td>
 <td align=center>ICS Alpha</td>
 <td align=center>Math Dept, Shanghai Jiaotong University</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Shanghai, China</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=239">(239) More</a></td>
 <td align=center>Spindel</td>
 <td align=center>UCSD CSE SC Group</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>1.80</td>
 <td align=center>57.6</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=238">(238) More</a></td>
 <td align=center>Odyssey</td>
 <td align=center>Open Biosystems</td>
 <td align=center>Opteron</td>
 <td align=center>8</td>
 <td align=center>2.40</td>
 <td align=center>38.4</td>
 <td align=center>Huntsville, Alabama</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=237">(237) More</a></td>
 <td align=center>Coltrane</td>
 <td align=center>UIUC</td>
 <td align=center>Opteron</td>
 <td align=center>10</td>
 <td align=center>1.60</td>
 <td align=center>32</td>
 <td align=center>Illinois</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=236">(236) More</a></td>
 <td align=center>CSE</td>
 <td align=center>Computational Science & Engineering</td>
 <td align=center>Opteron</td>
 <td align=center>22</td>
 <td align=center>2.20</td>
 <td align=center>96.8</td>
 <td align=center>University of California, Davis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=235">(235) More</a></td>
 <td align=center>prisms</td>
 <td align=center>Center for Computational Visualization, The University of Texas</td>
 <td align=center>Pentium 3</td>
 <td align=center>162</td>
 <td align=center>0.80</td>
 <td align=center>129.6</td>
 <td align=center>Austin, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=233">(233) More</a></td>
 <td align=center>Seraph Cluster</td>
 <td align=center>AMD Developer Center</td>
 <td align=center>Opteron</td>
 <td align=center>128</td>
 <td align=center>2.20</td>
 <td align=center>563.2</td>
 <td align=center>Sunnyvale</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=232">(232) More</a></td>
 <td align=center>PROTEUS</td>
 <td align=center>private</td>
 <td align=center>Other</td>
 <td align=center>14</td>
 <td align=center>0.80</td>
 <td align=center>11.2</td>
 <td align=center>Greenbelt Maryland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=231">(231) More</a></td>
 <td align=center>Fermilab reconstruction farms</td>
 <td align=center>Fermilab</td>
 <td align=center>Pentium 3</td>
 <td align=center>1504</td>
 <td align=center>1.50</td>
 <td align=center>2256</td>
 <td align=center>Batavia, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=230">(230) More</a></td>
 <td align=center>VMGrid</td>
 <td align=center>Ascential Software</td>
 <td align=center>Other</td>
 <td align=center>4</td>
 <td align=center>3.40</td>
 <td align=center>13.6</td>
 <td align=center>Westborough, MA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=229">(229) More</a></td>
 <td align=center>funcluster1</td>
 <td align=center>private</td>
 <td align=center>Pentium 3</td>
 <td align=center>3</td>
 <td align=center>0.45</td>
 <td align=center>1.35</td>
 <td align=center>Boston Metrowest, MA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=228">(228) More</a></td>
 <td align=center>private</td>
 <td align=center>Private</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.00</td>
 <td align=center>48</td>
 <td align=center>Worcester, MA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=227">(227) More</a></td>
 <td align=center>Beowulf</td>
 <td align=center>University of Houston HPC Group</td>
 <td align=center>Pentium 4</td>
 <td align=center>68</td>
 <td align=center>2.40</td>
 <td align=center>326.4</td>
 <td align=center>Houston</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=226">(226) More</a></td>
 <td align=center>Skynet</td>
 <td align=center>Skynet</td>
 <td align=center>Pentium 3</td>
 <td align=center>25</td>
 <td align=center>0.35</td>
 <td align=center>8.75</td>
 <td align=center>Falun, Sweden</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=225">(225) More</a></td>
 <td align=center>*Private*</td>
 <td align=center>*Private*</td>
 <td align=center>Opteron</td>
 <td align=center>256</td>
 <td align=center>2.20</td>
 <td align=center>1126.4</td>
 <td align=center>Paris, France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=224">(224) More</a></td>
 <td align=center>Xantos Rock</td>
 <td align=center>Xantos Biomedicine AG</td>
 <td align=center>Pentium 4</td>
 <td align=center>18</td>
 <td align=center>2.40</td>
 <td align=center>86.4</td>
 <td align=center>Munich</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=223">(223) More</a></td>
 <td align=center>spacenukes</td>
 <td align=center>Los Alamos National Laboratory</td>
 <td align=center>Opteron</td>
 <td align=center>20</td>
 <td align=center>1.40</td>
 <td align=center>56</td>
 <td align=center>Los Alamos, NM</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=222">(222) More</a></td>
 <td align=center>EC1</td>
 <td align=center>UCSF, Macromolecular Structure Group</td>
 <td align=center>Pentium 4</td>
 <td align=center>14</td>
 <td align=center>2.20</td>
 <td align=center>61.6</td>
 <td align=center>San Francisco, Calif., US</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=221">(221) More</a></td>
 <td align=center>Genesis</td>
 <td align=center>University of South Florida - AI Lab</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>3.00</td>
 <td align=center>24</td>
 <td align=center>Tampa, FL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=220">(220) More</a></td>
 <td align=center>Wonhyo</td>
 <td align=center>Bankok University</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>1.60</td>
 <td align=center>12.8</td>
 <td align=center>Bankok</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=219">(219) More</a></td>
 <td align=center>Googoo</td>
 <td align=center>Westmont College</td>
 <td align=center>Other</td>
 <td align=center>16</td>
 <td align=center>0.38</td>
 <td align=center>6.08</td>
 <td align=center>Santa Barbara</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=218">(218) More</a></td>
 <td align=center>DeepThought</td>
 <td align=center>Department of Aerospace Sciences, Cranfield University</td>
 <td align=center>Pentium 4</td>
 <td align=center>17</td>
 <td align=center>3.00</td>
 <td align=center>102</td>
 <td align=center>Cranfield, United Kingdom</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=217">(217) More</a></td>
 <td align=center>BU cluter</td>
 <td align=center>Bangkok University</td>
 <td align=center>Pentium 2</td>
 <td align=center>3</td>
 <td align=center>0.70</td>
 <td align=center>2.1</td>
 <td align=center>Bangkok Thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=216">(216) More</a></td>
 <td align=center>komolongma</td>
 <td align=center>Electrical and Computer Engineering, University of Puerto Rico</td>
 <td align=center>Pentium 3</td>
 <td align=center>130</td>
 <td align=center>1.20</td>
 <td align=center>156</td>
 <td align=center>Mayaguez, PR</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=215">(215) More</a></td>
 <td align=center>Groove</td>
 <td align=center>Human Genetics, UCLA</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Los Angeles</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=213">(213) More</a></td>
 <td align=center>biosys1</td>
 <td align=center>Michigan Center for Biological Information</td>
 <td align=center>Pentium 3</td>
 <td align=center>110</td>
 <td align=center>0.80</td>
 <td align=center>88</td>
 <td align=center>Ann Arbor, Michigan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=212">(212) More</a></td>
 <td align=center>Framingham Cluster</td>
 <td align=center>Framingham Heart Study</td>
 <td align=center>Pentium 4</td>
 <td align=center>30</td>
 <td align=center>2.40</td>
 <td align=center>144</td>
 <td align=center>Boston</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=211">(211) More</a></td>
 <td align=center>NodeX</td>
 <td align=center>Nodex ISP</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.80</td>
 <td align=center>89.6</td>
 <td align=center>Saint-Petersburg, Russia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=210">(210) More</a></td>
 <td align=center>Matterhorn</td>
 <td align=center>University of Zurich</td>
 <td align=center>Opteron</td>
 <td align=center>522</td>
 <td align=center>1.80</td>
 <td align=center>1879.2</td>
 <td align=center>Zurich</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=209">(209) More</a></td>
 <td align=center>Hyades</td>
 <td align=center>Astronomy Dept - University of Virginia</td>
 <td align=center>Pentium 4</td>
 <td align=center>28</td>
 <td align=center>2.80</td>
 <td align=center>156.8</td>
 <td align=center>Charlottesville, VA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=208">(208) More</a></td>
 <td align=center>cerebron</td>
 <td align=center>Quantum Chemistry Group, Jagiellonian University</td>
 <td align=center>Pentium 3</td>
 <td align=center>10</td>
 <td align=center>1.00</td>
 <td align=center>10</td>
 <td align=center>Cracow, Poland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=207">(207) More</a></td>
 <td align=center>homer</td>
 <td align=center>Radiological Sciences WUMS</td>
 <td align=center>Athlon MP</td>
 <td align=center>15</td>
 <td align=center>1.40</td>
 <td align=center>42</td>
 <td align=center>St Louis</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=206">(206) More</a></td>
 <td align=center>UICSuperCluster</td>
 <td align=center>University of Illinois in Chicago</td>
 <td align=center>Opteron</td>
 <td align=center>5</td>
 <td align=center>2.10</td>
 <td align=center>21</td>
 <td align=center>Chicago, Illinois</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=205">(205) More</a></td>
 <td align=center>titan</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>67.2</td>
 <td align=center>Aichi, Japan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=204">(204) More</a></td>
 <td align=center>Voyager</td>
 <td align=center>US Government</td>
 <td align=center>Opteron</td>
 <td align=center>480</td>
 <td align=center>1.80</td>
 <td align=center>1728</td>
 <td align=center>Washington, DC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=203">(203) More</a></td>
 <td align=center>USCMS and CDF Cluster</td>
 <td align=center>UCSD HEP</td>
 <td align=center>Pentium 4</td>
 <td align=center>200</td>
 <td align=center>2.60</td>
 <td align=center>1040</td>
 <td align=center>La Jolla</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=202">(202) More</a></td>
 <td align=center>Gandalf</td>
 <td align=center>AMD Developer Center</td>
 <td align=center>Opteron</td>
 <td align=center>32</td>
 <td align=center>2.20</td>
 <td align=center>140.8</td>
 <td align=center>Sunnyvale</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=201">(201) More</a></td>
 <td align=center>Mini-Morpheus</td>
 <td align=center>AMD Developer Center</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>1.80</td>
 <td align=center>57.6</td>
 <td align=center>Sunnyvale</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=200">(200) More</a></td>
 <td align=center>Smith</td>
 <td align=center>AMD Developer Center</td>
 <td align=center>Opteron</td>
 <td align=center>256</td>
 <td align=center>2.20</td>
 <td align=center>1126.4</td>
 <td align=center>Sunnyvale</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=199">(199) More</a></td>
 <td align=center>hpc1</td>
 <td align=center>New York University</td>
 <td align=center>Opteron</td>
 <td align=center>16</td>
 <td align=center>1.60</td>
 <td align=center>51.2</td>
 <td align=center>New York City</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=198">(198) More</a></td>
 <td align=center>apple</td>
 <td align=center>University of Miami</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>3.00</td>
 <td align=center>192</td>
 <td align=center>Miami</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=197">(197) More</a></td>
 <td align=center>plexus</td>
 <td align=center>RIT</td>
 <td align=center>Pentium 3</td>
 <td align=center>110</td>
 <td align=center>1.40</td>
 <td align=center>154</td>
 <td align=center>Rochester, NY</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=196">(196) More</a></td>
 <td align=center>clusterf</td>
 <td align=center><font color=#616161>N/A</font></td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>3.00</td>
 <td align=center>120</td>
 <td align=center>McLean, VA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=195">(195) More</a></td>
 <td align=center>plasma</td>
 <td align=center>MSU</td>
 <td align=center>Athlon XP</td>
 <td align=center>4</td>
 <td align=center>1.70</td>
 <td align=center>13.6</td>
 <td align=center>MSU, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=194">(194) More</a></td>
 <td align=center>mcbilin</td>
 <td align=center>MCBI</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>2.66</td>
 <td align=center>340.48</td>
 <td align=center>MSU, MI</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=193">(193) More</a></td>
 <td align=center>minicc2</td>
 <td align=center>Scalable Informatics LLC</td>
 <td align=center>Athlon XP</td>
 <td align=center>3</td>
 <td align=center>1.60</td>
 <td align=center>9.6</td>
 <td align=center>Canton, MI</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=192">(192) More</a></td>
 <td align=center>Cowan</td>
 <td align=center>Rollins College Physics Dept</td>
 <td align=center>Opteron</td>
 <td align=center>26</td>
 <td align=center>1.60</td>
 <td align=center>83.2</td>
 <td align=center>Winter Park, Florida</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=191">(191) More</a></td>
 <td align=center>WC-Governor</td>
 <td align=center>New Haven Public Schools</td>
 <td align=center>Pentium 3</td>
 <td align=center>12</td>
 <td align=center>0.55</td>
 <td align=center>6.6</td>
 <td align=center>New Haven, CT</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=190">(190) More</a></td>
 <td align=center>Tahu</td>
 <td align=center>MajorLinux Computing</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>2.40</td>
 <td align=center>14.4</td>
 <td align=center>Zurich</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=189">(189) More</a></td>
 <td align=center>SNOW</td>
 <td align=center>NUAA</td>
 <td align=center>Pentium 4</td>
 <td align=center>48</td>
 <td align=center>2.40</td>
 <td align=center>230.4</td>
 <td align=center>Nanjing PRC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=188">(188) More</a></td>
 <td align=center>cascade</td>
 <td align=center>University of Calgary</td>
 <td align=center>Athlon MP</td>
 <td align=center>32</td>
 <td align=center>2.20</td>
 <td align=center>140.8</td>
 <td align=center>Calgary, Alberta</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=187">(187) More</a></td>
 <td align=center>Elk</td>
 <td align=center>University of Calgary</td>
 <td align=center>Pentium 3</td>
 <td align=center>90</td>
 <td align=center>1.00</td>
 <td align=center>90</td>
 <td align=center>Calgary, Alberta</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=186">(186) More</a></td>
 <td align=center>Bigbird</td>
 <td align=center>University of St Andrews</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.80</td>
 <td align=center>22.4</td>
 <td align=center>St Andrews, Fife, UK</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=185">(185) More</a></td>
 <td align=center>FISMAT</td>
 <td align=center>HAPPY [] HACKING</td>
 <td align=center>Athlon XP</td>
 <td align=center>10</td>
 <td align=center>2.00</td>
 <td align=center>40</td>
 <td align=center>Morelia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=184">(184) More</a></td>
 <td align=center>Proadmin-Sequence</td>
 <td align=center>Proadmin, Inc.</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.40</td>
 <td align=center>38.4</td>
 <td align=center>Santa Clara, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=183">(183) More</a></td>
 <td align=center>CSAG-Rocks</td>
 <td align=center>CSAG-UCSD</td>
 <td align=center>Pentium 4</td>
 <td align=center>18</td>
 <td align=center>2.80</td>
 <td align=center>100.8</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=182">(182) More</a></td>
 <td align=center>camrdu06</td>
 <td align=center>AZRDM</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.80</td>
 <td align=center>44.8</td>
 <td align=center>Montreal, QC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=181">(181) More</a></td>
 <td align=center>lodestone</td>
 <td align=center>Scripps Institution of Oceanography</td>
 <td align=center>Pentium 4</td>
 <td align=center>278</td>
 <td align=center>2.80</td>
 <td align=center>1556.8</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=180">(180) More</a></td>
 <td align=center>Tales</td>
 <td align=center>UCLM Computational Chemistry Group</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.81</td>
 <td align=center>67.44</td>
 <td align=center>Ciudad Real (Spain)</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=179">(179) More</a></td>
 <td align=center>TSC Supercomputer</td>
 <td align=center>Systemax Manufacturing</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>2.80</td>
 <td align=center>112</td>
 <td align=center>Fletcher, OH</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=178">(178) More</a></td>
 <td align=center>Igneous</td>
 <td align=center>Edith Cowan University</td>
 <td align=center>Opteron</td>
 <td align=center>14</td>
 <td align=center>1.80</td>
 <td align=center>50.4</td>
 <td align=center>School of Computer and Information Science</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=177">(177) More</a></td>
 <td align=center>FIU CHEPREO Cluster</td>
 <td align=center>Florida International University</td>
 <td align=center>Pentium 4</td>
 <td align=center>20</td>
 <td align=center>2.67</td>
 <td align=center>106.8</td>
 <td align=center>NAP of the Americas - FIU Rack Space - Miami, FL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=176">(176) More</a></td>
 <td align=center>RAMSES</td>
 <td align=center>BECAT</td>
 <td align=center>Pentium 3</td>
 <td align=center>24</td>
 <td align=center>0.55</td>
 <td align=center>13.2</td>
 <td align=center>Storrs, Connecticut</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=175">(175) More</a></td>
 <td align=center>ulucreis</td>
 <td align=center>Istanbul Technical University</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>3.00</td>
 <td align=center>36</td>
 <td align=center>Istanbul-Turkey</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=174">(174) More</a></td>
 <td align=center>Nadelhorn</td>
 <td align=center>University of Zurich</td>
 <td align=center>Pentium 4</td>
 <td align=center>216</td>
 <td align=center>3.00</td>
 <td align=center>1296</td>
 <td align=center>Zurich, Switzerland</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=173">(173) More</a></td>
 <td align=center>placebo</td>
 <td align=center>Theory Group, Northwestern University</td>
 <td align=center>Opteron</td>
 <td align=center>88</td>
 <td align=center>2.00</td>
 <td align=center>352</td>
 <td align=center>Northwestern University, Evanston, IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=172">(172) More</a></td>
 <td align=center>Flower</td>
 <td align=center>CCGB, The University of Minnesota</td>
 <td align=center>Pentium 3</td>
 <td align=center>16</td>
 <td align=center>1.40</td>
 <td align=center>22.4</td>
 <td align=center>Minneapolis</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=171">(171) More</a></td>
 <td align=center>HPC00</td>
 <td align=center>PDPC / Providence University</td>
 <td align=center>Athlon MP</td>
 <td align=center>17</td>
 <td align=center>2.40</td>
 <td align=center>81.6</td>
 <td align=center>Taichung, Taiwan</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=170">(170) More</a></td>
 <td align=center>Addepalli-Cluster</td>
 <td align=center>Personal</td>
 <td align=center>Athlon XP</td>
 <td align=center>5</td>
 <td align=center>1.80</td>
 <td align=center>18</td>
 <td align=center>Texas</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=166">(166) More</a></td>
 <td align=center>HBARC</td>
 <td align=center>CalPoly Pomona</td>
 <td align=center>Pentium 4</td>
 <td align=center>26</td>
 <td align=center>1.80</td>
 <td align=center>93.6</td>
 <td align=center>Pomona, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=164">(164) More</a></td>
 <td align=center>Hydra-GHS</td>
 <td align=center>Gaithersburg High School</td>
 <td align=center>Pentium 3</td>
 <td align=center>13</td>
 <td align=center>0.93</td>
 <td align=center>12.09</td>
 <td align=center>Gaithersburg, MD</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=163">(163) More</a></td>
 <td align=center>milesahead</td>
 <td align=center>Lakehead University</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.80</td>
 <td align=center>67.2</td>
 <td align=center>Thunder Bay</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=162">(162) More</a></td>
 <td align=center>rescluster2</td>
 <td align=center>Partners Health Care</td>
 <td align=center>Pentium 4</td>
 <td align=center>23</td>
 <td align=center>3.06</td>
 <td align=center>140.76</td>
 <td align=center>Boston, MA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=161">(161) More</a></td>
 <td align=center>Lil Rascal</td>
 <td align=center>RBA Internet Services, Inc.</td>
 <td align=center>Pentium 4</td>
 <td align=center>5</td>
 <td align=center>2.00</td>
 <td align=center>20</td>
 <td align=center>Woodbridge, VA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=160">(160) More</a></td>
 <td align=center>sax0m</td>
 <td align=center>UI</td>
 <td align=center>Pentium 4</td>
 <td align=center>1</td>
 <td align=center>1.00</td>
 <td align=center>2</td>
 <td align=center>Jakarta</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=158">(158) More</a></td>
 <td align=center>stone</td>
 <td align=center>Quadrics</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>1.60</td>
 <td align=center>32</td>
 <td align=center>Bristol</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=156">(156) More</a></td>
 <td align=center>Quantanamera</td>
 <td align=center>Institut de Chimie de Strasborg, CNRS/Université Louis Pasteur</td>
 <td align=center>Athlon MP</td>
 <td align=center>27</td>
 <td align=center>2.13</td>
 <td align=center>115.02</td>
 <td align=center>Strasbourg, France</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=154">(154) More</a></td>
 <td align=center>Holomatrix</td>
 <td align=center>McLachlan Infotech (3D Graphics for Motion Picture Divs)</td>
 <td align=center>Pentium 4</td>
 <td align=center>24</td>
 <td align=center>2.40</td>
 <td align=center>115.2</td>
 <td align=center>Coffs Harbour, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=153">(153) More</a></td>
 <td align=center>stokes</td>
 <td align=center>Texas Learning & Computation Center University of Houston</td>
 <td align=center>Athlon MP</td>
 <td align=center>66</td>
 <td align=center>1.50</td>
 <td align=center>198</td>
 <td align=center>Houston</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=152">(152) More</a></td>
 <td align=center>asterion</td>
 <td align=center>Dip of Chemistry University of Bologna</td>
 <td align=center>Athlon MP</td>
 <td align=center>20</td>
 <td align=center>2.00</td>
 <td align=center>80</td>
 <td align=center>Bologna (Italy)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=151">(151) More</a></td>
 <td align=center>UN TOTS</td>
 <td align=center>Intel</td>
 <td align=center>Pentium 4</td>
 <td align=center>388</td>
 <td align=center>2.66</td>
 <td align=center>2064.16</td>
 <td align=center>Hillsboro. OR</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=150">(150) More</a></td>
 <td align=center>RoD</td>
 <td align=center>3CR/CS Dep./University of Bristol</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Bristol/UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=148">(148) More</a></td>
 <td align=center>RockStar</td>
 <td align=center>UCSD, CalIT^2, SDSC</td>
 <td align=center>Pentium 4</td>
 <td align=center>258</td>
 <td align=center>2.80</td>
 <td align=center>1444.8</td>
 <td align=center>Phoenix / La Jolla</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=147">(147) More</a></td>
 <td align=center>damascos</td>
 <td align=center>Materials Modeling Division, TU Darmstadt</td>
 <td align=center>Pentium 3</td>
 <td align=center>18</td>
 <td align=center>0.80</td>
 <td align=center>14.4</td>
 <td align=center>Darmstadt</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=146">(146) More</a></td>
 <td align=center>whataboutbobs</td>
 <td align=center>cluster.whataboutbob.org</td>
 <td align=center>Pentium 3</td>
 <td align=center>4</td>
 <td align=center>0.50</td>
 <td align=center>2</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=145">(145) More</a></td>
 <td align=center>Crayon</td>
 <td align=center>PRAGMA</td>
 <td align=center>Pentium 4</td>
 <td align=center>34</td>
 <td align=center>2.40</td>
 <td align=center>163.2</td>
 <td align=center>La Jolla</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=144">(144) More</a></td>
 <td align=center>orbitty</td>
 <td align=center>NCSU Physics Department</td>
 <td align=center>Pentium 4</td>
 <td align=center>92</td>
 <td align=center>2.40</td>
 <td align=center>441.6</td>
 <td align=center>Raleigh, North Carolina</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=142">(142) More</a></td>
 <td align=center>feynman</td>
 <td align=center>Quantum Chemistry Group, "Rudjer Boskovic" Institute</td>
 <td align=center>Athlon MP</td>
 <td align=center>12</td>
 <td align=center>2.13</td>
 <td align=center>51.12</td>
 <td align=center>Zagreb, Croatia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=140">(140) More</a></td>
 <td align=center>temasek</td>
 <td align=center>Nanyang Tech Univ (By NovaGlobal)</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>3.07</td>
 <td align=center>196.48</td>
 <td align=center>Singapore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=135">(135) More</a></td>
 <td align=center>Evolve</td>
 <td align=center>Australian Museum</td>
 <td align=center>Athlon MP</td>
 <td align=center>10</td>
 <td align=center>1.80</td>
 <td align=center>36</td>
 <td align=center>Sydney, Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=133">(133) More</a></td>
 <td align=center>Bedrocks</td>
 <td align=center>High Performance Computing and Networking Center</td>
 <td align=center>Athlon XP</td>
 <td align=center>4</td>
 <td align=center>1.00</td>
 <td align=center>8</td>
 <td align=center>Bangkok, Thailand</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=132">(132) More</a></td>
 <td align=center>Freedom</td>
 <td align=center>University of Malaya</td>
 <td align=center>Pentium 4</td>
 <td align=center>17</td>
 <td align=center>2.40</td>
 <td align=center>81.6</td>
 <td align=center>Kuala Lumpur, Malaysia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=131">(131) More</a></td>
 <td align=center>Gemini</td>
 <td align=center>RD-C2, High Performance Computing Research & Development @NECTEC</td>
 <td align=center>Athlon XP</td>
 <td align=center>8</td>
 <td align=center>1.66</td>
 <td align=center>26.56</td>
 <td align=center>Pathumthani, THAILAND</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=130">(130) More</a></td>
 <td align=center>Lonestar</td>
 <td align=center>TACC</td>
 <td align=center>Pentium 4</td>
 <td align=center>1024</td>
 <td align=center>3.06</td>
 <td align=center>6266.88</td>
 <td align=center>Austin, Texas</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=129">(129) More</a></td>
 <td align=center>Inst. for Computational Astrophysics Pluto Cluster</td>
 <td align=center>Saint Mary's University</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Halifax, NS, Canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=128">(128) More</a></td>
 <td align=center>SaDDam</td>
 <td align=center>INCAS</td>
 <td align=center>Athlon XP</td>
 <td align=center>32</td>
 <td align=center>1.80</td>
 <td align=center>115.2</td>
 <td align=center>Romania</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=127">(127) More</a></td>
 <td align=center>hydra</td>
 <td align=center>University of Florida</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.40</td>
 <td align=center>19.2</td>
 <td align=center>Gainesville</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=126">(126) More</a></td>
 <td align=center>mill</td>
 <td align=center>University of Helsinki</td>
 <td align=center>Athlon MP</td>
 <td align=center>64</td>
 <td align=center>2.13</td>
 <td align=center>272.64</td>
 <td align=center>Helsinki, Finland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=125">(125) More</a></td>
 <td align=center>Hosie</td>
 <td align=center>Hosie Family</td>
 <td align=center>Pentium 4</td>
 <td align=center>3</td>
 <td align=center>1.57</td>
 <td align=center>9.42</td>
 <td align=center>Gaithersburg, MD</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=124">(124) More</a></td>
 <td align=center>CTBP</td>
 <td align=center>Center for Theoretical Biological Physics</td>
 <td align=center>Pentium 4</td>
 <td align=center>160</td>
 <td align=center>2.80</td>
 <td align=center>896</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=123">(123) More</a></td>
 <td align=center>genrocks</td>
 <td align=center>BUMC - Genetics Program</td>
 <td align=center>Pentium 3</td>
 <td align=center>2</td>
 <td align=center>0.50</td>
 <td align=center>1</td>
 <td align=center>Boston</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=122">(122) More</a></td>
 <td align=center>3balls</td>
 <td align=center>Private experiment</td>
 <td align=center>Pentium 3</td>
 <td align=center>2</td>
 <td align=center>0.40</td>
 <td align=center>0.8</td>
 <td align=center>Brisbane Australia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=121">(121) More</a></td>
 <td align=center>Roie Rocks</td>
 <td align=center>SDSC</td>
 <td align=center>Itanium</td>
 <td align=center>4</td>
 <td align=center>0.80</td>
 <td align=center>12.8</td>
 <td align=center>La Jolla</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=120">(120) More</a></td>
 <td align=center>GOKU</td>
 <td align=center>Integrity Applications Inc.</td>
 <td align=center>Pentium 3</td>
 <td align=center>5</td>
 <td align=center>0.50</td>
 <td align=center>2.5</td>
 <td align=center>Chantilly, Virginia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=119">(119) More</a></td>
 <td align=center>nexus</td>
 <td align=center>Wake Forest University Health Sciences - Structural Biology</td>
 <td align=center>Athlon MP</td>
 <td align=center>32</td>
 <td align=center>2.00</td>
 <td align=center>128</td>
 <td align=center>Winston-Salem, NC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=118">(118) More</a></td>
 <td align=center>CCC Compute Cluster</td>
 <td align=center>Worcester Polytechnic Institute (WPI)</td>
 <td align=center>Pentium 4</td>
 <td align=center>22</td>
 <td align=center>2.40</td>
 <td align=center>105.6</td>
 <td align=center>Worcester, MA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=117">(117) More</a></td>
 <td align=center>Cosima</td>
 <td align=center>Materials Modeling Division, TU Darmstadt</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>Darmstadt, Germany</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=116">(116) More</a></td>
 <td align=center>Magellan</td>
 <td align=center>Massachusetts Biomedical Initiatives</td>
 <td align=center>Pentium 4</td>
 <td align=center>16</td>
 <td align=center>2.79</td>
 <td align=center>89.28</td>
 <td align=center>Worcester, Massachusetts</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=115">(115) More</a></td>
 <td align=center>HPCCC TDG ROCKS</td>
 <td align=center>High Performance Cluster Computing Centre, HK Baptist University</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>2.80</td>
 <td align=center>716.8</td>
 <td align=center>Hong Kong</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=114">(114) More</a></td>
 <td align=center>Vertex</td>
 <td align=center>University of Texas at Austin</td>
 <td align=center>Pentium 4</td>
 <td align=center>18</td>
 <td align=center>2.40</td>
 <td align=center>86.4</td>
 <td align=center>Austin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=113">(113) More</a></td>
 <td align=center>Numbers</td>
 <td align=center>San Diego State University</td>
 <td align=center>Athlon</td>
 <td align=center>6</td>
 <td align=center>2.80</td>
 <td align=center>16.8</td>
 <td align=center>San Diego, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=112">(112) More</a></td>
 <td align=center>henhouse</td>
 <td align=center>Swiss Institute of Bioinformatics</td>
 <td align=center>Pentium 4</td>
 <td align=center>30</td>
 <td align=center>2.40</td>
 <td align=center>144</td>
 <td align=center>Geneva, Switzerland</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=111">(111) More</a></td>
 <td align=center>Valkyrie</td>
 <td align=center>UCSD, Academic Computing</td>
 <td align=center>Pentium 3</td>
 <td align=center>32</td>
 <td align=center>1.00</td>
 <td align=center>32</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=110">(110) More</a></td>
 <td align=center>skiron</td>
 <td align=center>NTUA Chemical Engineering School</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.66</td>
 <td align=center>21.28</td>
 <td align=center>Athens</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=109">(109) More</a></td>
 <td align=center>Apollo</td>
 <td align=center>SDUST</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.00</td>
 <td align=center>32</td>
 <td align=center>SDUST , China</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=108">(108) More</a></td>
 <td align=center>rocks11</td>
 <td align=center>PNNL</td>
 <td align=center>Pentium 4</td>
 <td align=center>48</td>
 <td align=center>2.40</td>
 <td align=center>230.4</td>
 <td align=center>Richland Wa</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=107">(107) More</a></td>
 <td align=center>Matrix</td>
 <td align=center>National Research Council</td>
 <td align=center>Pentium 4</td>
 <td align=center>48</td>
 <td align=center>2.40</td>
 <td align=center>230.4</td>
 <td align=center>Ottawa, Canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=105">(105) More</a></td>
 <td align=center>remora</td>
 <td align=center>Instituto de Investigaciones en Materiales, UNAM</td>
 <td align=center>Pentium 4</td>
 <td align=center>7</td>
 <td align=center>2.20</td>
 <td align=center>30.8</td>
 <td align=center>Mexico, D.F.</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=104">(104) More</a></td>
 <td align=center>zcools</td>
 <td align=center>Non profit</td>
 <td align=center>Pentium 2</td>
 <td align=center>8</td>
 <td align=center>1.20</td>
 <td align=center>9.6</td>
 <td align=center>Italy Milano</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=103">(103) More</a></td>
 <td align=center>Bevo</td>
 <td align=center>University of Texas CSM</td>
 <td align=center>Athlon MP</td>
 <td align=center>90</td>
 <td align=center>2.00</td>
 <td align=center>360</td>
 <td align=center>Austin, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=102">(102) More</a></td>
 <td align=center>Nashi</td>
 <td align=center>ECE Dept.</td>
 <td align=center>Athlon MP</td>
 <td align=center>88</td>
 <td align=center>1.80</td>
 <td align=center>316.8</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=101">(101) More</a></td>
 <td align=center>mathwulf</td>
 <td align=center>Texas Tech Math/HPCC</td>
 <td align=center>Athlon XP</td>
 <td align=center>24</td>
 <td align=center>1.00</td>
 <td align=center>48</td>
 <td align=center>Lubbock, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=100">(100) More</a></td>
 <td align=center>antaeus</td>
 <td align=center>Texas Tech HPCC</td>
 <td align=center>Athlon MP</td>
 <td align=center>32</td>
 <td align=center>1.67</td>
 <td align=center>106.88</td>
 <td align=center>Lubbock, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=99">(99) More</a></td>
 <td align=center>weland</td>
 <td align=center>Texas Tech HPCC</td>
 <td align=center>Athlon MP</td>
 <td align=center>64</td>
 <td align=center>1.67</td>
 <td align=center>213.76</td>
 <td align=center>Lubbock, TX</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=98">(98) More</a></td>
 <td align=center>Snowstorm</td>
 <td align=center>University of Tromsø</td>
 <td align=center>Itanium 2</td>
 <td align=center>376</td>
 <td align=center>1.30</td>
 <td align=center>1955.2</td>
 <td align=center>Tromsø, Norway</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=97">(97) More</a></td>
 <td align=center>ngc</td>
 <td align=center>CNR IRC</td>
 <td align=center>Athlon XP</td>
 <td align=center>9</td>
 <td align=center>1.80</td>
 <td align=center>32.4</td>
 <td align=center>Napoli Italy</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=96">(96) More</a></td>
 <td align=center>polvo</td>
 <td align=center>INESC-MN</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>2.54</td>
 <td align=center>40.64</td>
 <td align=center>Lisboa Portugal</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=95">(95) More</a></td>
 <td align=center>tejas</td>
 <td align=center>Texas Advanced Computing Center</td>
 <td align=center>Pentium 3</td>
 <td align=center>64</td>
 <td align=center>1.00</td>
 <td align=center>64</td>
 <td align=center>Austin</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=94">(94) More</a></td>
 <td align=center>JCSG Falcon</td>
 <td align=center>JCSG</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>2.40</td>
 <td align=center>614.4</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=93">(93) More</a></td>
 <td align=center>JCSG Jet</td>
 <td align=center>JCSG</td>
 <td align=center>Pentium 3</td>
 <td align=center>32</td>
 <td align=center>1.00</td>
 <td align=center>32</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=92">(92) More</a></td>
 <td align=center>Brutus</td>
 <td align=center>Myricom, Inc.</td>
 <td align=center>Pentium 3</td>
 <td align=center>16</td>
 <td align=center>1.00</td>
 <td align=center>16</td>
 <td align=center>Oak Ridge, TN</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=91">(91) More</a></td>
 <td align=center>typical</td>
 <td align=center>Theory Group, Northwestern University</td>
 <td align=center>Itanium 2</td>
 <td align=center>12</td>
 <td align=center>0.90</td>
 <td align=center>43.2</td>
 <td align=center>Northwestern U.</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=90">(90) More</a></td>
 <td align=center>kansas</td>
 <td align=center>Brown University</td>
 <td align=center>Pentium 4</td>
 <td align=center>26</td>
 <td align=center>2.20</td>
 <td align=center>114.4</td>
 <td align=center>Providence</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=89">(89) More</a></td>
 <td align=center>GL_monster</td>
 <td align=center>Brown University</td>
 <td align=center>Pentium 4</td>
 <td align=center>98</td>
 <td align=center>1.70</td>
 <td align=center>333.2</td>
 <td align=center>Providence</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=88">(88) More</a></td>
 <td align=center>marx</td>
 <td align=center>Brown University</td>
 <td align=center>Athlon MP</td>
 <td align=center>88</td>
 <td align=center>1.67</td>
 <td align=center>293.92</td>
 <td align=center>Providence</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=87">(87) More</a></td>
 <td align=center>lou</td>
 <td align=center>Brown University</td>
 <td align=center>Athlon MP</td>
 <td align=center>98</td>
 <td align=center>1.67</td>
 <td align=center>327.32</td>
 <td align=center>Providence</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=86">(86) More</a></td>
 <td align=center>trapeza</td>
 <td align=center>Brown University</td>
 <td align=center>Athlon MP</td>
 <td align=center>40</td>
 <td align=center>1.53</td>
 <td align=center>122.4</td>
 <td align=center>Providence</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=85">(85) More</a></td>
 <td align=center>d2grid</td>
 <td align=center>d2grid.com</td>
 <td align=center>Pentium 4</td>
 <td align=center>24</td>
 <td align=center>2.40</td>
 <td align=center>115.2</td>
 <td align=center>China.P.R.</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=84">(84) More</a></td>
 <td align=center>Sin-Cluster</td>
 <td align=center>Sinergy</td>
 <td align=center>Pentium 4</td>
 <td align=center>4</td>
 <td align=center>2.00</td>
 <td align=center>16</td>
 <td align=center>italy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=83">(83) More</a></td>
 <td align=center>PIPE</td>
 <td align=center>Digital Image Analysis Lab</td>
 <td align=center>Pentium 4</td>
 <td align=center>98</td>
 <td align=center>2.40</td>
 <td align=center>470.4</td>
 <td align=center>Scripps Institution of Oceanography</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=82">(82) More</a></td>
 <td align=center>Dell PE2650</td>
 <td align=center>Corp</td>
 <td align=center>Opteron</td>
 <td align=center>4</td>
 <td align=center>2.80</td>
 <td align=center>22.4</td>
 <td align=center>Round Rock, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=81">(81) More</a></td>
 <td align=center>EMA CCSU COMPUTER CLUB</td>
 <td align=center>CCSU Computer Club</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>0.67</td>
 <td align=center>5.36</td>
 <td align=center>New Britain CT</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=80">(80) More</a></td>
 <td align=center>Milky Way</td>
 <td align=center>i2r</td>
 <td align=center>Pentium 3</td>
 <td align=center>11</td>
 <td align=center>0.60</td>
 <td align=center>6.6</td>
 <td align=center>Singapore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=79">(79) More</a></td>
 <td align=center>gaspac</td>
 <td align=center>Genetic Algorithm Systems Lab</td>
 <td align=center>Pentium 3</td>
 <td align=center>12</td>
 <td align=center>1.13</td>
 <td align=center>13.56</td>
 <td align=center>University of Nevada, Reno</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=78">(78) More</a></td>
 <td align=center>hydra3</td>
 <td align=center>Singapore-MIT Alliance</td>
 <td align=center>Itanium 2</td>
 <td align=center>60</td>
 <td align=center>1.00</td>
 <td align=center>240</td>
 <td align=center>Singapore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=77">(77) More</a></td>
 <td align=center>Itanic</td>
 <td align=center>Rocks Cluster Development</td>
 <td align=center>Itanium 2</td>
 <td align=center>8</td>
 <td align=center>0.90</td>
 <td align=center>28.8</td>
 <td align=center>La Jolla, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=76">(76) More</a></td>
 <td align=center>GCLcluster</td>
 <td align=center>UC Berkeley Geophysics Computing Lab</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>2.40</td>
 <td align=center>307.2</td>
 <td align=center>UC Berkeley</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=75">(75) More</a></td>
 <td align=center>cluster2</td>
 <td align=center>LCP/COPPE/UFRJ</td>
 <td align=center>Pentium 4</td>
 <td align=center>9</td>
 <td align=center>2.40</td>
 <td align=center>43.2</td>
 <td align=center>Rio de Janeiro/Brazil</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=74">(74) More</a></td>
 <td align=center>Geon-SDSC</td>
 <td align=center>Geon</td>
 <td align=center>Pentium 4</td>
 <td align=center>12</td>
 <td align=center>2.40</td>
 <td align=center>57.6</td>
 <td align=center>San Diego, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=73">(73) More</a></td>
 <td align=center>Orc</td>
 <td align=center>University of Surrey SCRIBA</td>
 <td align=center>Pentium 3</td>
 <td align=center>20</td>
 <td align=center>1.40</td>
 <td align=center>28</td>
 <td align=center>Guildford, Surrey. UK</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=72">(72) More</a></td>
 <td align=center>hpcvl</td>
 <td align=center>Carleton University</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>1.85</td>
 <td align=center>473.6</td>
 <td align=center>Ontario, Canada</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=71">(71) More</a></td>
 <td align=center>cortex</td>
 <td align=center>University Of Nevada, Reno</td>
 <td align=center>Pentium 4</td>
 <td align=center>128</td>
 <td align=center>2.40</td>
 <td align=center>614.4</td>
 <td align=center>Reno, NV</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=70">(70) More</a></td>
 <td align=center>walnut</td>
 <td align=center>University Of Nevada, Reno Chemistry Department</td>
 <td align=center>Athlon XP</td>
 <td align=center>30</td>
 <td align=center>1.80</td>
 <td align=center>108</td>
 <td align=center>Reno, NV</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=69">(69) More</a></td>
 <td align=center>Electra</td>
 <td align=center>University of Macedonia, Department of Applied Informatics</td>
 <td align=center>Pentium 2</td>
 <td align=center>65</td>
 <td align=center>0.23</td>
 <td align=center>14.95</td>
 <td align=center>Thessaloniki, Greece (Hellas)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=68">(68) More</a></td>
 <td align=center>Martinez</td>
 <td align=center>University of Illinois School of Chemical Sciences</td>
 <td align=center>Other</td>
 <td align=center>27</td>
 <td align=center>1.40</td>
 <td align=center>37.8</td>
 <td align=center>Urbana, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=67">(67) More</a></td>
 <td align=center>Makri</td>
 <td align=center>University of Illinois School of Chemical Sciences</td>
 <td align=center>Athlon MP</td>
 <td align=center>18</td>
 <td align=center>1.66</td>
 <td align=center>59.76</td>
 <td align=center>Urbana, IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=66">(66) More</a></td>
 <td align=center>Schulten</td>
 <td align=center>University of Illinois School of Chemical Sciences</td>
 <td align=center>Athlon XP</td>
 <td align=center>23</td>
 <td align=center>1.80</td>
 <td align=center>82.8</td>
 <td align=center>Urbana, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=65">(65) More</a></td>
 <td align=center>Iceberg</td>
 <td align=center>Bio-X @ Stanford University</td>
 <td align=center>Pentium 4</td>
 <td align=center>604</td>
 <td align=center>2.80</td>
 <td align=center>3382.4</td>
 <td align=center>Stanford, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=64">(64) More</a></td>
 <td align=center>receptor</td>
 <td align=center>Biomaterials, Drug Delivery, and Molecular Recognition Labs</td>
 <td align=center>Athlon MP</td>
 <td align=center>8</td>
 <td align=center>1.66</td>
 <td align=center>26.56</td>
 <td align=center>University of Texas at Austin</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=63">(63) More</a></td>
 <td align=center>Tembusu</td>
 <td align=center>School of Computing, National University of Singapore</td>
 <td align=center>Pentium 3</td>
 <td align=center>128</td>
 <td align=center>1.40</td>
 <td align=center>179.2</td>
 <td align=center>Singapore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=62">(62) More</a></td>
 <td align=center>keck2</td>
 <td align=center>UCSD Chemistry  - McCammon Lab</td>
 <td align=center>Pentium 3</td>
 <td align=center>76</td>
 <td align=center>0.80</td>
 <td align=center>60.8</td>
 <td align=center>San Diego, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=61">(61) More</a></td>
 <td align=center>elan</td>
 <td align=center>University of Delaware</td>
 <td align=center>Pentium 4</td>
 <td align=center>80</td>
 <td align=center>2.40</td>
 <td align=center>384</td>
 <td align=center>Newark, DE</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=60">(60) More</a></td>
 <td align=center>EIL</td>
 <td align=center>Environmental Information Lab</td>
 <td align=center>Pentium 3</td>
 <td align=center>18</td>
 <td align=center>0.40</td>
 <td align=center>7.2</td>
 <td align=center>Santa Barbara</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=58">(58) More</a></td>
 <td align=center>BiG</td>
 <td align=center>Nanyang Polytechnic</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Singapore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=57">(57) More</a></td>
 <td align=center>balsa</td>
 <td align=center>School of Math, Georgia Institute of Technology</td>
 <td align=center>Athlon MP</td>
 <td align=center>28</td>
 <td align=center>1.80</td>
 <td align=center>100.8</td>
 <td align=center>Atlanta, GA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=56">(56) More</a></td>
 <td align=center>Florida CMS Tier2</td>
 <td align=center>University of Florida</td>
 <td align=center>Pentium 3</td>
 <td align=center>140</td>
 <td align=center>1.00</td>
 <td align=center>140</td>
 <td align=center>University of Florida</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=55">(55) More</a></td>
 <td align=center>Caltech CMS Tier2</td>
 <td align=center>Caltech</td>
 <td align=center>Pentium 4</td>
 <td align=center>40</td>
 <td align=center>2.40</td>
 <td align=center>192</td>
 <td align=center>Caltech</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=54">(54) More</a></td>
 <td align=center>US Tier1 Facility for CMS</td>
 <td align=center>CMS</td>
 <td align=center>Athlon MP</td>
 <td align=center>120</td>
 <td align=center>1.90</td>
 <td align=center>456</td>
 <td align=center>Fermilab</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=53">(53) More</a></td>
 <td align=center>UCSD CMS Tier2</td>
 <td align=center>UCSD</td>
 <td align=center>Pentium 4</td>
 <td align=center>40</td>
 <td align=center>2.40</td>
 <td align=center>192</td>
 <td align=center>SDSC</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=52">(52) More</a></td>
 <td align=center>Chihuahua</td>
 <td align=center>North Carolina State University College of PAMS</td>
 <td align=center>Pentium 4</td>
 <td align=center>311</td>
 <td align=center>2.25</td>
 <td align=center>1399.5</td>
 <td align=center>Raleigh, North Carolina</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=51">(51) More</a></td>
 <td align=center>GridKa</td>
 <td align=center>Forschungszentrum Karlsruhe</td>
 <td align=center>EM64T</td>
 <td align=center>8632</td>
 <td align=center>2.52</td>
 <td align=center>43505.28</td>
 <td align=center>Karlsruhe, Germany</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=50">(50) More</a></td>
 <td align=center>JADE</td>
 <td align=center>GENOME INSTITUTE OF SINGAPORE</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>SINGAPORE</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=49">(49) More</a></td>
 <td align=center>RocketScience0</td>
 <td align=center>SCS</td>
 <td align=center>Pentium 3</td>
 <td align=center>16</td>
 <td align=center>0.55</td>
 <td align=center>8.8</td>
 <td align=center>SCS - Singapore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=48">(48) More</a></td>
 <td align=center>RocketScience2</td>
 <td align=center>SCS</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.80</td>
 <td align=center>179.2</td>
 <td align=center>SCS - Singapore</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=47">(47) More</a></td>
 <td align=center>RocketScience</td>
 <td align=center>SCS</td>
 <td align=center>Pentium 4</td>
 <td align=center>10</td>
 <td align=center>2.20</td>
 <td align=center>44</td>
 <td align=center>SCS - Singapore</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=46">(46) More</a></td>
 <td align=center>Jaguar</td>
 <td align=center>National University of Singapore (NUS)</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.20</td>
 <td align=center>140.8</td>
 <td align=center>NUS, Supercomputing and Visualisation Unit</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=45">(45) More</a></td>
 <td align=center>stein</td>
 <td align=center>CNR IBF</td>
 <td align=center>Athlon XP</td>
 <td align=center>12</td>
 <td align=center>1.60</td>
 <td align=center>38.4</td>
 <td align=center>Palermo Italy</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=44">(44) More</a></td>
 <td align=center>Herzberg</td>
 <td align=center>Institute "Rudjer Boskovic"</td>
 <td align=center>Pentium 3</td>
 <td align=center>6</td>
 <td align=center>1.00</td>
 <td align=center>6</td>
 <td align=center>Zagreb, Croatia</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=43">(43) More</a></td>
 <td align=center>Geofizika</td>
 <td align=center>Faculty of Science, Department of Geophysics</td>
 <td align=center>Athlon MP</td>
 <td align=center>12</td>
 <td align=center>2.00</td>
 <td align=center>48</td>
 <td align=center>Zagreb, Croatia</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=42">(42) More</a></td>
 <td align=center>Britannic</td>
 <td align=center>SDSC</td>
 <td align=center>Itanium 2</td>
 <td align=center>2</td>
 <td align=center>0.90</td>
 <td align=center>7.2</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=41">(41) More</a></td>
 <td align=center>ARCluster</td>
 <td align=center>Von Karman Institute</td>
 <td align=center>Athlon XP</td>
 <td align=center>16</td>
 <td align=center>1.80</td>
 <td align=center>57.6</td>
 <td align=center>Rhode-St-Genese, Belgium</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=40">(40) More</a></td>
 <td align=center>Distributed</td>
 <td align=center>UC Irvine, EECS Dept.</td>
 <td align=center>Athlon MP</td>
 <td align=center>32</td>
 <td align=center>1.60</td>
 <td align=center>102.4</td>
 <td align=center>Irvine, CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=39">(39) More</a></td>
 <td align=center>loni-gpop</td>
 <td align=center>BIRN</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.10</td>
 <td align=center>8.8</td>
 <td align=center>LA (UCLA) CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=38">(38) More</a></td>
 <td align=center>bic-gpop</td>
 <td align=center>BIRN</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.10</td>
 <td align=center>8.8</td>
 <td align=center>Pasadena (CalTech) CA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=37">(37) More</a></td>
 <td align=center>unc-gpop</td>
 <td align=center>BIRN</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.10</td>
 <td align=center>8.8</td>
 <td align=center>Durham (Duke) North Carolina</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=36">(36) More</a></td>
 <td align=center>civm-gpop</td>
 <td align=center>BIRN</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.10</td>
 <td align=center>8.8</td>
 <td align=center>Durham (Duke) North Carolina</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=35">(35) More</a></td>
 <td align=center>mgh-gpop</td>
 <td align=center>BIRN</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.10</td>
 <td align=center>8.8</td>
 <td align=center>Boston Mass</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=34">(34) More</a></td>
 <td align=center>bwh-gpop</td>
 <td align=center>BIRN</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.10</td>
 <td align=center>8.8</td>
 <td align=center>Boston Mass</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=33">(33) More</a></td>
 <td align=center>fMRI-gpop</td>
 <td align=center>BIRN</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.10</td>
 <td align=center>8.8</td>
 <td align=center>San Diego, CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=32">(32) More</a></td>
 <td align=center>ncmir-gpop</td>
 <td align=center>BIRN</td>
 <td align=center>Pentium 3</td>
 <td align=center>9</td>
 <td align=center>1.10</td>
 <td align=center>9.9</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=31">(31) More</a></td>
 <td align=center>BCC-gpop</td>
 <td align=center>BIRN</td>
 <td align=center>Pentium 3</td>
 <td align=center>10</td>
 <td align=center>1.10</td>
 <td align=center>11</td>
 <td align=center>SDSC, San Diego CA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=30">(30) More</a></td>
 <td align=center>rocks10</td>
 <td align=center>PNNL</td>
 <td align=center>Pentium 3</td>
 <td align=center>8</td>
 <td align=center>1.00</td>
 <td align=center>8</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=29">(29) More</a></td>
 <td align=center>rocks8</td>
 <td align=center>PNNL</td>
 <td align=center>Pentium 4</td>
 <td align=center>8</td>
 <td align=center>1.70</td>
 <td align=center>27.2</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=28">(28) More</a></td>
 <td align=center>rocks7</td>
 <td align=center>PNNL</td>
 <td align=center>EM64T</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=27">(27) More</a></td>
 <td align=center>rocks9</td>
 <td align=center>PNNL</td>
 <td align=center>Pentium 4</td>
 <td align=center>212</td>
 <td align=center>2.00</td>
 <td align=center>848</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=26">(26) More</a></td>
 <td align=center>rocks6</td>
 <td align=center>PNNL</td>
 <td align=center>Pentium 4</td>
 <td align=center>96</td>
 <td align=center>2.33</td>
 <td align=center>447.36</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=25">(25) More</a></td>
 <td align=center>rocks5</td>
 <td align=center>PNNL</td>
 <td align=center>EM64T</td>
 <td align=center>8</td>
 <td align=center>2.40</td>
 <td align=center>38.4</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=24">(24) More</a></td>
 <td align=center>rocks4</td>
 <td align=center>PNNL</td>
 <td align=center>Pentium 4</td>
 <td align=center>32</td>
 <td align=center>2.40</td>
 <td align=center>153.6</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=23">(23) More</a></td>
 <td align=center>rocks3</td>
 <td align=center>PNNL</td>
 <td align=center>EM64T</td>
 <td align=center>52</td>
 <td align=center>2.80</td>
 <td align=center>291.2</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=22">(22) More</a></td>
 <td align=center>rocks2</td>
 <td align=center>PNNL</td>
 <td align=center>EM64T</td>
 <td align=center>72</td>
 <td align=center>2.33</td>
 <td align=center>335.52</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=21">(21) More</a></td>
 <td align=center>rocks1</td>
 <td align=center>PNNL</td>
 <td align=center>EM64T</td>
 <td align=center>176</td>
 <td align=center>2.66</td>
 <td align=center>936.32</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=20">(20) More</a></td>
 <td align=center>grieg</td>
 <td align=center>Universidad de Sevilla</td>
 <td align=center>Athlon MP</td>
 <td align=center>14</td>
 <td align=center>2.20</td>
 <td align=center>61.6</td>
 <td align=center>Sevilla (Spain)</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=19">(19) More</a></td>
 <td align=center>BACCie</td>
 <td align=center>Government</td>
 <td align=center>Pentium 4</td>
 <td align=center>38</td>
 <td align=center>2.20</td>
 <td align=center>167.2</td>
 <td align=center>DC/VA Metro</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=18">(18) More</a></td>
 <td align=center>mermaid</td>
 <td align=center>Scripps Institution of Oceanography</td>
 <td align=center>Pentium 3</td>
 <td align=center>18</td>
 <td align=center>0.73</td>
 <td align=center>13.14</td>
 <td align=center>Scripps Institution of Oceanography</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=17">(17) More</a></td>
 <td align=center>compas</td>
 <td align=center>Scripps Institution of Oceanography</td>
 <td align=center>Pentium 3</td>
 <td align=center>256</td>
 <td align=center>1.00</td>
 <td align=center>256</td>
 <td align=center>Scripps Institution of Oceanography</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=16">(16) More</a></td>
 <td align=center>atlas</td>
 <td align=center>Scripps Institution of Oceanography</td>
 <td align=center>Pentium 3</td>
 <td align=center>256</td>
 <td align=center>1.00</td>
 <td align=center>256</td>
 <td align=center>Scripps Institution of Oceanography</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=15">(15) More</a></td>
 <td align=center>Jupiter</td>
 <td align=center>The Institute for Advanced Technology</td>
 <td align=center>Pentium 3</td>
 <td align=center>44</td>
 <td align=center>1.00</td>
 <td align=center>44</td>
 <td align=center>Austin, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=14">(14) More</a></td>
 <td align=center>The Extinction Machine</td>
 <td align=center>Biological Sciences, University of South Carolina</td>
 <td align=center>Athlon MP</td>
 <td align=center>194</td>
 <td align=center>1.73</td>
 <td align=center>671.24</td>
 <td align=center>Columbia, South Carolina</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=13">(13) More</a></td>
 <td align=center>Pluto</td>
 <td align=center>The Institute for Advanced Technology</td>
 <td align=center>Athlon</td>
 <td align=center>16</td>
 <td align=center>0.60</td>
 <td align=center>9.6</td>
 <td align=center>Austin, TX</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=12">(12) More</a></td>
 <td align=center>vague</td>
 <td align=center>Theory Group, Northwestern University</td>
 <td align=center>Opteron</td>
 <td align=center>4</td>
 <td align=center>1.70</td>
 <td align=center>13.6</td>
 <td align=center>Northwestern University, Evanston, IL</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=11">(11) More</a></td>
 <td align=center>general</td>
 <td align=center>Theory Group, Northwestern University</td>
 <td align=center>Pentium 4</td>
 <td align=center>14</td>
 <td align=center>2.40</td>
 <td align=center>67.2</td>
 <td align=center>Northwestern University, Evanston, IL</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=10">(10) More</a></td>
 <td align=center>wprocks0</td>
 <td align=center>Weather Predict, Inc.</td>
 <td align=center>Athlon MP</td>
 <td align=center>28</td>
 <td align=center>2.00</td>
 <td align=center>112</td>
 <td align=center>Weather Predict, Inc., Raleigh, NC</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=9">(9) More</a></td>
 <td align=center>fhypn</td>
 <td align=center>Batelle</td>
 <td align=center>Athlon MP</td>
 <td align=center>14</td>
 <td align=center>2.13</td>
 <td align=center>59.64</td>
 <td align=center>Richland, WA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=8">(8) More</a></td>
 <td align=center>lc1</td>
 <td align=center>University of Virginia/ITC</td>
 <td align=center>Pentium 4</td>
 <td align=center>64</td>
 <td align=center>2.40</td>
 <td align=center>307.2</td>
 <td align=center>Charlottesville, VA</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=7">(7) More</a></td>
 <td align=center>lc0</td>
 <td align=center>University of Virginia/ITC</td>
 <td align=center>Athlon MP</td>
 <td align=center>96</td>
 <td align=center>1.53</td>
 <td align=center>293.76</td>
 <td align=center>Charlottesville, VA</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=6">(6) More</a></td>
 <td align=center>keck1</td>
 <td align=center>NCMIR</td>
 <td align=center>Pentium 3</td>
 <td align=center>64</td>
 <td align=center>0.80</td>
 <td align=center>51.2</td>
 <td align=center>National Center for Microscopy Imaging Research</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=5">(5) More</a></td>
 <td align=center>Meteor</td>
 <td align=center>Rocks</td>
 <td align=center>Pentium 3</td>
 <td align=center>118</td>
 <td align=center>0.93</td>
 <td align=center>109.74</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=4">(4) More</a></td>
 <td align=center>Buzz</td>
 <td align=center>Rocks</td>
 <td align=center>Pentium 4</td>
 <td align=center>6</td>
 <td align=center>2.20</td>
 <td align=center>26.4</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=3">(3) More</a></td>
 <td align=center>Fossil</td>
 <td align=center>Rocks</td>
 <td align=center>Pentium 2</td>
 <td align=center>5</td>
 <td align=center>0.30</td>
 <td align=center>1.5</td>
 <td align=center>San Diego</td>
</tr>
<tr class=even>
 <td align=center><a href="details.php?id=2">(2) More</a></td>
 <td align=center>Mica</td>
 <td align=center>Rocks</td>
 <td align=center>Pentium 4</td>
 <td align=center>18</td>
 <td align=center>2.20</td>
 <td align=center>79.2</td>
 <td align=center>San Diego</td>
</tr>
<tr class=odd>
 <td align=center><a href="details.php?id=1">(1) More</a></td>
 <td align=center>Onyx</td>
 <td align=center>Rocks</td>
 <td align=center>Pentium 4</td>
 <td align=center>18</td>
 <td align=center>2.20</td>
 <td align=center>79.2</td>
 <td align=center>San Diego, CA</td>
</tr>
<tr>
 <td colspan=6 align=center>
  
 </td>
</tr>
</table>
</center>

</body>
</html>
 
