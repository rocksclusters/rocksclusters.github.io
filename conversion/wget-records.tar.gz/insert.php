<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>
<HEAD>
 <TITLE>Insert A Cluster</TITLE>
 <META http-equiv="Content-type" content="text/html; charset=utf-8">
 
 <LINK rel="stylesheet" href="./styles.css" type="text/css">
</HEAD>
<BODY BGCOLOR="#FFFFFF">

<TABLE WIDTH=100% CELLSPACING=5>
 <TR>
   <TD ALIGN=left VALIGN=center>
    <H1>Insert A Cluster</H1>
    <a href=./index.php>Back to Register</a>
   </TD>
   <TD ALIGN=right>
    <A HREF="http://www.rocksclusters.org">
     <IMG SRC="images/rocks.jpg" ALT="Rocks Clusters" HEIGHT=100 WIDTH=100 BORDER=0>
    </A>
   </TD>
 </TR>
</TABLE>


All fields other than Name and CPU count are optional, 
but fill in as many as possible.<br>

<p>

<p>

<form action="./insert.php" method=POST>
 <table cellspacing=2 cellpadding=4 border=0>
 <tr>
    <td align=right>Cluster Name</td>
    <td><input type=text name=name size=30 maxlength=64 value=""></td>
 </tr>
 <tr>
  <td align=right>Register Password <strong>[1]</strong><br>
   <small>(Used to modify this entry)</small>
  </td>
  <td>
   <input type=password name=pass size=16 maxlength=32 value="">
  </td>
 </tr>
 <tr>
  <td align=right>Password Again</td>
  <td>
   <input type=password name=pass2 size=16 maxlength=32 value="">
  </td>
 </tr>
 <tr>
  <td align=right>Number of CPUs</td>
  <td><input type=text name=cpus size=10 maxlength=11 value=""></td>
 </tr>
 <tr>
  <td align=right>CPU Type<br>
  </td>
  <td>
   <select name=cputype>
      <option value="Unspecified">--Choose One
      <option value="Athlon">Athlon
<option value="Athlon MP">Athlon MP
<option value="Athlon XP">Athlon XP
<option value="Athlon 64">Athlon 64
<option value="Opteron">Opteron
<option value="Pentium">Pentium
<option value="Pentium 2">Pentium 2
<option value="Pentium 3">Pentium 3
<option value="Pentium 4">Pentium 4
<option value="EM64T">EM64T
<option value="EM64T-4">EM64T-4
<option value="EM64T-8">EM64T-8
<option value="Itanium">Itanium
<option value="Itanium 2">Itanium 2
<option value="Other">Other
<option value="Unspecified">Unspecified

   </select>
   <small>Note: EM64T-4 is the Intel x86_64 chip that performs 4 FLOPS per
   cycle (e.g., Woodcrest).</small>
  </td>
 </tr>
 <tr>
  <td align=right>CPU Clock Rate (Ghz)<br>
   <small>(like 1.8)</small>
  </td>
  <td><input type=text name=cpuclock size=10 maxlength=11 value="">
  </td>
 </tr>
 <tr>
  <td align=right>Fully-Qualified Domain Name<br>
   <small>(like "meteor00.sdsc.edu")</small>
  </td>
  <td><input type=text name=fqdn size=50 maxlength=128 value=""></td>
 </tr>
 <tr>
  <td align=right>Rocks Software Version<br>
  </td>
  <td>
   <select name=rocks>
      <option value="Unspecified">--Choose One
      <option value="2.2.1">2.2.1
<option value="2.3.0">2.3.0
<option value="2.3.1">2.3.1
<option value="2.3.2">2.3.2
<option value="3.0.0">3.0.0
<option value="3.1.0">3.1.0
<option value="3.2.0">3.2.0
<option value="3.3.0">3.3.0
<option value="4.0.0">4.0.0
<option value="4.1">4.1
<option value="4.2">4.2
<option value="4.2.1">4.2.1
<option value="4.3">4.3
<option value="5.0">5.0
<option value="5.1">5.1
<option value="5.2">5.2
<option value="5.3">5.3
<option value="5.4">5.4
<option value="5.4.3">5.4.3
<option value="5.5">5.5
<option value="6.0">6.0
<option value="Other">Other
<option value="Unspecified">Unspecified

   </select>
  </td>
 </tr>
 <tr>
  <td align=right>Organization
  </td>
  <td><input type=text name=org size=30 maxlength=64 value=""></td>
 </tr>
 <tr>
  <td align=right>Location<br>
   <small>(like "San Diego")</small>
  </td>
  <td><input type=text name=location size=40 maxlength=64 value="">
  </td>
 </tr>
 <tr>
  <td align=right>Contact<br>
   <small>(like "Rocks Fan &lt;fan@sdsc.edu&gt;")</small>
  </td>
  <td><input type=text name=contact size=40 maxlength=64 value="">
  </td>
 </tr>
 <tr>
  <td align=right>Monitored:<br>
  </td>
  <td>
   Would you like to be part of the Rocks Grid Monitoring network?<br>
   yes:<input type=radio name=monitored value="yes" >
   no:<input type=radio name=monitored value="no" checked>
  </td>
 </tr>
 <tr>
  <td align=right valign=top>Bibliography <strong>[2]</strong></td>
  <td><textarea name=note rows=4 cols=45 ></textarea></td>
 </tr>
 <tr>
  <td align=right valign=top>Note</td>
  <td><textarea name=note rows=4 cols=45 ></textarea></td>
 </tr>
 <tr>
  <td> </td>
  <td>
<script type="text/javascript"
   src="http://api.recaptcha.net/challenge?k=6LdWJwAAAAAAANxQcfxYucMOHS9HDt7ShOQEROB8">
</script>

<noscript>
   <iframe src="http://api.recaptcha.net/noscript?k=6LdWJwAAAAAAANxQcfxYucMOHS9HDt7ShOQEROB8"
       height="300" width="500" frameborder="0"></iframe><br>
   <textarea name="recaptcha_challenge_field" rows="3" cols="40">
   </textarea>
   <input type=hidden name="recaptcha_response_field" value="manual_challenge">
</noscript>
  </td>
 </tr>

 <tr>
  <td> </td>
  <td colspan=1 align=left><input type=submit value="Commit"></td>
 </tr>

 </table>
 <input type=hidden name=id value="">
 <input type=hidden name=commit value="yes">
</form>

  </TD>
 </TR>
 <TR>
  <TD>

<P>
   <blockquote>
   <strong>[1]</strong>. We require this password if you need to
   edit your cluster's information in the future. This should not
   be the same as the root password of your cluster. A blank password
   is acceptable as well.<br>
   <p>
   <strong>[2]</strong>. The Bibliography section is for papers
   and publications that incorporated results obtained from this cluster.
   We hope to make the case that the Rocks software enables real and
   meaningful scientific work. This field can additionally describe 
   the purpose of the machine.
   <p>
   <strong>[3]</strong>. The Peak Theoretial Performance
   will be calculated for your cluster as follows:<br>
   <b>Peak GFLOPS = [CPUs] * 
   [CPU clock rate (GHz)] * [CPU floating point issue rate] </b><br>
   The issue rate of your CPUs describes how many FP instructions 
   it can compute per cycle. <br>
   A rough guide is: <i>(CPU type: issue rate)</i> 
    Pentium 2: <b>1</b>, 
    Pentium 4: <b>2</b>, 
    Athlon XP: <b>3</b>, 
    Itanium 2: <b>4</b>.<br>
  </blockquote>

</body>
</html>
